import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import Mustache from 'mustache';
import { describe, expect, it } from 'vitest';
import { whatsappUrl, planWhatsappMessage, SITE } from '../config/site';
import { planById } from '../data/plans';
import { adminEmailParams, customerEmailParams } from './email';
import { EMPTY_REQUEST, estimateFor, phoneForWhatsapp, validate, valuesFromQuery, whatsappRequestMessage, type RequestValues } from './request';

const template = (name: string) => readFileSync(resolve(__dirname, '../../email-templates', name), 'utf8');
const ctx = { origin: 'https://propcare.example', submittedAt: '16 Oct 2026, 11:30 am IST' };

const sample: RequestValues = {
  ...EMPTY_REQUEST,
  name: 'Asha Rao', email: 'asha@example.com', phone: '+44 7700 900123', cityArea: 'Electronic City, Bengaluru',
  propertyType: 'apartment', family: 'home', planId: 'care-plus', size: '3bhk-plus', numProperties: '2',
  billing: 'annual', addons: ['onboarding', 'emergency-visit'], contactTime: '3 PM – 5 PM', message: 'Keys are with my brother.\nPlease call first.', agree: true,
};

function indexOrder(html: string, needles: string[]) {
  // Each needle must appear after the previous one. Values from parameters are HTML-escaped
  // by the template engine ("/" becomes "&#x2F;"), static template text is not.
  let from = 0;
  for (const n of needles) {
    const raw = html.indexOf(n, from);
    const i = raw > -1 ? raw : html.indexOf(Mustache.escape(n), from);
    expect(i, `"${n}" missing or out of order (searched from ${from})`).toBeGreaterThan(-1);
    from = i + 1;
  }
}

describe('WhatsApp links', () => {
  it('use wa.me with the international number, digits only', () => {
    expect(SITE.whatsappNumber).toBe('917760273587');
    const url = whatsappUrl();
    expect(url.startsWith('https://wa.me/917760273587?text=')).toBe(true);
    expect(decodeURIComponent(url.split('?text=')[1])).toBe("Hi PropCare, I'm interested in your property care services.");
    expect(url).not.toMatch(/\s|wa\.me\/\+|whatsapp:\/\//);
    expect(decodeURIComponent(whatsappUrl(planWhatsappMessage('Care Plus')).split('?text=')[1])).toBe("Hi PropCare, I'm interested in the Care Plus plan.");
  });

  it('normalises customer numbers for the admin WhatsApp button', () => {
    expect(phoneForWhatsapp('98765 43210')).toBe('919876543210');
    expect(phoneForWhatsapp('098765-43210')).toBe('919876543210');
    expect(phoneForWhatsapp('+44 7700 900123')).toBe('447700900123');
    expect(phoneForWhatsapp('0044 7700 900123')).toBe('447700900123');
  });

  it('pre-fills the fallback message with the request', () => {
    const msg = whatsappRequestMessage(sample, estimateFor(sample));
    expect(msg).toContain('Asha Rao');
    expect(msg).toContain('Home Care — Care Plus (₹2,999 per property per month)');
    expect(msg).toContain('3BHK or larger · 2 properties · Annual billing');
    expect(msg).toMatch(/Estimate: ₹[\d,]+\/month \(excl\. GST\)/);
    expect(whatsappUrl(msg).length).toBeLessThan(2000);
  });
});

describe('request form', () => {
  it('pre-selects the plan from "Choose this plan" links', () => {
    const v = valuesFromQuery('?plan=care-plus&billing=annual');
    expect([v.planId, v.family, v.billing, v.propertyType]).toEqual(['care-plus', 'home', 'annual', 'apartment']);
    expect(valuesFromQuery('?package=complete').planId).toBe('care-plus');
    expect(valuesFromQuery('?plan=full-rental-management').propertyType).toBe('tenanted');
    expect(valuesFromQuery('?plan=portfolio-4-plus').numProperties).toBe('4');
    expect(valuesFromQuery('?plan=nonsense').planId).toBe('');
  });

  it('validates required fields with friendly messages', () => {
    const e = validate(EMPTY_REQUEST);
    expect(Object.keys(e).sort()).toEqual(['agree', 'cityArea', 'email', 'family', 'name', 'phone', 'planId', 'propertyType'].sort());
    expect(validate({ ...sample, family: 'rental', planId: 'rent-assist', monthlyRent: '' }).monthlyRent).toBeTruthy();
    expect(validate({ ...sample, family: 'land', planId: 'site-watch', landArea: '' }).landArea).toBeTruthy();
    expect(validate({ ...sample, email: 'asha@' }).email).toBeTruthy();
    expect(validate({ ...sample, phone: '12345' }).phone).toBeTruthy();
    expect(validate(sample)).toEqual({});
  });
});

describe('customer confirmation email', () => {
  const est = estimateFor(sample);
  const params = customerEmailParams(sample, est, ctx);
  // Drop the setup notes in the HTML comment so they can't satisfy the checks.
  const html = Mustache.render(template('customer-confirmation.html'), params).replace(/<!--[\s\S]*?-->/g, '');

  it('follows the required order', () => {
    indexOrder(html, [
      'Welcome to PropCare, Asha Rao!',
      'Thank you for visiting our website',
      'Your selected package',
      'Home Care — Care Plus',
      '₹2,999 per property per month',
      'What’s included',
      planById('care-plus')!.features[0],
      planById('care-plus')!.features.at(-1)!,
      'Your details',
      'Billing preference',
      'Estimated fee',
      'Estimate — excl. GST; final quote confirmed after a call',
      'What happens next',
      'within 1 working day (10 AM – 5 PM)',
      'https://wa.me/917760273587?text=',
      'propcare.admin@gmail.com',
      'Plot # 6, Nandi Garden, Haldenahalli, Anekal, Bangalore - 562106',
      'https://propcare.example/terms.html',
      'Warm regards',
      'Team PropCare',
      'Healthy Properties Happy Owners',
    ]);
  });

  it('lists every feature and the selections', () => {
    for (const feature of planById('care-plus')!.features) expect(html).toContain(Mustache.escape(feature));
    expect(html).toContain('3BHK or larger');
    expect(html).toContain('2 properties');
    expect(html).toContain('Onboarding, Emergency visit');
    expect(params.estimate_monthly).toBe(`₹${new Intl.NumberFormat('en-IN').format(Math.round((2999 + 500) * 2 * 0.9 * 10 / 12))} per month`);
  });

  it('leaves no unfilled placeholders and escapes visitor input', () => {
    const body = html.replace(/<!--[\s\S]*?-->/g, '');
    expect(body).not.toMatch(/\{\{|\}\}/);
    const evil = Mustache.render(template('customer-confirmation.html'), customerEmailParams({ ...sample, name: '<img src=x onerror=alert(1)>' }, est, ctx));
    expect(evil).not.toContain('<img src=x');
    expect(evil).toContain('Welcome to PropCare, &lt;img src');
  });

  it('subject variable and recipient', () => {
    expect(params.plan_name).toBe('Care Plus');
    expect(params.to_email).toBe('asha@example.com');
    expect(params.reply_to).toBe('propcare.admin@gmail.com');
  });
});

describe('admin notification email', () => {
  const est = estimateFor(sample);
  const params = adminEmailParams(sample, est, ctx);
  const html = Mustache.render(template('admin-notification.html'), params);

  it('contains every form field and replies to the customer', () => {
    for (const label of ['Full name', 'Email', 'Phone / WhatsApp', 'City / area of the property', 'Property type', 'Plan family', 'Plan', 'Property size', 'Number of properties', 'Billing preference', 'Add-ons', 'Preferred contact method', 'Preferred contact time', 'Owner lives', 'Message / special requirements', 'Agreed to Terms & Conditions', 'Submitted']) {
      expect(html, label).toContain(`>${Mustache.escape(label).replace('&amp;amp;', '&amp;')}<`);
    }
    expect(params.reply_to).toBe('asha@example.com');
    expect(params.customer_whatsapp_url).toMatch(/^https:\/\/wa\.me\/447700900123\?text=/);
    expect(html.replace(/<!--[\s\S]*?-->/g, '')).not.toMatch(/\{\{|\}\}/);
  });
});
