/**
 * Builds the EmailJS template parameters for the two request emails and sends them.
 *
 * Templates live in /email-templates (paste them into EmailJS — see EMAIL_SETUP.md).
 * Every value is inserted with {{double braces}}, so EmailJS HTML-escapes it: nothing a
 * visitor types can inject HTML into an email.
 */
import { EMAILJS, isEmailConfigured } from '../config/email';
import { SITE, whatsappUrl } from '../config/site';
import { BILLING_CYCLES, PRICING_NOTES, familyById, inr, planById, type Plan } from '../data/plans';
import type { Estimate } from './pricing';
import {
  allFieldLines, billedLine, netlifyFields, phoneForWhatsapp, planHeading, selectionLines, type LabelValue, type RequestValues,
} from './request';

export const NEXT_STEPS = `Our team will contact you within 1 working day (${SITE.hours}) to confirm details and schedule your onboarding visit.`;

export interface EmailContext {
  /** Site origin, e.g. https://propcare-bengaluru.netlify.app — used for the logo and Terms links. */
  origin: string;
  submittedAt: string;
}

function estimateBlock(est: Estimate | null) {
  if (!est) {
    return { estimate_ok: false, estimate_monthly: 'To be confirmed on our call', estimate_billed: '', estimate_lines: [] as LabelValue[], has_estimate_lines: false, one_time: [] as LabelValue[], has_one_time: false };
  }
  const lines: LabelValue[] = est.lines.map((line) => ({
    label: line.label,
    value: line.kind === 'discount' ? `− ${inr(Math.abs(line.amount))}` : inr(line.amount),
  }));
  const oneTime: LabelValue[] = est.oneTime.map((line) => ({ label: line.label + (line.note ? ` (${line.note})` : ''), value: line.display }));
  return {
    estimate_ok: est.ok,
    estimate_monthly: est.ok ? `${inr(est.effectiveMonthly)} per month` : (est.missing ?? 'To be confirmed on our call'),
    estimate_billed: est.ok ? billedLine(est) : '',
    estimate_lines: est.ok ? lines : [],
    has_estimate_lines: est.ok && lines.length > 0,
    one_time: oneTime,
    has_one_time: oneTime.length > 0,
  };
}

/** A short line under the price label, carrying only what the label doesn't already say. */
function pricingNote(plan: Plan): string {
  if (plan.family === 'home') return PRICING_NOTES.sizeAddon;
  if (plan.family === 'portfolio') return plan.pricingRule;
  return '';
}

function contactBlock(origin: string) {
  return {
    contact_phone: SITE.phoneDisplay,
    contact_tel: `tel:${SITE.phoneE164}`,
    whatsapp_url: whatsappUrl("Hi PropCare, I've just submitted a request on your website."),
    contact_email: SITE.email,
    office_address: SITE.address,
    working_hours: SITE.hours,
    terms_url: `${origin}/terms.html`,
    site_url: origin,
    site_host: origin.replace(/^https?:\/\//, ''),
    logo_url: `${origin}/email/propcare-mark.png`,
    tagline: SITE.tagline,
    company: SITE.legalName,
  };
}

/** Template 1: confirmation to the customer. */
export function customerEmailParams(values: RequestValues, est: Estimate | null, ctx: EmailContext): Record<string, unknown> {
  const plan = planById(values.planId)!;
  const isPortfolio = plan.family === 'portfolio';
  const feePlan = est?.feePlan;
  return {
    to_email: values.email.trim(),
    to_name: values.name.trim(),
    reply_to: SITE.email,
    name: values.name.trim(),
    plan_family: familyById(plan.family).name,
    plan_name: plan.name,
    plan_heading: planHeading(values),
    price_label: plan.priceLabel,
    pricing_note: pricingNote(plan),
    has_pricing_note: Boolean(pricingNote(plan)),
    features: plan.features,
    has_base_plan: Boolean(isPortfolio && feePlan),
    base_plan_heading: isPortfolio && feePlan ? `${familyById(feePlan.family).name} — ${feePlan.name} (${feePlan.priceLabel})` : '',
    base_features: isPortfolio && feePlan ? feePlan.features : [],
    selections: selectionLines(values, est),
    billing_cycle: BILLING_CYCLES[values.billing].label,
    ...estimateBlock(est),
    estimate_note: PRICING_NOTES.estimate,
    next_steps: NEXT_STEPS,
    ...contactBlock(ctx.origin),
    submitted_at: ctx.submittedAt,
  };
}

/** Template 2: new-request notification to PropCare with every form field. */
export function adminEmailParams(values: RequestValues, est: Estimate | null, ctx: EmailContext): Record<string, unknown> {
  const plan = planById(values.planId)!;
  const customerDigits = phoneForWhatsapp(values.phone);
  return {
    reply_to: values.email.trim(),
    customer_name: values.name.trim(),
    customer_email: values.email.trim(),
    customer_phone: values.phone.trim(),
    city_area: values.cityArea.trim(),
    plan_heading: planHeading(values),
    plan_name: plan.name,
    price_label: plan.priceLabel,
    fields: allFieldLines(values, est, ctx.submittedAt),
    features: est?.feePlan && plan.family === 'portfolio' ? [...plan.features, ...est.feePlan.features.map((f) => `${est.feePlan.name}: ${f}`)] : plan.features,
    ...estimateBlock(est),
    estimate_note: PRICING_NOTES.estimate,
    customer_whatsapp_url: `https://wa.me/${customerDigits}?text=${encodeURIComponent(`Hi ${values.name.trim().split(/\s+/)[0]}, this is PropCare about your ${plan.name} request.`)}`,
    customer_tel: `tel:+${customerDigits}`,
    customer_mailto: `mailto:${values.email.trim()}?subject=${encodeURIComponent(`Your PropCare ${plan.name} request`)}`,
    ...contactBlock(ctx.origin),
    submitted_at: ctx.submittedAt,
  };
}

export class EmailSendError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

export async function sendEmail(templateId: string, params: Record<string, unknown>, timeoutMs = 15000): Promise<void> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(EMAILJS.endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ service_id: EMAILJS.serviceId, template_id: templateId, user_id: EMAILJS.publicKey, template_params: params }),
      signal: controller.signal,
    });
    if (!response.ok) throw new EmailSendError(response.status, await response.text().catch(() => response.statusText));
  } finally {
    clearTimeout(timer);
  }
}

export interface EmailOutcome { configured: boolean; admin: boolean; customer: boolean }

const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

/** EmailJS's REST API allows 1 request per second: retry once if it answers 429 (too many requests). */
async function sendWithRetry(templateId: string, params: Record<string, unknown>): Promise<void> {
  try {
    await sendEmail(templateId, params);
  } catch (error) {
    if (!(error instanceof EmailSendError) || error.status !== 429) throw error;
    await wait(1500);
    await sendEmail(templateId, params);
  }
}

/** Sends the PropCare notification first, then (only if it worked) the customer confirmation. */
export async function sendRequestEmails(values: RequestValues, est: Estimate | null, ctx: EmailContext): Promise<EmailOutcome> {
  if (!isEmailConfigured()) return { configured: false, admin: false, customer: false };
  const outcome: EmailOutcome = { configured: true, admin: false, customer: false };
  const started = Date.now();
  try {
    await sendWithRetry(EMAILJS.adminTemplateId, adminEmailParams(values, est, ctx));
    outcome.admin = true;
  } catch (error) {
    if (import.meta.env.DEV) console.warn('Admin email failed', error);
    return outcome;
  }
  // Keep the two requests at least ~1 second apart (EmailJS rate limit).
  const gap = 1100 - (Date.now() - started);
  if (gap > 0) await wait(gap);
  try {
    await sendWithRetry(EMAILJS.customerTemplateId, customerEmailParams(values, est, ctx));
    outcome.customer = true;
  } catch (error) {
    if (import.meta.env.DEV) console.warn('Customer email failed', error);
  }
  return outcome;
}

/** Netlify Forms copy (lead record in the Netlify dashboard). Resolves false off Netlify. */
export async function submitToNetlify(formName: string, values: RequestValues, est: Estimate | null, submittedAt: string): Promise<boolean> {
  const body = new URLSearchParams();
  body.set('form-name', formName);
  body.set('bot-field', values.botField);
  for (const [key, value] of Object.entries(netlifyFields(values, est, submittedAt))) body.set(key, value);
  try {
    const response = await fetch('/', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: body.toString() });
    return response.ok;
  } catch {
    return false;
  }
}
