import { afterEach, describe, expect, it, vi } from 'vitest';
import { EMPTY_REQUEST, estimateFor, type RequestValues } from './request';

const values = {
  ...EMPTY_REQUEST,
  name: 'Asha Rao', email: 'asha@example.com', phone: '+91 98450 12345', cityArea: 'Anekal',
  propertyType: 'apartment', family: 'home', planId: 'care-plus', agree: true,
} as RequestValues;
const ctx = { origin: 'https://example.test', submittedAt: '16 Oct 2026, 6:00 pm IST' };

/** Load the email module with EmailJS configured (the IDs are read when the module loads). */
async function loadConfigured() {
  vi.stubEnv('VITE_EMAILJS_SERVICE_ID', 'service_test');
  vi.stubEnv('VITE_EMAILJS_PUBLIC_KEY', 'public_test');
  vi.stubEnv('VITE_EMAILJS_TEMPLATE_CUSTOMER', 'template_customer');
  vi.stubEnv('VITE_EMAILJS_TEMPLATE_ADMIN', 'template_admin');
  vi.resetModules();
  return import('./email');
}

describe('sendRequestEmails (EmailJS REST)', () => {
  afterEach(() => { vi.unstubAllEnvs(); vi.unstubAllGlobals(); vi.resetModules(); });

  it('does nothing while the EmailJS IDs are still placeholders', async () => {
    const fetchMock = vi.fn();
    vi.stubGlobal('fetch', fetchMock);
    vi.resetModules();
    const { sendRequestEmails } = await import('./email');
    expect(await sendRequestEmails(values, estimateFor(values), ctx)).toEqual({ configured: false, admin: false, customer: false });
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it('sends the PropCare copy first, then the customer confirmation at least 1 s later (EmailJS allows 1 request/s)', async () => {
    const calls: { at: number; body: { service_id: string; template_id: string; user_id: string } }[] = [];
    vi.stubGlobal('fetch', vi.fn(async (_url: string, init: RequestInit) => {
      calls.push({ at: Date.now(), body: JSON.parse(String(init.body)) });
      return new Response('OK', { status: 200 });
    }));
    const { sendRequestEmails } = await loadConfigured();
    expect(await sendRequestEmails(values, estimateFor(values), ctx)).toEqual({ configured: true, admin: true, customer: true });
    expect(calls.map((c) => c.body.template_id)).toEqual(['template_admin', 'template_customer']);
    expect(calls.every((c) => c.body.service_id === 'service_test' && c.body.user_id === 'public_test')).toBe(true);
    expect(calls[1].at - calls[0].at).toBeGreaterThanOrEqual(1000);
  });

  it('retries once after a 429, and never confirms to the customer if PropCare’s copy failed', async () => {
    const statuses = [429, 500];
    const templates: string[] = [];
    vi.stubGlobal('fetch', vi.fn(async (_url: string, init: RequestInit) => {
      templates.push(JSON.parse(String(init.body)).template_id);
      return new Response('error', { status: statuses.shift() ?? 500 });
    }));
    const { sendRequestEmails } = await loadConfigured();
    expect(await sendRequestEmails(values, estimateFor(values), ctx)).toEqual({ configured: true, admin: false, customer: false });
    expect(templates).toEqual(['template_admin', 'template_admin']);
  });
});
