/**
 * Fee estimator. Pure functions over src/data/plans.ts, shared by the Packages page
 * (cards + estimator), the request form, the confirmation emails and the WhatsApp fallback.
 *
 * Order of calculation (all monthly, per the pricing sheet):
 *   per-property fee (flat / % of rent / per acre) + size add-on (Home Care only)
 *   × number of properties
 *   − Family Portfolio discount (10% for 2–3 properties, 15% for 4+)
 *   × billing factor (monthly 1, quarterly 0.95, annual 10/12)
 */
import {
  BILLING_CYCLES, OUTSIDE_AREA_NOTE, PLANS, PRICING_NOTES, SIZE_OPTIONS, SQFT_PER_ACRE, billingFactor, inr, num,
  oneTimeCharge, planById, portfolioTierFor, PORTFOLIO_TIERS,
  type AddonId, type BillingCycleId, type Plan, type PortfolioTier, type SizeId,
} from '../data/plans';

export type LandUnit = 'sqft' | 'acres';

export interface EstimateInput {
  planId: string;
  /** For Family Portfolio: the plan used for each property. */
  basePlanId?: string;
  size?: SizeId | '';
  monthlyRent?: number | null;
  landArea?: number | null;
  landUnit?: LandUnit;
  numProperties?: number | null;
  billing: BillingCycleId;
  addons?: AddonId[];
}

export interface EstimateLine { label: string; amount: number; kind: 'base' | 'addon' | 'multiply' | 'discount' | 'subtotal' }
export interface OneTimeLine { id: AddonId; label: string; amount: number | null; display: string; note?: string }

export interface Estimate {
  ok: boolean;
  /** Why the estimate can't be calculated yet (e.g. rent missing). */
  missing?: string;
  plan: Plan;
  /** The plan that sets the per-property fee (differs from `plan` for Family Portfolio). */
  feePlan: Plan;
  numProperties: number;
  perPropertyMonthly: number;
  lines: EstimateLine[];
  portfolioTier: PortfolioTier | null;
  /** Monthly total after portfolio discount, before billing discount. */
  monthlyBeforeBilling: number;
  billing: BillingCycleId;
  /** Effective monthly fee after the billing discount, rounded to the rupee. */
  effectiveMonthly: number;
  /** Amount charged per billing period, rounded to the rupee. */
  billedAmount: number;
  billedPer: string;
  /** Saving per year versus paying monthly, rounded. */
  savingsPerYear: number;
  oneTime: OneTimeLine[];
  oneTimeTotal: number;
  notes: string[];
  warnings: string[];
}

export const DEFAULT_FEE_PLAN_FOR_PORTFOLIO = 'care-plus';

export function toAcres(area: number, unit: LandUnit): number {
  return unit === 'acres' ? area : area / SQFT_PER_ACRE;
}
export function toSqFt(area: number, unit: LandUnit): number {
  return unit === 'sqft' ? area : area * SQFT_PER_ACRE;
}

/** Best Land Watch plan for an area (smallest plan whose limit covers it, else the per-acre plan). */
export function suggestLandPlan(area: number, unit: LandUnit): string {
  const sqft = toSqFt(area, unit);
  const capped = PLANS
    .filter((p) => p.family === 'land' && p.pricing.kind === 'flat' && p.pricing.maxAreaSqFt)
    .sort((a, b) => ((a.pricing as { maxAreaSqFt: number }).maxAreaSqFt - (b.pricing as { maxAreaSqFt: number }).maxAreaSqFt));
  const fit = capped.find((p) => sqft <= (p.pricing as { maxAreaSqFt: number }).maxAreaSqFt);
  return fit?.id ?? PLANS.find((p) => p.family === 'land' && p.pricing.kind === 'perAcre')!.id;
}

const round = (x: number) => Math.round(x);

export function estimate(input: EstimateInput): Estimate {
  const plan = planById(input.planId);
  if (!plan) throw new Error(`Unknown plan: ${input.planId}`);

  const isPortfolio = plan.pricing.kind === 'portfolio';
  const feePlan = isPortfolio ? planById(input.basePlanId) ?? planById(DEFAULT_FEE_PLAN_FOR_PORTFOLIO)! : plan;

  let numProperties = Math.max(1, Math.floor(Number(input.numProperties) || 1));
  if (isPortfolio) {
    const chosen = PORTFOLIO_TIERS.find((t) => t.id === (plan.pricing as { tier: string }).tier)!;
    numProperties = Math.max(numProperties, chosen.minProperties);
  }

  const lines: EstimateLine[] = [];
  const warnings: string[] = [];
  const notes: string[] = [];
  let perProperty = 0;
  let missing: string | undefined;

  const p = feePlan.pricing;
  if (p.kind === 'flat') {
    perProperty = p.monthly;
    lines.push({ label: `${feePlan.name}: ${inr(p.monthly)}/month`, amount: p.monthly, kind: 'base' });
    if (p.sizeAddon) {
      const size = SIZE_OPTIONS.find((s) => s.id === input.size);
      if (size && size.addon > 0) {
        perProperty += size.addon;
        lines.push({ label: `Size add-on (${size.label})`, amount: size.addon, kind: 'addon' });
      }
    }
    if (p.maxAreaSqFt && input.landArea && input.landArea > 0) {
      const sqft = toSqFt(input.landArea, input.landUnit ?? 'sqft');
      if (sqft > p.maxAreaSqFt) {
        const better = planById(suggestLandPlan(input.landArea, input.landUnit ?? 'sqft'))!;
        warnings.push(`${feePlan.name} covers ${feePlan.id === 'site-watch' ? `plots up to ${num(p.maxAreaSqFt)} sq ft` : 'land up to 1 acre'}. For ${formatArea(input.landArea, input.landUnit ?? 'sqft')}, ${better.name} fits: ${better.priceLabel}.`);
      }
    }
  } else if (p.kind === 'rentPercent') {
    const rent = Number(input.monthlyRent);
    if (!rent || rent <= 0) {
      missing = 'Enter the monthly rent to estimate this plan.';
      perProperty = p.minimum;
      lines.push({ label: `${feePlan.name}: minimum ${inr(p.minimum)}/month`, amount: p.minimum, kind: 'base' });
    } else {
      const raw = rent * p.percent;
      perProperty = Math.max(raw, p.minimum);
      lines.push({
        label: raw >= p.minimum
          ? `${feePlan.name}: ${Math.round(p.percent * 100)}% of ${inr(rent)} rent`
          : `${feePlan.name}: minimum fee (${Math.round(p.percent * 100)}% of ${inr(rent)} is ${inr(raw)})`,
        amount: perProperty, kind: 'base',
      });
    }
  } else if (p.kind === 'perAcre') {
    perProperty = p.base;
    lines.push({ label: `${feePlan.name}: ${inr(p.base)}/month (first acre)`, amount: p.base, kind: 'base' });
    const area = Number(input.landArea);
    if (area > 0) {
      const acres = toAcres(area, input.landUnit ?? 'sqft');
      const extra = Math.max(0, Math.ceil(acres - p.includedAcres - 1e-9));
      if (extra > 0) {
        perProperty += extra * p.perExtraAcre;
        lines.push({ label: `${extra} extra acre${extra > 1 ? 's' : ''} × ${inr(p.perExtraAcre)}`, amount: extra * p.perExtraAcre, kind: 'addon' });
        if (!Number.isInteger(Math.round(acres * 1e6) / 1e6)) notes.push('Part acres are rounded up to the next whole acre in this estimate.');
      }
    } else {
      notes.push(`Add the land area to include ${inr(p.perExtraAcre)} for each extra acre.`);
    }
  }

  let monthly = perProperty * numProperties;
  if (numProperties > 1) {
    lines.push({ label: `× ${numProperties} properties`, amount: monthly, kind: 'multiply' });
    if (feePlan.family === 'rental') notes.push('Assumes a similar rent for each property.');
    if (feePlan.family === 'land') notes.push('Assumes a similar area for each plot.');
  }

  const portfolioTier = portfolioTierFor(numProperties);
  if (portfolioTier) {
    const discount = monthly * portfolioTier.discount;
    lines.push({ label: `Family Portfolio discount (${Math.round(portfolioTier.discount * 100)}% for ${portfolioTier.label} properties)`, amount: -discount, kind: 'discount' });
    monthly -= discount;
  }

  const cycle = BILLING_CYCLES[input.billing];
  const factor = billingFactor(input.billing);
  if (input.billing === 'quarterly') lines.push({ label: 'Quarterly billing: 5% off', amount: -monthly * cycle.discount, kind: 'discount' });
  if (input.billing === 'annual') lines.push({ label: 'Annual billing: pay 10 months, get 12', amount: -(monthly - monthly * factor), kind: 'discount' });

  const effectiveMonthly = round(monthly * factor);
  const billedAmount = round(monthly * cycle.chargedMonths * (1 - cycle.discount));
  const savingsPerYear = round(monthly * 12 - monthly * factor * 12);

  // One-time charges for the add-ons the owner ticked.
  const oneTime: OneTimeLine[] = [];
  for (const id of input.addons ?? []) {
    if (id === 'onboarding') {
      const fee = oneTimeCharge('onboarding').amount! * numProperties;
      oneTime.push(input.billing === 'annual'
        ? { id, label: 'Onboarding', amount: 0, display: 'Waived', note: 'waived on annual payment' }
        : { id, label: `Onboarding${numProperties > 1 ? ` × ${numProperties}` : ''}`, amount: fee, display: inr(fee), note: `${inr(oneTimeCharge('onboarding').amount!)} per property; waived on annual payment` });
    } else if (id === 'tenant-placement') {
      const rent = Number(input.monthlyRent);
      const free = feePlan.id === 'full-rental-management' && input.billing === 'annual';
      if (free) oneTime.push({ id, label: 'Tenant placement', amount: 0, display: 'Free', note: 'free with a 12-month Full Rental Management commitment' });
      else if (rent > 0) oneTime.push({ id, label: 'Tenant placement', amount: round(rent / 2), display: inr(rent / 2), note: "half of one month's rent, charged once" });
      else oneTime.push({ id, label: 'Tenant placement', amount: null, display: "Half of one month's rent", note: 'charged once' });
    } else if (id === 'emergency-visit') {
      oneTime.push({ id, label: 'Emergency visit', amount: null, display: `${oneTimeCharge('emergency-visit').price} per visit`, note: 'when needed, within 24 hours' });
    } else if (id === 'paperwork') {
      oneTime.push({ id, label: 'Paperwork assistance', amount: null, display: oneTimeCharge('paperwork').price });
    }
  }
  const oneTimeTotal = oneTime.reduce((sum, line) => sum + (line.amount ?? 0), 0);

  notes.push(PRICING_NOTES.vendorCosts, OUTSIDE_AREA_NOTE);

  return {
    ok: !missing, missing, plan, feePlan, numProperties, perPropertyMonthly: perProperty, lines, portfolioTier,
    monthlyBeforeBilling: monthly, billing: input.billing, effectiveMonthly, billedAmount, billedPer: cycle.per,
    savingsPerYear, oneTime, oneTimeTotal, notes, warnings,
  };
}

/** Price shown on a plan card for a billing cycle (effective per month). */
export function cardPrice(plan: Plan, billing: BillingCycleId): { amount: number | null; billed: number | null; savings: number } {
  const factor = billingFactor(billing);
  const cycle = BILLING_CYCLES[billing];
  if (plan.pricing.kind === 'flat' || plan.pricing.kind === 'perAcre') {
    const base = plan.pricing.kind === 'flat' ? plan.pricing.monthly : plan.pricing.base;
    return { amount: round(base * factor), billed: round(base * cycle.chargedMonths * (1 - cycle.discount)), savings: round(base * 12 * (1 - factor)) };
  }
  if (plan.pricing.kind === 'rentPercent') {
    const min = plan.pricing.minimum;
    return { amount: round(min * factor), billed: round(min * cycle.chargedMonths * (1 - cycle.discount)), savings: round(min * 12 * (1 - factor)) };
  }
  return { amount: null, billed: null, savings: 0 };
}

export function formatArea(area: number, unit: LandUnit): string {
  return unit === 'acres' ? `${area} acre${area === 1 ? '' : 's'}` : `${num(area)} sq ft`;
}

export function savingsLabel(billing: BillingCycleId, savingsPerYear: number): string | null {
  if (billing === 'monthly' || savingsPerYear <= 0) return null;
  return billing === 'annual' ? `Save ${inr(savingsPerYear)} a year — 2 months free` : `Save ${inr(savingsPerYear)} a year`;
}
