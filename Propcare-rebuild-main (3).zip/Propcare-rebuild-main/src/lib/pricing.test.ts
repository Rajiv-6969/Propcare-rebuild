import { describe, expect, it } from 'vitest';
import { PLANS, planById, plansInFamily, inr, billingFactor, familyFromLabel, RECOMMENDED_PLAN_ID } from '../data/plans';
import { cardPrice, estimate, suggestLandPlan } from './pricing';

describe('plans data (section 1 of the owner\'s document)', () => {
  it('has every plan with the exact base prices', () => {
    const prices = Object.fromEntries(PLANS.map((p) => [p.id, p.basePrice]));
    expect(prices).toEqual({
      essential: 1499, 'care-plus': 2999, premium: 4999,
      'rent-assist': null, 'full-rental-management': null,
      'site-watch': 999, 'land-watch': 1999, 'estate-watch': 1999,
      'portfolio-2-3': null, 'portfolio-4-plus': null,
    });
  });

  it('has the exact price labels', () => {
    expect(planById('essential')!.priceLabel).toBe('₹1,499 per property per month');
    expect(planById('care-plus')!.priceLabel).toBe('₹2,999 per property per month');
    expect(planById('premium')!.priceLabel).toBe('₹4,999 per property per month');
    expect(planById('rent-assist')!.priceLabel).toBe('5% of monthly rent (min ₹1,500)');
    expect(planById('full-rental-management')!.priceLabel).toBe('8% of monthly rent (min ₹3,000)');
    expect(planById('site-watch')!.priceLabel).toBe('₹999 per month (up to 2,400 sq ft)');
    expect(planById('land-watch')!.priceLabel).toBe('₹1,999 per month (up to 1 acre)');
    expect(planById('estate-watch')!.priceLabel).toBe('₹1,999 + ₹750 per extra acre, per month');
    expect(planById('portfolio-2-3')!.priceLabel).toBe('10% off combined fees');
    expect(planById('portfolio-4-plus')!.priceLabel).toBe('15% off combined fees');
  });

  it('marks only Care Plus as recommended', () => {
    expect(PLANS.filter((p) => p.recommended).map((p) => p.id)).toEqual(['care-plus']);
    expect(RECOMMENDED_PLAN_ID).toBe('care-plus');
  });

  it('derives features from the comparison table', () => {
    expect(planById('essential')!.features).toHaveLength(6);
    expect(planById('care-plus')!.features).toHaveLength(10);
    expect(planById('premium')!.features).toHaveLength(12);
    expect(planById('essential')!.features).not.toContain('Housing society liaison');
    expect(planById('care-plus')!.features).toContain('Checklist inspection + dated photo and video report');
    expect(planById('premium')!.features).toContain('Relationship manager + Annual Asset Review');
    expect(planById('rent-assist')!.features).toContain('Quarterly property inspection');
    expect(planById('full-rental-management')!.features).toContain('TDS-on-rent support for NRI owners');
    expect(planById('estate-watch')!.features).toContain('Weed or debris clearing once a year, included');
    expect(planById('site-watch')!.features.some((f) => f.startsWith('Drone'))).toBe(false);
    expect(plansInFamily('home').map((p) => p.name)).toEqual(['Essential', 'Care Plus', 'Premium']);
  });

  it('formats rupees the Indian way', () => {
    expect(inr(161973)).toBe('₹1,61,973');
    expect(inr(2499.17)).toBe('₹2,499');
    expect(familyFromLabel('home')).toBe('From ₹1,499');
    expect(familyFromLabel('land')).toBe('From ₹999');
    expect(familyFromLabel('rental')).toBe('5% of rent');
  });

  it('uses the right billing factors', () => {
    expect(billingFactor('monthly')).toBe(1);
    expect(billingFactor('quarterly')).toBeCloseTo(0.95);
    expect(billingFactor('annual')).toBeCloseTo(10 / 12);
  });
});

describe('estimate()', () => {
  it('Care Plus monthly / quarterly / annual', () => {
    const m = estimate({ planId: 'care-plus', billing: 'monthly' });
    expect([m.effectiveMonthly, m.billedAmount, m.savingsPerYear]).toEqual([2999, 2999, 0]);
    const q = estimate({ planId: 'care-plus', billing: 'quarterly' });
    expect([q.effectiveMonthly, q.billedAmount, q.savingsPerYear]).toEqual([2849, 8547, 1799]);
    const a = estimate({ planId: 'care-plus', billing: 'annual' });
    // annual = 10/12 of the 12-month total
    expect(a.billedAmount).toBe(2999 * 10);
    expect(a.effectiveMonthly).toBe(Math.round((2999 * 12 * 10) / 12 / 12));
    expect(a.savingsPerYear).toBe(2999 * 2);
  });

  it('adds the size add-on for Home Care only', () => {
    expect(estimate({ planId: 'essential', size: '3bhk-plus', billing: 'monthly' }).effectiveMonthly).toBe(1999);
    expect(estimate({ planId: 'essential', size: 'independent', billing: 'monthly' }).effectiveMonthly).toBe(2499);
    expect(estimate({ planId: 'site-watch', size: 'independent', billing: 'monthly' }).effectiveMonthly).toBe(999);
  });

  it('applies Family Portfolio 10% for 2–3 and 15% for 4+', () => {
    const three = estimate({ planId: 'premium', size: 'independent', numProperties: 3, billing: 'annual' });
    expect(three.portfolioTier?.discount).toBe(0.1);
    expect(three.monthlyBeforeBilling).toBeCloseTo((4999 + 1000) * 3 * 0.9);
    expect(three.billedAmount).toBe(161973);
    expect(three.effectiveMonthly).toBe(13498);
    const four = estimate({ planId: 'essential', numProperties: 4, billing: 'monthly' });
    expect(four.portfolioTier?.discount).toBe(0.15);
    expect(four.effectiveMonthly).toBe(Math.round(1499 * 4 * 0.85));
    expect(estimate({ planId: 'essential', numProperties: 1, billing: 'monthly' }).portfolioTier).toBeNull();
  });

  it('portfolio plans use a per-property plan and at least the tier minimum', () => {
    const e = estimate({ planId: 'portfolio-2-3', billing: 'monthly' });
    expect(e.numProperties).toBe(2);
    expect(e.feePlan.id).toBe('care-plus');
    expect(e.effectiveMonthly).toBe(Math.round(2999 * 2 * 0.9));
    const e4 = estimate({ planId: 'portfolio-4-plus', basePlanId: 'land-watch', numProperties: 2, billing: 'quarterly' });
    expect(e4.numProperties).toBe(4);
    expect(e4.effectiveMonthly).toBe(Math.round(1999 * 4 * 0.85 * 0.95));
  });

  it('Rental Care: % of rent with a minimum', () => {
    expect(estimate({ planId: 'rent-assist', monthlyRent: 25000, billing: 'monthly' }).effectiveMonthly).toBe(1500);
    expect(estimate({ planId: 'rent-assist', monthlyRent: 40000, billing: 'monthly' }).effectiveMonthly).toBe(2000);
    expect(estimate({ planId: 'full-rental-management', monthlyRent: 25000, billing: 'monthly' }).effectiveMonthly).toBe(3000);
    const q = estimate({ planId: 'full-rental-management', monthlyRent: 50000, billing: 'quarterly' });
    expect([q.effectiveMonthly, q.billedAmount]).toEqual([3800, 11400]);
    const missing = estimate({ planId: 'rent-assist', billing: 'monthly' });
    expect(missing.ok).toBe(false);
  });

  it('Land Watch: extra acres and plan suggestions', () => {
    expect(estimate({ planId: 'estate-watch', landArea: 1, landUnit: 'acres', billing: 'monthly' }).effectiveMonthly).toBe(1999);
    expect(estimate({ planId: 'estate-watch', landArea: 2, landUnit: 'acres', billing: 'monthly' }).effectiveMonthly).toBe(2749);
    expect(estimate({ planId: 'estate-watch', landArea: 3.5, landUnit: 'acres', billing: 'monthly' }).effectiveMonthly).toBe(1999 + 3 * 750);
    expect(estimate({ planId: 'estate-watch', landArea: 87120, landUnit: 'sqft', billing: 'monthly' }).effectiveMonthly).toBe(2749);
    expect(suggestLandPlan(1200, 'sqft')).toBe('site-watch');
    expect(suggestLandPlan(10000, 'sqft')).toBe('land-watch');
    expect(suggestLandPlan(1.2, 'acres')).toBe('estate-watch');
    const site = estimate({ planId: 'site-watch', landArea: 3000, landUnit: 'sqft', billing: 'monthly' });
    expect(site.warnings[0]).toContain('Land Watch');
  });

  it('one-time add-ons', () => {
    const monthly = estimate({ planId: 'care-plus', numProperties: 2, billing: 'monthly', addons: ['onboarding'] });
    expect(monthly.oneTime[0].amount).toBe(2499 * 2);
    const annual = estimate({ planId: 'care-plus', billing: 'annual', addons: ['onboarding'] });
    expect(annual.oneTime[0]).toMatchObject({ amount: 0, display: 'Waived' });
    const tp = estimate({ planId: 'rent-assist', monthlyRent: 30000, billing: 'monthly', addons: ['tenant-placement'] });
    expect(tp.oneTime[0].amount).toBe(15000);
    const tpFree = estimate({ planId: 'full-rental-management', monthlyRent: 30000, billing: 'annual', addons: ['tenant-placement'] });
    expect(tpFree.oneTime[0].display).toBe('Free');
  });
});

describe('cardPrice()', () => {
  it('shows effective monthly prices per billing cycle', () => {
    const cp = planById('care-plus')!;
    expect(cardPrice(cp, 'monthly').amount).toBe(2999);
    expect(cardPrice(cp, 'quarterly').amount).toBe(2849);
    expect(cardPrice(cp, 'annual').amount).toBe(2499);
    expect(cardPrice(cp, 'annual').billed).toBe(29990);
    expect(cardPrice(planById('rent-assist')!, 'quarterly').amount).toBe(1425);
    expect(cardPrice(planById('portfolio-2-3')!, 'annual').amount).toBeNull();
  });
});
