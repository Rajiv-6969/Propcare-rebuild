/**
 * "Submit a Request" form: field options, URL pre-fill, validation, and the summaries
 * used by the admin email and the WhatsApp fallback.
 */
import {
  ADDONS, BILLING_CYCLES, PLAN_FAMILIES, PLANS, SIZE_OPTIONS, familyById, planById, plansInFamily,
  type AddonId, type BillingCycleId, type FamilyId, type SizeId,
} from '../data/plans';
import { DEFAULT_FEE_PLAN_FOR_PORTFOLIO, estimate, formatArea, suggestLandPlan, type Estimate, type EstimateInput, type LandUnit } from './pricing';
import { inr } from '../data/plans';

export type PropertyTypeId = 'apartment' | 'villa' | 'tenanted' | 'land';

export const PROPERTY_TYPES: { id: PropertyTypeId; label: string; family: FamilyId; size?: SizeId }[] = [
  { id: 'apartment', label: 'Apartment / Flat', family: 'home' },
  { id: 'villa', label: 'Villa / Independent house', family: 'home', size: 'independent' },
  { id: 'tenanted', label: 'Tenanted home', family: 'rental' },
  { id: 'land', label: 'Vacant land / plot', family: 'land' },
];

export const CONTACT_METHODS = ['WhatsApp', 'Phone call', 'Email'] as const;
export const CONTACT_TIMES = ['10 AM – 12 noon', '12 noon – 3 PM', '3 PM – 5 PM', 'Any time, 10 AM – 5 PM'] as const;
export const OWNER_LOCATIONS = ['In India', 'Abroad (NRI)'] as const;

export interface RequestValues {
  name: string;
  email: string;
  phone: string;
  cityArea: string;
  propertyType: PropertyTypeId | '';
  family: FamilyId | '';
  planId: string;
  /** Family Portfolio only: the plan used for each property. */
  basePlanId: string;
  size: SizeId | '';
  monthlyRent: string;
  landArea: string;
  landUnit: LandUnit;
  numProperties: string;
  billing: BillingCycleId;
  addons: AddonId[];
  contactMethod: string;
  contactTime: string;
  ownerLocation: string;
  message: string;
  agree: boolean;
  /** Honeypot: humans never see or fill this. */
  botField: string;
}

export const EMPTY_REQUEST: RequestValues = {
  name: '', email: '', phone: '', cityArea: '', propertyType: '', family: '', planId: '', basePlanId: DEFAULT_FEE_PLAN_FOR_PORTFOLIO,
  size: '', monthlyRent: '', landArea: '', landUnit: 'sqft', numProperties: '1', billing: 'monthly', addons: [],
  contactMethod: '', contactTime: '', ownerLocation: '', message: '', agree: false, botField: '',
};

const LEGACY_PACKAGES: Record<string, string> = { basic: 'essential', complete: 'care-plus', premium: 'premium', plot: 'site-watch' };

/** Read ?plan=…&billing=…&size=…&rent=…&area=…&unit=…&n=…&base=…&addons=… (plus old ?package= links). */
export function valuesFromQuery(search: string): RequestValues {
  const q = new URLSearchParams(search);
  const values: RequestValues = { ...EMPTY_REQUEST, addons: [] };
  const rawPlan = (q.get('plan') ?? q.get('package') ?? '').toLowerCase().trim();
  const plan = planById(rawPlan) ?? planById(LEGACY_PACKAGES[rawPlan]) ?? PLANS.find((p) => p.name.toLowerCase() === rawPlan.replace(/-/g, ' '));
  if (plan) { values.planId = plan.id; values.family = plan.family; }
  const family = q.get('family') as FamilyId | null;
  if (!plan && family && PLAN_FAMILIES.some((f) => f.id === family)) values.family = family;
  const billing = q.get('billing') as BillingCycleId | null;
  if (billing && billing in BILLING_CYCLES) values.billing = billing;
  const size = q.get('size') as SizeId | null;
  if (size && SIZE_OPTIONS.some((s) => s.id === size)) values.size = size;
  const rent = Number(q.get('rent'));
  if (rent > 0) values.monthlyRent = String(Math.round(rent));
  const area = Number(q.get('area'));
  if (area > 0) values.landArea = String(area);
  const unit = q.get('unit');
  if (unit === 'acres' || unit === 'sqft') values.landUnit = unit;
  const n = Number(q.get('n'));
  if (Number.isInteger(n) && n >= 1 && n <= 50) values.numProperties = String(n);
  const base = q.get('base');
  if (base && planById(base) && planById(base)!.family !== 'portfolio') values.basePlanId = base;
  const addons = (q.get('addons') ?? '').split(',').filter((a): a is AddonId => ADDONS.some((x) => x.id === a));
  values.addons = addons;
  // Pick a sensible property type from the plan family.
  const family2 = values.family === 'portfolio' ? planById(values.basePlanId)?.family : values.family;
  if (family2 === 'rental') values.propertyType = 'tenanted';
  else if (family2 === 'land') values.propertyType = 'land';
  else if (family2 === 'home') values.propertyType = values.size === 'independent' ? 'villa' : 'apartment';
  if (values.family === 'portfolio') {
    const tierMin = values.planId === 'portfolio-4-plus' ? 4 : 2;
    if (Number(values.numProperties) < tierMin) values.numProperties = String(tierMin);
  }
  return values;
}

/** The family whose per-property fields (size / rent / area) apply. */
export function feeFamily(values: RequestValues): FamilyId | '' {
  if (values.family === 'portfolio') return planById(values.basePlanId)?.family ?? 'home';
  return values.family;
}

export function toEstimateInput(values: RequestValues): EstimateInput | null {
  if (!values.planId || !planById(values.planId)) return null;
  return {
    planId: values.planId,
    basePlanId: values.basePlanId,
    size: values.size,
    monthlyRent: Number(values.monthlyRent) || null,
    landArea: Number(values.landArea) || null,
    landUnit: values.landUnit,
    numProperties: Number(values.numProperties) || 1,
    billing: values.billing,
    addons: values.addons,
  };
}

export function estimateFor(values: RequestValues): Estimate | null {
  const input = toEstimateInput(values);
  return input ? estimate(input) : null;
}

/* ------------------------------------------------------------------ validation */

export type RequestErrors = Partial<Record<keyof RequestValues, string>>;

export const digitsOnly = (s: string) => s.replace(/\D/g, '');

export function isValidPhone(phone: string): boolean {
  const cleaned = phone.trim();
  if (!/^\+?[\d\s\-().]{7,20}$/.test(cleaned)) return false;
  const digits = digitsOnly(cleaned);
  return digits.length >= 10 && digits.length <= 15;
}

export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim());
}

/** Phone in wa.me form (digits, country code first). Assumes India for 10-digit numbers. */
export function phoneForWhatsapp(phone: string): string {
  const trimmed = phone.trim();
  let digits = digitsOnly(trimmed);
  if (trimmed.startsWith('+')) return digits;
  if (digits.startsWith('00')) return digits.slice(2);
  if (digits.length === 11 && digits.startsWith('0')) digits = digits.slice(1);
  if (digits.length === 10) return `91${digits}`;
  return digits;
}

export function validate(values: RequestValues): RequestErrors {
  const e: RequestErrors = {};
  if (values.name.trim().length < 2) e.name = 'Please enter your full name.';
  if (!values.email.trim()) e.email = 'Please enter your email so we can send your confirmation.';
  else if (!isValidEmail(values.email)) e.email = "That email address doesn't look right. Please check it.";
  if (!values.phone.trim()) e.phone = 'Please enter a phone or WhatsApp number.';
  else if (!isValidPhone(values.phone)) e.phone = 'Please enter a valid number, for example 98765 43210 or +44 7700 900123.';
  if (values.cityArea.trim().length < 2) e.cityArea = 'Please tell us the city or area of the property.';
  if (!values.propertyType) e.propertyType = 'Please choose the type of property.';
  if (!values.family) e.family = 'Please choose a plan family.';
  if (!values.planId) e.planId = 'Please choose a plan.';
  const ff = feeFamily(values);
  if (ff === 'rental') {
    const rent = Number(values.monthlyRent);
    if (!values.monthlyRent.trim()) e.monthlyRent = 'Please enter the monthly rent so we can estimate the fee.';
    else if (!(rent > 0) || rent > 10000000) e.monthlyRent = 'Please enter the rent as a number of rupees, for example 25000.';
  }
  if (ff === 'land') {
    const area = Number(values.landArea);
    if (!values.landArea.trim()) e.landArea = 'Please enter the land area.';
    else if (!(area > 0)) e.landArea = 'Please enter the area as a number, for example 2400 or 1.5.';
  }
  const n = Number(values.numProperties);
  if (!Number.isInteger(n) || n < 1 || n > 50) e.numProperties = 'Please enter a whole number between 1 and 50.';
  else if (values.family === 'portfolio' && n < 2) e.numProperties = 'Family Portfolio is for 2 or more properties.';
  if (!values.agree) e.agree = 'Please agree to the Terms & Conditions to continue.';
  return e;
}

/* ------------------------------------------------------------------ summaries */

export const propertyTypeLabel = (id: string) => PROPERTY_TYPES.find((p) => p.id === id)?.label ?? '';
export const sizeLabel = (id: string) => SIZE_OPTIONS.find((s) => s.id === id)?.label ?? '';
export const addonLabels = (ids: AddonId[]) => ids.map((id) => ADDONS.find((a) => a.id === id)?.label ?? id);

export function planHeading(values: RequestValues): string {
  const plan = planById(values.planId);
  if (!plan) return '';
  return `${familyById(plan.family).name} — ${plan.name}`;
}

/** Size, rent or area line, e.g. "3BHK or larger" or "Rent ₹25,000/month". */
export function propertyDetail(values: RequestValues): string {
  const ff = feeFamily(values);
  if (ff === 'home') return values.size ? sizeLabel(values.size) : 'Size not given';
  if (ff === 'rental') return Number(values.monthlyRent) > 0 ? `Rent ${inr(Number(values.monthlyRent))}/month` : 'Rent not given';
  if (ff === 'land') return Number(values.landArea) > 0 ? formatArea(Number(values.landArea), values.landUnit) : 'Area not given';
  return '';
}

export function propertyDetailLabel(values: RequestValues): string {
  const ff = feeFamily(values);
  return ff === 'rental' ? 'Monthly rent' : ff === 'land' ? 'Land area' : 'Property size';
}

export function numPropertiesText(n: number): string {
  return `${n} propert${n === 1 ? 'y' : 'ies'}`;
}

export interface LabelValue { label: string; value: string }

/** The owner's selections shown in the customer email. */
export function selectionLines(values: RequestValues, est: Estimate | null): LabelValue[] {
  const lines: LabelValue[] = [
    { label: 'Property type', value: propertyTypeLabel(values.propertyType) },
    { label: propertyDetailLabel(values), value: propertyDetail(values) },
    { label: 'Number of properties', value: numPropertiesText(est?.numProperties ?? (Number(values.numProperties) || 1)) },
    { label: 'Billing preference', value: BILLING_CYCLES[values.billing].label },
    { label: 'Add-ons', value: values.addons.length ? addonLabels(values.addons).join(', ') : 'None' },
  ];
  if (values.family === 'portfolio' && est) lines.splice(2, 0, { label: 'Plan for each property', value: `${familyById(est.feePlan.family).name} — ${est.feePlan.name}` });
  return lines;
}

/** Every field, for the admin notification. */
export function allFieldLines(values: RequestValues, est: Estimate | null, submittedAt: string): LabelValue[] {
  const plan = planById(values.planId);
  return [
    { label: 'Full name', value: values.name.trim() },
    { label: 'Email', value: values.email.trim() },
    { label: 'Phone / WhatsApp', value: values.phone.trim() },
    { label: 'City / area of the property', value: values.cityArea.trim() },
    { label: 'Property type', value: propertyTypeLabel(values.propertyType) },
    { label: 'Plan family', value: plan ? familyById(plan.family).name : '' },
    { label: 'Plan', value: plan ? `${plan.name} (${plan.priceLabel})` : '' },
    ...(values.family === 'portfolio' && est ? [{ label: 'Plan for each property', value: `${familyById(est.feePlan.family).name} — ${est.feePlan.name} (${est.feePlan.priceLabel})` }] : []),
    { label: propertyDetailLabel(values), value: propertyDetail(values) },
    { label: 'Number of properties', value: String(est?.numProperties ?? values.numProperties) },
    { label: 'Billing preference', value: BILLING_CYCLES[values.billing].label },
    { label: 'Add-ons', value: values.addons.length ? addonLabels(values.addons).join(', ') : 'None' },
    { label: 'Preferred contact method', value: values.contactMethod || 'Not given' },
    { label: 'Preferred contact time', value: values.contactTime || 'Not given' },
    { label: 'Owner lives', value: values.ownerLocation || 'Not given' },
    { label: 'Message / special requirements', value: values.message.trim() || '—' },
    { label: 'Agreed to Terms & Conditions', value: values.agree ? 'Yes' : 'No' },
    { label: 'Submitted', value: submittedAt },
  ];
}

/**
 * Field names stored by Netlify Forms. public/__forms.html declares the same names so
 * Netlify detects the form at deploy time — keep the two lists in sync.
 */
export const NETLIFY_FIELD_NAMES = [
  'name', 'email', 'phone', 'city_area', 'property_type', 'plan_family', 'plan', 'plan_for_each_property', 'property_detail',
  'number_of_properties', 'billing', 'addons', 'contact_method', 'contact_time', 'owner_location', 'message',
  'agreed_to_terms', 'estimate', 'submitted_at',
] as const;

export function netlifyFields(values: RequestValues, est: Estimate | null, submittedAt: string): Record<(typeof NETLIFY_FIELD_NAMES)[number], string> {
  const plan = planById(values.planId);
  return {
    name: values.name.trim(),
    email: values.email.trim(),
    phone: values.phone.trim(),
    city_area: values.cityArea.trim(),
    property_type: propertyTypeLabel(values.propertyType),
    plan_family: plan ? familyById(plan.family).name : '',
    plan: plan ? `${plan.name} (${plan.priceLabel})` : '',
    plan_for_each_property: values.family === 'portfolio' && est ? `${est.feePlan.name} (${est.feePlan.priceLabel})` : '',
    property_detail: propertyDetail(values),
    number_of_properties: String(est?.numProperties ?? values.numProperties),
    billing: BILLING_CYCLES[values.billing].label,
    addons: values.addons.length ? addonLabels(values.addons).join(', ') : 'None',
    contact_method: values.contactMethod,
    contact_time: values.contactTime,
    owner_location: values.ownerLocation,
    message: values.message.trim(),
    agreed_to_terms: values.agree ? 'Yes' : 'No',
    estimate: est?.ok ? `${inr(est.effectiveMonthly)} per month, excl. GST (${BILLING_CYCLES[values.billing].label})` : est?.missing ?? '',
    submitted_at: submittedAt,
  };
}

export function estimateHeadline(est: Estimate | null): string {
  if (!est) return '';
  if (!est.ok) return est.missing ?? '';
  return `${inr(est.effectiveMonthly)} per month`;
}

export function billedLine(est: Estimate): string {
  if (est.billing === 'monthly') return `${inr(est.billedAmount)} billed every month`;
  if (est.billing === 'quarterly') return `${inr(est.billedAmount)} billed every 3 months (5% off)`;
  return `${inr(est.billedAmount)} billed per year (pay 10 months, get 12)`;
}

/** Text for the WhatsApp fallback when the form can't be sent. Keeps the message short enough for wa.me. */
export function whatsappRequestMessage(values: RequestValues, est: Estimate | null): string {
  const lines = [
    "Hi PropCare, I tried to submit a request on your website. Here are my details:",
    `Name: ${values.name.trim()}`,
    `Phone: ${values.phone.trim()}`,
    `Email: ${values.email.trim()}`,
    `Property: ${[propertyTypeLabel(values.propertyType), values.cityArea.trim()].filter(Boolean).join(', ')}`,
  ];
  const heading = planHeading(values);
  if (heading) lines.push(`Plan: ${heading} (${planById(values.planId)!.priceLabel})`);
  const detail = propertyDetail(values);
  lines.push(`${detail ? `${detail} · ` : ''}${numPropertiesText(est?.numProperties ?? (Number(values.numProperties) || 1))} · ${BILLING_CYCLES[values.billing].label} billing`);
  if (values.addons.length) lines.push(`Add-ons: ${addonLabels(values.addons).join(', ')}`);
  if (est?.ok) lines.push(`Estimate: ${inr(est.effectiveMonthly)}/month (excl. GST)`);
  if (values.contactTime) lines.push(`Best time to call: ${values.contactTime}`);
  const msg = values.message.trim();
  if (msg) lines.push(`Message: ${msg.length > 400 ? `${msg.slice(0, 400)}…` : msg}`);
  return lines.join('\n');
}

export { plansInFamily, suggestLandPlan };
