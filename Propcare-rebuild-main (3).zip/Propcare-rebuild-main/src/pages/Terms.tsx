import { useEffect, useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { pathFor } from '../config/routes';
import { EXTERNAL_LINK, SITE, mailtoUrl, whatsappUrl } from '../config/site';
import { TERMS, TERMS_PREAMBLE, TERMS_UPDATED } from '../data/terms';
import { PageHero } from '../components/layout/Layout';
import { RefText } from '../components/ui/RefText';

/** The section whose heading was last scrolled past (first section when at the top). */
function useScrollSpy(ids: string[]): string {
  const [active, setActive] = useState(ids[0]);
  useEffect(() => {
    let frame = 0;
    const update = () => {
      frame = 0;
      const line = (document.querySelector('.site-header')?.getBoundingClientRect().height ?? 64) + 40;
      let current = ids[0];
      for (const id of ids) {
        const el = document.getElementById(id);
        if (el && el.getBoundingClientRect().top <= line) current = id;
      }
      // At the very bottom, the last section is the one being read.
      if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 4) current = ids[ids.length - 1];
      setActive(current);
    };
    const onScroll = () => { if (!frame) frame = requestAnimationFrame(update); };
    update();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => { window.removeEventListener('scroll', onScroll); window.removeEventListener('resize', onScroll); if (frame) cancelAnimationFrame(frame); };
  }, [ids]);
  return active;
}

const IDS = TERMS.map((s) => `t-${s.id}`);

export default function TermsPage() {
  const active = useScrollSpy(IDS);
  const toc = (
    <ol className="toc-list">
      {TERMS.map((section) => (
        <li key={section.id}>
          <a href={`#t-${section.id}`} aria-current={active === `t-${section.id}` ? 'true' : undefined}>
            <span className="toc-num">{section.number}</span>{section.title}
          </a>
        </li>
      ))}
    </ol>
  );
  return (
    <>
      <PageHero eyebrow="Customer terms" title={<>Terms &amp; <em>Conditions</em></>} lead={TERMS_PREAMBLE}>
        <p className="page-hero-meta"><span className="chip">Last updated {TERMS_UPDATED}</span></p>
      </PageHero>
      <section className="section" aria-label="Terms and conditions">
        <div className="container terms-layout">
          <nav className="toc" aria-label="On this page">
            <p className="toc-title">On this page</p>
            {toc}
          </nav>
          <details className="toc-mobile">
            <summary>On this page <ChevronDown aria-hidden="true" /></summary>
            {toc}
          </details>
          <article className="terms-body">
            <p className="terms-numbering">
              Clause numbers follow PropCare’s service document: <a className="ref-link" href={pathFor('packages')}>section 1</a> is plans and pricing,
              and <a className="ref-link" href={pathFor('what-we-check')}>section 2</a> is the site visit checklists.
            </p>
            {TERMS.map((section) => (
              <section key={section.id} id={`t-${section.id}`} className="terms-section" aria-labelledby={`t-${section.id}-h`}>
                <h2 id={`t-${section.id}-h`}><span className="terms-num">{section.number}</span> {section.title}</h2>
                {section.clauses.length > 1 ? (
                  <ol className="clauses">{section.clauses.map((clause, i) => <li key={i}><span><RefText text={clause} page="terms" /></span></li>)}</ol>
                ) : <p><RefText text={section.clauses[0]} page="terms" /></p>}
              </section>
            ))}
            <aside className="terms-contact card">
              <h2>Questions about these terms?</h2>
              <p>Email <a href={mailtoUrl}>{SITE.email}</a> or <a href={whatsappUrl('Hi PropCare, I have a question about your Terms & Conditions.')} {...EXTERNAL_LINK}>WhatsApp {SITE.phoneDisplay}</a>. Ready to start? <a href={pathFor('request')}>Submit a request</a>.</p>
            </aside>
          </article>
        </div>
      </section>
    </>
  );
}
