import { useState } from 'react';
import { Building2, CheckCircle2, Fence, KeyRound, ReceiptText, Users } from 'lucide-react';
import { pathFor } from '../config/routes';
import { whatsappUrl } from '../config/site';
import {
  BILLING_TERMS, ONE_TIME_CHARGES, PLAN_FAMILIES, PRICING_NOTES, RECOMMENDED_PLAN_ID, familyById, plansInFamily,
  type BillingCycleId, type FamilyId,
} from '../data/plans';
import { useHashState } from '../hooks/motion';
import { CtaBand, PageHero } from '../components/layout/Layout';
import { BillingToggle, ComparisonTable, Estimator, FamilyNote, PlanCard } from '../components/packages/PackagesParts';
import { CheckList, Reveal, TabList } from '../components/ui/primitives';

const FAMILY_ICONS: Record<FamilyId, typeof Building2> = { home: Building2, rental: KeyRound, land: Fence, portfolio: Users };
const FAMILY_IDS = PLAN_FAMILIES.map((f) => f.id);

export default function PackagesPage() {
  const [family, setFamily] = useHashState<FamilyId>(FAMILY_IDS, 'home');
  const [billing, setBilling] = useState<BillingCycleId>('monthly');
  const [estimatorPlan, setEstimatorPlan] = useState(RECOMMENDED_PLAN_ID);
  const plans = plansInFamily(family);
  const info = familyById(family);

  return (
    <>
      <PageHero eyebrow="Plans & pricing" title={<>Care plans &amp; <em>pricing</em></>}
        lead={`${PRICING_NOTES.intro} Switch the billing cycle to see what you save.`}>
        <ul className="page-hero-meta">
          <li className="chip"><ReceiptText aria-hidden="true" /> {PRICING_NOTES.perProperty}</li>
          <li className="chip"><CheckCircle2 aria-hidden="true" /> {PRICING_NOTES.vendorCosts}</li>
        </ul>
      </PageHero>

      <section className="section plans-section" aria-labelledby="plans-heading">
        <h2 id="plans-heading" className="sr-only">Plans</h2>
        {FAMILY_IDS.map((id) => <span key={id} id={id} className="anchor" aria-hidden="true" />)}
        <div className="plan-controls">
          <div className="container plan-controls-inner">
            <TabList idPrefix="fam" label="Plan family" active={family} onChange={setFamily}
              items={PLAN_FAMILIES.map((f) => { const Icon = FAMILY_ICONS[f.id]; return { id: f.id, label: f.name, icon: <Icon aria-hidden="true" /> }; })} />
            <BillingToggle value={billing} onChange={setBilling} />
          </div>
        </div>
        <div className="container">
          <div id={`fam-panel-${family}`} role="tabpanel" aria-labelledby={`fam-tab-${family}`} className="tab-panel">
            <div key={family} className="family-intro swap-in">
              <h3>{info.name} <span>— {info.audience.toLowerCase()}</span></h3>
              <p>{info.intro}</p>
            </div>
            <div key={`${family}-cards`} className={`plan-grid count-${plans.length}`}>
              {plans.map((plan, index) => <PlanCard key={plan.id} plan={plan} billing={billing} index={index} onEstimate={setEstimatorPlan} />)}
            </div>
            <FamilyNote family={family} />
            <div className="compare-block">
              <h3>Compare {info.name} plans</h3>
              <ComparisonTable family={family} />
            </div>
          </div>
        </div>
      </section>

      <section className="section section-alt" id="estimator" aria-labelledby="estimator-title">
        <div className="container">
          <Reveal className="section-head">
            <p className="eyebrow">Price estimator</p>
            <h2 id="estimator-title">Estimate your <em>monthly fee</em></h2>
            <p>Pick a plan and tell us a little about the property. The estimate updates as you go and excludes GST; we confirm the final quote on a call.</p>
          </Reveal>
          <Estimator planId={estimatorPlan} setPlanId={setEstimatorPlan} billing={billing} setBilling={setBilling} />
        </div>
      </section>

      <section className="section" aria-labelledby="charges-title">
        <div className="container charges-grid">
          <Reveal>
            <p className="eyebrow">Extras</p>
            <h2 id="charges-title">One-time and <em className="nowrap">on-demand</em> charges</h2>
            <p className="lead">For work outside your plan, or if you need us without one.</p>
          </Reveal>
          <Reveal i={1} className="table-wrap">
            <table className="data-table charges-table">
              <caption className="sr-only">One-time and on-demand charges</caption>
              <thead><tr><th scope="col">Service</th><th scope="col">Price</th></tr></thead>
              <tbody>
                {ONE_TIME_CHARGES.map((charge) => (
                  <tr key={charge.id}><th scope="row">{charge.service}</th><td>{charge.price}</td></tr>
                ))}
              </tbody>
            </table>
          </Reveal>
        </div>
      </section>

      <section className="section-tight section-alt" aria-labelledby="terms-title">
        <div className="container billing-terms">
          <Reveal>
            <h2 id="terms-title">Billing terms</h2>
            <p>Full details are in our <a href={pathFor('terms')}>Terms &amp; Conditions</a>.</p>
          </Reveal>
          <Reveal i={1}><CheckList items={BILLING_TERMS} /></Reveal>
        </div>
      </section>

      <CtaBand
        title={<>Found the right <em>plan?</em></>}
        text="Send us a request and we’ll confirm the details on a call within 1 working day."
        primary={{ label: 'Submit a Request', href: pathFor('request') }}
        secondary={{ label: 'Chat on WhatsApp', href: whatsappUrl(), whatsapp: true }}
      />
    </>
  );
}
