import { ArrowRight } from 'lucide-react';
import { NAV_ROUTES, pathFor } from '../config/routes';
import { PageHero } from '../components/layout/Layout';

export default function NotFoundPage() {
  return (
    <>
      <PageHero eyebrow="Error 404" title={<>Page not <em>found</em></>} lead="The page you’re looking for doesn’t exist or has moved. These might help:" />
      <section className="section">
        <div className="container-narrow">
          <ul className="notfound-links">
            <li><a className="link-arrow" href="/">Home <ArrowRight aria-hidden="true" /></a></li>
            {NAV_ROUTES.map((route) => <li key={route.id}><a className="link-arrow" href={route.path}>{route.nav} <ArrowRight aria-hidden="true" /></a></li>)}
            <li><a className="link-arrow" href={pathFor('request')}>Submit a Request <ArrowRight aria-hidden="true" /></a></li>
          </ul>
        </div>
      </section>
    </>
  );
}
