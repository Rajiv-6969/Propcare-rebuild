import { useEffect, useState } from 'react';
import { ArrowRight, Clock, Mail, MapPin, Navigation, Phone } from 'lucide-react';
import { pathFor } from '../config/routes';
import { EXTERNAL_LINK, SITE, bengaluruTime, mailtoUrl, telUrl, whatsappUrl } from '../config/site';
import { BILLING_TERMS } from '../data/plans';
import { CtaBand, PageHero } from '../components/layout/Layout';
import { Reveal, WhatsAppIcon } from '../components/ui/primitives';

function LocalTime() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => { const t = window.setInterval(() => setNow(new Date()), 30000); return () => window.clearInterval(t); }, []);
  return (
    <p className="local-time chip">
      <Clock aria-hidden="true" /> It’s {bengaluruTime(now)} in Bengaluru · Working hours {SITE.hours}
    </p>
  );
}

export default function ContactPage() {
  const serviceArea = BILLING_TERMS.find((t) => t.startsWith('Service area'))!.replace('Service area: ', '');
  return (
    <>
      <PageHero eyebrow="We’re here" title={<>Contact <em>us</em></>} lead="WhatsApp is the fastest way to reach us. You can also call, email, or visit the office.">
        <div className="page-hero-meta"><LocalTime /></div>
      </PageHero>
      <section className="section" aria-label="Ways to contact PropCare">
        <div className="container contact-grid">
          <Reveal className="card contact-card contact-primary" i={0}>
            <span className="icon-tile icon-wa"><WhatsAppIcon size={22} /></span>
            <h2>WhatsApp</h2>
            <p>Message us any time; we reply during working hours. Photos and documents are welcome.</p>
            <a className="btn btn-primary btn-lg" href={whatsappUrl()} {...EXTERNAL_LINK}><WhatsAppIcon size={18} /> Chat on WhatsApp</a>
            <p className="contact-detail">{SITE.phoneDisplay}</p>
            <figure className="wa-qr">
              <img src="/brand/whatsapp-qr.svg" width={132} height={132} alt="QR code that opens a WhatsApp chat with PropCare" loading="lazy" decoding="async" />
              <figcaption>On a computer? Scan with your phone’s camera to open the chat there.</figcaption>
            </figure>
          </Reveal>
          <Reveal className="card contact-card" i={1}>
            <span className="icon-tile"><Phone aria-hidden="true" /></span>
            <h2>Phone</h2>
            <p>Call during working hours, {SITE.hours}.</p>
            <a className="btn btn-secondary" href={telUrl}>Call {SITE.phoneDisplay}</a>
          </Reveal>
          <Reveal className="card contact-card" i={2}>
            <span className="icon-tile"><Mail aria-hidden="true" /></span>
            <h2>Email</h2>
            <p>For detailed questions and documents.</p>
            <a className="btn btn-secondary contact-email" href={mailtoUrl}>{SITE.email}</a>
          </Reveal>
          <Reveal className="card contact-card contact-office" i={3}>
            <span className="icon-tile"><MapPin aria-hidden="true" /></span>
            <h2>Office</h2>
            <address>{SITE.addressLines.map((line) => <span key={line}>{line}</span>)}</address>
            <a className="btn btn-secondary" href={SITE.mapsUrl} {...EXTERNAL_LINK}><Navigation aria-hidden="true" /> Get directions</a>
          </Reveal>
          <Reveal className="card contact-card contact-hours" i={4}>
            <span className="icon-tile"><Clock aria-hidden="true" /></span>
            <h2>Working hours</h2>
            <p className="contact-big">{SITE.hours}</p>
            <p>India time (IST). Requests sent outside these hours are answered on the next working day.</p>
          </Reveal>
          <Reveal className="card contact-card contact-area" i={5}>
            <span className="icon-tile"><Navigation aria-hidden="true" /></span>
            <div className="contact-area-text">
              <h2>Service area</h2>
              <p>{serviceArea.charAt(0).toUpperCase() + serviceArea.slice(1)}</p>
            </div>
            <a className="link-arrow" href={pathFor('packages')}>See plans and prices <ArrowRight aria-hidden="true" /></a>
          </Reveal>
        </div>
      </section>
      <CtaBand
        title={<>Have a question about your <em>property?</em></>}
        text="Fill out the request form and we’ll get back to you within 1 working day."
        primary={{ label: 'Submit a Request', href: pathFor('request') }}
        secondary={{ label: 'Chat on WhatsApp', href: whatsappUrl(), whatsapp: true }}
      />
    </>
  );
}
