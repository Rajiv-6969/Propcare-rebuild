import { Clock, Eye, HeartHandshake, MapPin, ShieldCheck, Zap } from 'lucide-react';
import { pathFor } from '../config/routes';
import { whatsappUrl } from '../config/site';
import { BILLING_TERMS } from '../data/plans';
import { CtaBand, PageHero } from '../components/layout/Layout';
import { Reveal } from '../components/ui/primitives';

const VALUES = [
  { icon: ShieldCheck, title: 'Trust', text: 'We do what we say, and show you what we did.' },
  { icon: Eye, title: 'Transparency', text: 'Clear updates, clear prices, and no surprises.' },
  { icon: HeartHandshake, title: 'Care', text: 'We treat every property as if it were our own.' },
  { icon: Zap, title: 'Responsiveness', text: 'When something needs attention, we move quickly.' },
];

const WHO = [
  { title: 'NRIs abroad', text: 'Your Bengaluru home or plot looked after, with reports you can read from any time zone.' },
  { title: 'Owners in other cities', text: 'Someone local to visit, check, coordinate repairs and keep the paperwork moving.' },
  { title: 'Busy owners nearby', text: 'For when you simply can’t visit as often as the property needs.' },
];

export default function AboutPage() {
  return (
    <>
      <PageHero eyebrow="Our story" title={<>About <em>PropCare</em></>} lead="We exist because properties deserve care, and owners deserve peace of mind." />
      <section className="section" aria-labelledby="problem-title">
        <div className="container editorial">
          <Reveal className="editorial-head">
            <p className="eyebrow">Why we started</p>
            <h2 id="problem-title">The problem we <em>solve</em></h2>
          </Reveal>
          <Reveal className="editorial-body prose" i={1}>
            <p>Thousands of property owners in Bengaluru face the same challenge: they own a home, flat, villa, or plot but can’t be there to look after it. They live abroad as NRIs, work in other cities, or are simply too busy to visit regularly.</p>
            <p>The result? Properties deteriorate. Leaks go unnoticed. Bills pile up. Encroachers eye vacant land. Tenants take advantage. And owners live with constant worry.</p>
            <p>PropCare becomes your eyes, ears, and hands on the ground. We visit your property regularly, document everything, handle maintenance, pay bills, manage tenants, and keep you informed.</p>
          </Reveal>
        </div>
      </section>

      <section className="section section-alt" aria-labelledby="values-title">
        <div className="container">
          <Reveal className="section-head">
            <p className="eyebrow">Our values</p>
            <h2 id="values-title">How we <em>work</em></h2>
          </Reveal>
          <ul className="values-row">
            {VALUES.map((value, index) => (
              <Reveal as="li" key={value.title} i={index} className="value-item">
                <span className="icon-tile"><value.icon aria-hidden="true" /></span>
                <h3>{value.title}</h3>
                <p>{value.text}</p>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      <section className="section" aria-labelledby="who-title">
        <div className="container who-grid">
          <Reveal>
            <p className="eyebrow">Who we serve</p>
            <h2 id="who-title">Owners who can’t <em>be there</em></h2>
            <p className="lead">Based in Anekal and serving the surrounding areas of Bengaluru.</p>
            <ul className="area-facts">
              <li><MapPin aria-hidden="true" /> {BILLING_TERMS.find((t) => t.startsWith('Service area'))}</li>
              <li><Clock aria-hidden="true" /> Visit reports with dated photos within 24 hours.</li>
            </ul>
          </Reveal>
          <ul className="who-list">
            {WHO.map((item, index) => (
              <Reveal as="li" key={item.title} i={index} className="card">
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      <CtaBand
        title={<>Let’s look after your <em>property</em></>}
        text="See the plans, or tell us about your property and we’ll suggest the right one."
        primary={{ label: 'View Packages', href: pathFor('packages') }}
        secondary={{ label: 'Chat on WhatsApp', href: whatsappUrl(), whatsapp: true }}
      />
    </>
  );
}
