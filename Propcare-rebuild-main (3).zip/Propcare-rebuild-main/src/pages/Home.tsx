import { pathFor } from '../config/routes';
import { whatsappUrl } from '../config/site';
import { CtaBand } from '../components/layout/Layout';
import { Hero } from '../components/home/Hero';
import { HealthCheck, HowItWorks, PlansTeaser, ReportsSection, ServicesIndex } from '../components/home/Sections';

export default function HomePage() {
  return (
    <>
      <Hero />
      <ServicesIndex />
      <HowItWorks />
      <ReportsSection />
      <PlansTeaser />
      <HealthCheck />
      <CtaBand
        title={<>Ready to give your property the <em>care</em> it deserves?</>}
        text="Tell us about your property and the plan you’d like. Our team will call within 1 working day to confirm details and schedule your onboarding visit."
        primary={{ label: 'Submit a Request', href: pathFor('request') }}
        secondary={{ label: 'Chat on WhatsApp', href: whatsappUrl(), whatsapp: true }}
      />
    </>
  );
}
