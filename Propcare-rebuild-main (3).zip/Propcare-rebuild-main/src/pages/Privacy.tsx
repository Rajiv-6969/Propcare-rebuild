import { pathFor } from '../config/routes';
import { SITE, mailtoUrl } from '../config/site';
import { PageHero } from '../components/layout/Layout';

export default function PrivacyPage() {
  return (
    <>
      <PageHero eyebrow="Privacy" title={<>How we use your <em>information</em></>} />
      <section className="section">
        <div className="container-narrow prose">
          <p>When you contact PropCare or submit a request, we use the details you provide to understand your property needs, respond to you, arrange a conversation and coordinate the services you ask about.</p>
          <h2>Information you share</h2>
          <p>This may include your name, email address, phone or WhatsApp number, where you live, the city or area and type of your property, its size, rent or land area, the number of properties, the plan, billing preference and add-ons you choose, your preferred contact time and anything you write in your message.</p>
          <h2>How your request is sent</h2>
          <p>The request form sends your details to PropCare and emails you a confirmation with a summary of your plan. To do this the website uses an email delivery service (EmailJS) and, where the site is hosted on Netlify, Netlify’s form service, which keeps a copy of the request for PropCare. If you choose to message us on WhatsApp, WhatsApp’s own terms apply to that chat.</p>
          <h2>Property information</h2>
          <p>Once you become a customer, our <a href={pathFor('terms')}>Terms &amp; Conditions</a> explain how we keep your personal and property information confidential, and who owns the photos and reports.</p>
          <h2>Your choices</h2>
          <p>Contact <a href={mailtoUrl}>{SITE.email}</a> to ask about information you have shared or to stop contact about a request.</p>
        </div>
      </section>
    </>
  );
}
