import { Building2, Camera, ClipboardList, Clock3, Gauge, Home, KeyRound, LandPlot } from 'lucide-react';
import { pathFor } from '../config/routes';
import { whatsappUrl } from '../config/site';
import { CHECKLISTS, CHECKLIST_INTRO, STATUS_LEGEND, checklistItemCount, type Checklist } from '../data/checklists';
import { useHashState } from '../hooks/motion';
import { CtaBand, PageHero } from '../components/layout/Layout';
import { CheckList, Reveal, StatusPill, TabList } from '../components/ui/primitives';
import { RefText } from '../components/ui/RefText';

const TAB_ICONS: Record<Checklist['id'], typeof Home> = { 'every-visit': ClipboardList, apartment: Building2, villa: Home, tenanted: KeyRound, land: LandPlot };
const IDS = CHECKLISTS.map((c) => c.id);

export default function WhatWeCheckPage() {
  const [active, setActive] = useHashState(IDS, 'every-visit');
  const list = CHECKLISTS.find((c) => c.id === active)!;
  return (
    <>
      <PageHero eyebrow="Site visit checklists" title={<>What we <em>check</em></>} lead={<RefText text={CHECKLIST_INTRO} page="what-we-check" />}>
        <ul className="page-hero-meta" aria-label="Every report includes">
          <li className="chip"><Camera aria-hidden="true" /> Dated photo for anything not OK</li>
          <li className="chip"><Clock3 aria-hidden="true" /> Report within 24 hours</li>
          <li className="chip"><Gauge aria-hidden="true" /> Health Score A/B/C/D</li>
        </ul>
      </PageHero>

      <section className="section" aria-labelledby="checklists-title">
        <div className="container">
          <div className="check-head">
            <h2 id="checklists-title" className="sr-only">Checklists by property type</h2>
            <ul className="legend legend-inline" aria-label="How each item is marked">
              {STATUS_LEGEND.map((s) => <li key={s.id}><StatusPill status={s.id} /><span>{s.description}</span></li>)}
            </ul>
          </div>
          {IDS.map((id) => <span key={id} id={id} className="anchor" aria-hidden="true" />)}
          <TabList idPrefix="wwc" label="Property type" active={active} onChange={setActive}
            items={CHECKLISTS.map((c) => { const Icon = TAB_ICONS[c.id]; return { id: c.id, label: c.tab, icon: <Icon aria-hidden="true" />, count: checklistItemCount(c) }; })} />
          <div key={list.id} id={`wwc-panel-${list.id}`} role="tabpanel" aria-labelledby={`wwc-tab-${list.id}`} tabIndex={0} className="tab-panel check-panel swap-in">
            <div className="check-panel-head">
              <h3><span className="check-num">{list.number}</span> {list.title}</h3>
              {list.note && <p><RefText text={list.note} page="what-we-check" /></p>}
              {list.id !== 'every-visit' && (
                <p className="check-reminder"><RefText text="Every visit uses the common checklist in 2.1." page="what-we-check" /></p>
              )}
            </div>
            <div className={`check-groups ${list.groups.length > 1 ? 'multi' : ''}`}>
              {list.groups.map((group, index) => (
                <section key={group.title ?? index} className="check-group" style={{ ['--i' as string]: index }} aria-label={group.title ?? list.title}>
                  {group.title && <h4>{group.title}</h4>}
                  <CheckList items={group.items} />
                </section>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="section-tight section-alt" aria-labelledby="report-title">
        <div className="container report-strip">
          <Reveal>
            <h2 id="report-title">What reaches you after a visit</h2>
          </Reveal>
          <ol className="report-steps">
            <Reveal as="li" i={0}><strong>Every item marked</strong><span>OK, Attention or Urgent, against the checklists above.</span></Reveal>
            <Reveal as="li" i={1}><strong>Dated photos</strong><span>For anything that is not OK, so you can see it for yourself.</span></Reveal>
            <Reveal as="li" i={2}><strong>Within 24 hours</strong><span>The report reaches you within a day of the visit.</span></Reveal>
            <Reveal as="li" i={3}><strong>Health Score</strong><span>One grade, A to D, for the overall condition.</span></Reveal>
          </ol>
        </div>
      </section>

      <CtaBand
        title={<>Choose how often we <em>visit</em></>}
        text="Monthly, twice a month or weekly for homes; monthly for land; quarterly or monthly inspections for rentals."
        primary={{ label: 'View Packages', href: pathFor('packages') }}
        secondary={{ label: 'Chat on WhatsApp', href: whatsappUrl(), whatsapp: true }}
      />
    </>
  );
}
