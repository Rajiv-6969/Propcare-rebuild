import { PageHero } from '../components/layout/Layout';
import { RequestForm } from '../components/request/RequestForm';
import { SITE } from '../config/site';

export default function RequestPage() {
  return (
    <>
      <PageHero eyebrow="Get started" title={<>Submit a <em>request</em></>}
        lead={`Tell us about your property and the plan you’d like. You’ll get a confirmation email, and our team will call within 1 working day (${SITE.hours}).`} />
      <section className="section request-section" aria-label="Request form">
        <div className="container">
          <RequestForm />
        </div>
      </section>
    </>
  );
}
