import { ArrowRight, ClipboardCheck, Droplets, Fence, KeyRound, ReceiptText, Wrench } from 'lucide-react';
import { pathFor } from '../config/routes';
import { whatsappUrl } from '../config/site';
import { CHECKLISTS } from '../data/checklists';
import { familyById } from '../data/plans';
import { SERVICES } from '../data/services';
import { HowItWorks } from '../components/home/Sections';
import { CtaBand, PageHero } from '../components/layout/Layout';
import { CheckList, Reveal } from '../components/ui/primitives';

const ICONS: Record<string, typeof ClipboardCheck> = { inspections: ClipboardCheck, cleaning: Droplets, repairs: Wrench, tenants: KeyRound, bills: ReceiptText, plots: Fence };

export default function ServicesPage() {
  return (
    <>
      <PageHero eyebrow="What we do" title={<>Our <em>services</em></>} lead="Everything your property needs to stay healthy, handled by one local team that reports back after every visit." />
      <section className="section" aria-label="Services">
        <div className="container service-grid">
          {SERVICES.map((service, index) => {
            const Icon = ICONS[service.id] ?? ClipboardCheck;
            const checklist = CHECKLISTS.find((c) => c.id === service.checklist);
            return (
              <Reveal as="article" key={service.id} id={service.id} i={index % 2} className="card service-card" aria-labelledby={`${service.id}-title`}>
                <span className="icon-tile"><Icon aria-hidden="true" /></span>
                <h2 id={`${service.id}-title`}>{service.title}</h2>
                <p className="service-summary">{service.summary}</p>
                <CheckList items={service.details} compact />
                <div className="service-links">
                  <a className="link-arrow" href={`${pathFor('packages')}#${service.family}`}>{familyById(service.family).name} plans <ArrowRight aria-hidden="true" /></a>
                  {checklist && <a className="link-arrow" href={`${pathFor('what-we-check')}#${checklist.id}`}>What we check <ArrowRight aria-hidden="true" /></a>}
                </div>
              </Reveal>
            );
          })}
        </div>
      </section>
      <div className="section-alt"><HowItWorks id="services-how" /></div>
      <CtaBand
        title={<>Not sure which service you <em>need?</em></>}
        text="Tell us about the property. We’ll suggest the right plan and explain exactly what’s included."
        primary={{ label: 'Submit a Request', href: pathFor('request') }}
        secondary={{ label: 'Chat on WhatsApp', href: whatsappUrl(), whatsapp: true }}
      />
    </>
  );
}
