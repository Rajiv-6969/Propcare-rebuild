import { useCallback, useEffect, useRef, useState, type RefObject } from 'react';

export function prefersReducedMotion(): boolean {
  return typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

export function usePrefersReducedMotion(): boolean {
  const [reduced, setReduced] = useState(prefersReducedMotion);
  useEffect(() => {
    const media = window.matchMedia('(prefers-reduced-motion: reduce)');
    const update = () => setReduced(media.matches);
    media.addEventListener('change', update);
    return () => media.removeEventListener('change', update);
  }, []);
  return reduced;
}

/*
 * Elements still waiting to animate in. The IntersectionObserver only reports threshold
 * crossings, so if the visitor jumps past an element (anchor link, End key, fast fling) it
 * would stay hidden. A cheap rAF-throttled sweep reveals anything already above the viewport.
 */
const waiting = new Map<Element, () => void>();
let sweepFrame = 0;
function sweepPassed() {
  sweepFrame = 0;
  for (const [el, done] of waiting) {
    if (!el.isConnected) { waiting.delete(el); continue; }
    if (el.getBoundingClientRect().bottom < 0) { waiting.delete(el); done(); }
  }
  if (!waiting.size) window.removeEventListener('scroll', onSweepScroll);
}
function onSweepScroll() { if (!sweepFrame) sweepFrame = requestAnimationFrame(sweepPassed); }
function waitFor(el: Element, done: () => void) {
  if (!waiting.size) window.addEventListener('scroll', onSweepScroll, { passive: true });
  waiting.set(el, done);
}
function stopWaiting(el: Element) { waiting.delete(el); }

/* One shared observer for every [data-reveal] element. */
let revealObserver: IntersectionObserver | null = null;
function reveal(el: Element) {
  el.classList.add('is-visible');
  revealObserver?.unobserve(el);
  stopWaiting(el);
}
function getRevealObserver(): IntersectionObserver | null {
  if (typeof window === 'undefined' || !('IntersectionObserver' in window)) return null;
  if (!revealObserver) {
    revealObserver = new IntersectionObserver((entries) => {
      for (const entry of entries) if (entry.isIntersecting) reveal(entry.target);
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.12 });
  }
  return revealObserver;
}

/** Ref callback: fades and lifts the element in the first time it scrolls into view. */
export function useReveal<T extends Element>() {
  return useCallback((node: T | null) => {
    if (!node) return;
    const observer = getRevealObserver();
    if (!observer || prefersReducedMotion()) { node.classList.add('is-visible'); return; }
    observer.observe(node);
    waitFor(node, () => reveal(node));
  }, []);
}

/** True once the element has been on screen (stays true). */
export function useInView<T extends Element>(ref: RefObject<T>, options: IntersectionObserverInit = { threshold: 0.3 }): boolean {
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const node = ref.current;
    if (!node || seen) return;
    if (!('IntersectionObserver' in window)) { setSeen(true); return; }
    const io = new IntersectionObserver(([entry]) => { if (entry.isIntersecting) { setSeen(true); io.disconnect(); stopWaiting(node); } }, options);
    io.observe(node);
    waitFor(node, () => { setSeen(true); io.disconnect(); });
    return () => { io.disconnect(); stopWaiting(node); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ref, seen]);
  return seen;
}

/** Toggles .is-paused on an element while it is off screen (pauses ambient CSS loops). */
export function usePauseOffscreen<T extends Element>(ref: RefObject<T>) {
  useEffect(() => {
    const node = ref.current;
    if (!node || !('IntersectionObserver' in window)) return;
    const io = new IntersectionObserver(([entry]) => node.classList.toggle('is-paused', !entry.isIntersecting));
    io.observe(node);
    return () => io.disconnect();
  }, [ref]);
}

export function useScrolled(threshold = 8): boolean {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    let frame = 0;
    const read = () => { frame = 0; setScrolled(window.scrollY > threshold); };
    const onScroll = () => { if (!frame) frame = requestAnimationFrame(read); };
    read();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => { window.removeEventListener('scroll', onScroll); if (frame) cancelAnimationFrame(frame); };
  }, [threshold]);
  return scrolled;
}

const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3);

/** Smoothly animates a number towards `target` (instant under reduced motion). */
export function useTweenedNumber(target: number, duration = 450): number {
  const [value, setValue] = useState(target);
  const fromRef = useRef(target);
  const frameRef = useRef(0);
  useEffect(() => {
    const from = fromRef.current;
    if (from === target || prefersReducedMotion()) { fromRef.current = target; setValue(target); return; }
    const start = performance.now();
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      const next = from + (target - from) * easeOutCubic(t);
      fromRef.current = next;
      setValue(next);
      if (t < 1) frameRef.current = requestAnimationFrame(tick);
      else fromRef.current = target;
    };
    cancelAnimationFrame(frameRef.current);
    frameRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frameRef.current);
  }, [target, duration]);
  return value;
}

/** Counts up from 0 to `target` once `active` becomes true. */
export function useCountUp(target: number, active: boolean, duration = 600): number {
  const [value, setValue] = useState(0);
  useEffect(() => {
    if (!active) return;
    if (prefersReducedMotion()) { setValue(target); return; }
    let frame = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      setValue(Math.round(target * easeOutCubic(t)));
      if (t < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [active, target, duration]);
  return value;
}

/**
 * Pages are rendered in the browser, so when a page opens at /terms.html#t-tenanted the browser's own
 * jump to that section happens before the section exists. Do the jump once after the first render.
 * It is instant (no smooth scroll on page load); html's scroll-padding keeps it clear of the header.
 */
export function useInitialHashScroll(): void {
  useEffect(() => {
    const id = decodeURIComponent(window.location.hash.slice(1));
    if (!id || id === 'main') return;
    const frame = requestAnimationFrame(() => {
      document.getElementById(id)?.scrollIntoView({ block: 'start', behavior: 'instant' });
    });
    return () => cancelAnimationFrame(frame);
  }, []);
}

/** Keeps a tab id in sync with location.hash (e.g. /what-we-check.html#villa). */
export function useHashState<T extends string>(ids: readonly T[], fallback: T): [T, (id: T) => void] {
  const read = () => {
    const hash = decodeURIComponent(window.location.hash.replace('#', '')) as T;
    return ids.includes(hash) ? hash : fallback;
  };
  const [active, setActive] = useState<T>(read);
  useEffect(() => {
    // Only react to hashes that name a tab, so other anchors (e.g. #estimator) keep the current tab.
    const onHash = () => {
      const hash = decodeURIComponent(window.location.hash.replace('#', '')) as T;
      if (ids.includes(hash)) setActive(hash);
    };
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const update = useCallback((id: T) => {
    setActive(id);
    history.replaceState(null, '', `${window.location.pathname}${window.location.search}#${id}`);
  }, []);
  return [active, update];
}
