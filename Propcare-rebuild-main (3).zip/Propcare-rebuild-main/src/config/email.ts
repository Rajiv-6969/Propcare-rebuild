/**
 * EmailJS settings for the "Submit a Request" confirmation emails.
 *
 * Fill these in through environment variables (see .env.example and EMAIL_SETUP.md):
 *   VITE_EMAILJS_SERVICE_ID, VITE_EMAILJS_PUBLIC_KEY,
 *   VITE_EMAILJS_TEMPLATE_CUSTOMER, VITE_EMAILJS_TEMPLATE_ADMIN
 *
 * The EmailJS public key is designed to be used in browser code; it is not a secret.
 * Never put the EmailJS *private* key in this project.
 */
const env = import.meta.env;

export const EMAILJS = {
  endpoint: 'https://api.emailjs.com/api/v1.0/email/send',
  serviceId: (env.VITE_EMAILJS_SERVICE_ID as string | undefined) || 'YOUR_EMAILJS_SERVICE_ID',
  publicKey: (env.VITE_EMAILJS_PUBLIC_KEY as string | undefined) || 'YOUR_EMAILJS_PUBLIC_KEY',
  customerTemplateId: (env.VITE_EMAILJS_TEMPLATE_CUSTOMER as string | undefined) || 'YOUR_CUSTOMER_TEMPLATE_ID',
  adminTemplateId: (env.VITE_EMAILJS_TEMPLATE_ADMIN as string | undefined) || 'YOUR_ADMIN_TEMPLATE_ID',
} as const;

export function isEmailConfigured(): boolean {
  return [EMAILJS.serviceId, EMAILJS.publicKey, EMAILJS.customerTemplateId, EMAILJS.adminTemplateId].every((value) => value && !value.startsWith('YOUR_'));
}

/** Netlify Forms keeps a copy of every request in the Netlify dashboard (works only on Netlify). */
export const NETLIFY_FORM_NAME = 'property-request';
