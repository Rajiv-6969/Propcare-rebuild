/**
 * Brand facts used everywhere on the site and in the confirmation emails.
 * Change a phone number, address or hour here and every page, link and email follows.
 */
export const SITE = {
  name: 'PropCare',
  legalName: 'PropCare Private Limited',
  tagline: 'Healthy Properties Happy Owners',
  phoneDisplay: '+91 77602 73587',
  /** Digits only, country code first, no "+", spaces or leading 0. This is what wa.me expects. */
  whatsappNumber: '917760273587',
  /** E.164 form for tel: links. */
  phoneE164: '+917760273587',
  email: 'propcare.admin@gmail.com',
  address: 'Plot # 6, Nandi Garden, Haldenahalli, Anekal, Bangalore - 562106',
  addressLines: ['Plot # 6, Nandi Garden', 'Haldenahalli, Anekal', 'Bangalore - 562106'],
  mapsUrl: 'https://www.google.com/maps/search/?api=1&query=Plot+6+Nandi+Garden+Haldenahalli+Anekal+Bangalore+562106',
  hours: '10 AM – 5 PM',
  /** Working hours in Asia/Kolkata, 24h clock. */
  openHour: 10,
  closeHour: 17,
  /** Production URL used for canonical/OG tags at build time. Override with VITE_SITE_URL. */
  url: (import.meta.env.VITE_SITE_URL as string | undefined)?.replace(/\/$/, '') || 'https://propcare-bengaluru.netlify.app',
} as const;

export const DEFAULT_WHATSAPP_MESSAGE = "Hi PropCare, I'm interested in your property care services.";

/**
 * The one place WhatsApp links are built.
 * Format: https://wa.me/<digits only>?text=<encodeURIComponent(message)>
 * Works on Android/iOS (opens the app) and desktop (WhatsApp Web / Desktop).
 */
export function whatsappUrl(message: string = DEFAULT_WHATSAPP_MESSAGE): string {
  const text = message.trim();
  return `https://wa.me/${SITE.whatsappNumber}${text ? `?text=${encodeURIComponent(text)}` : ''}`;
}

export function planWhatsappMessage(planName: string): string {
  return `Hi PropCare, I'm interested in the ${planName} plan.`;
}

export const telUrl = `tel:${SITE.phoneE164}`;
export const mailtoUrl = `mailto:${SITE.email}`;

/** Attributes every external WhatsApp link should carry. */
export const EXTERNAL_LINK = { target: '_blank', rel: 'noopener noreferrer' } as const;

/** Current time in Bengaluru, e.g. "4:05 pm" — handy for owners abroad. */
export function bengaluruTime(now: Date = new Date()): string {
  return new Intl.DateTimeFormat('en-IN', { timeZone: 'Asia/Kolkata', hour: 'numeric', minute: '2-digit', hour12: true }).format(now);
}

/** Is it currently within working hours (10 AM – 5 PM) in Bengaluru? Days are not checked. */
export function withinWorkingHours(now: Date = new Date()): boolean {
  const hour = Number(new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Kolkata', hour: 'numeric', hour12: false }).format(now));
  return hour >= SITE.openHour && hour < SITE.closeHour;
}
