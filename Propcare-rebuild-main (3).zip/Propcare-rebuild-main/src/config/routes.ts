/**
 * Route table: one entry per page. Used by the app (navigation, page lookup) and by
 * vite.config.ts, which writes a real HTML file per route with its own <title>,
 * description, canonical and Open Graph tags. Keep this file free of browser-only code.
 */
export type RouteId = 'home' | 'about' | 'services' | 'what-we-check' | 'packages' | 'request' | 'contact' | 'terms' | 'privacy' | 'not-found';

export interface RouteMeta {
  id: RouteId;
  path: string;
  /** HTML file written at build time. */
  file: string;
  title: string;
  description: string;
  /** Label in the main navigation (omit to keep it out of the nav). */
  nav?: string;
  /** Include in sitemap.xml */
  sitemap: boolean;
  priority?: number;
}

export const ROUTES: RouteMeta[] = [
  {
    id: 'home', path: '/', file: 'index.html', sitemap: true, priority: 1,
    title: 'PropCare | Property Care in Bengaluru – Healthy Properties Happy Owners',
    description: 'PropCare looks after homes, rentals and land in and around Anekal, Bengaluru: scheduled visits, dated photo reports within 24 hours and a Property Health Score.',
  },
  {
    id: 'about', path: '/about.html', file: 'about.html', nav: 'About Us', sitemap: true, priority: 0.7,
    title: 'About PropCare | Property Care for Owners Away from Bengaluru',
    description: 'Why PropCare exists: owners in other cities and countries need trusted eyes, ears and hands on the ground for their Bengaluru property.',
  },
  {
    id: 'services', path: '/services.html', file: 'services.html', nav: 'Services', sitemap: true, priority: 0.8,
    title: 'Services | Inspections, Repairs, Tenants & Land Watch | PropCare',
    description: 'Property inspections, repairs coordination, tenant support, bill and tax reminders, and vacant land watch around Anekal, Bengaluru.',
  },
  {
    id: 'what-we-check', path: '/what-we-check.html', file: 'what-we-check.html', nav: 'What We Check', sitemap: true, priority: 0.8,
    title: 'What We Check | PropCare Site Visit Checklists',
    description: 'The checklists PropCare inspectors follow on every visit to apartments, villas, tenanted homes and vacant land, with OK, Attention and Urgent ratings.',
  },
  {
    id: 'packages', path: '/packages.html', file: 'packages.html', nav: 'Packages', sitemap: true, priority: 0.9,
    title: 'Packages & Pricing | Home Care, Rental Care, Land Watch | PropCare',
    description: 'PropCare plans for homes, rentals and land: Home Care, Rental Care, Land Watch and Family Portfolio discounts, with savings on quarterly and annual billing.',
  },
  {
    id: 'request', path: '/request.html', file: 'request.html', sitemap: true, priority: 0.9,
    title: 'Submit a Request | PropCare Bengaluru',
    description: 'Tell PropCare about your property and the plan you want. You will get a confirmation email and a call within 1 working day.',
  },
  {
    id: 'contact', path: '/contact.html', file: 'contact.html', nav: 'Contact Us', sitemap: true, priority: 0.7,
    title: 'Contact PropCare | WhatsApp, Phone & Office in Anekal',
    description: 'WhatsApp, call or email PropCare, or visit our office in Haldenahalli, Anekal, Bengaluru. Reach the team during working hours, 10 AM to 5 PM.',
  },
  {
    id: 'terms', path: '/terms.html', file: 'terms.html', sitemap: true, priority: 0.4,
    title: 'Terms & Conditions | PropCare',
    description: 'The terms that apply to every PropCare plan and one-time service: scope, fees, repairs and approvals, emergencies, tenancies, liability and cancellation.',
  },
  {
    id: 'privacy', path: '/privacy.html', file: 'privacy.html', sitemap: true, priority: 0.3,
    title: 'Privacy | PropCare',
    description: 'How PropCare uses the information you share through its website and request form.',
  },
  {
    id: 'not-found', path: '/404.html', file: '404.html', sitemap: false,
    title: 'Page not found | PropCare',
    description: 'This page does not exist. Find PropCare plans, services and contact details here.',
  },
];

export const NAV_ROUTES = ROUTES.filter((route) => route.nav);

export function routeFor(pathname: string): RouteMeta {
  const clean = pathname.replace(/\/+$/, '') || '/';
  const withHtml = clean === '/' ? '/' : clean.endsWith('.html') ? clean : `${clean}.html`;
  if (withHtml === '/index.html') return ROUTES[0];
  return ROUTES.find((route) => route.path === withHtml) ?? ROUTES[ROUTES.length - 1];
}

export function pathFor(id: RouteId): string {
  return ROUTES.find((route) => route.id === id)?.path ?? '/';
}
