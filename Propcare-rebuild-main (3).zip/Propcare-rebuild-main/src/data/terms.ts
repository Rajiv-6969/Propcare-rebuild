/**
 * Customer Terms & Conditions, word for word from section 3 of the owner's document
 * "PropCare — Pricing, Site Visit Checklists & Terms and Conditions" (28 Sep 2026).
 * Clause numbers match that document so customers and staff can refer to the same numbers,
 * e.g. "clause 3.5". Cross-references ("section 1", "under 3.5") become links on the Terms page.
 */
export const TERMS_UPDATED = '28 September 2026';

export const TERMS_PREAMBLE =
  'These terms apply to every owner ("Owner") who subscribes to a PropCare plan or buys a one-time service.';

/*
 * In the document the preamble continues: "This draft should be reviewed by a lawyer before use;
 * it is a working template, not legal advice." That is a note to PropCare, not a customer term,
 * so it is deliberately not published on the website.
 */

export interface TermsSection { id: string; number: string; title: string; clauses: string[] }

export const TERMS: TermsSection[] = [
  { id: 'scope', number: '3.1', title: 'Scope of service', clauses: [
    'PropCare provides only the services listed under the plan the Owner has chosen (section 1). Anything else is quoted and agreed in writing before it starts.',
    "PropCare acts as the Owner's representative for inspection, coordination and reporting. It does not own, insure or guarantee the property.",
    'Legal, title, tax and valuation matters are referred to qualified professionals. PropCare does not give legal or tax advice.',
  ] },
  { id: 'onboarding', number: '3.2', title: 'Onboarding and authorisation', clauses: [
    "The Owner provides proof of ownership (or the owner's written authority), ID proof, and copies of key documents before service starts.",
    'The Owner hands over keys, access cards or society authorisation letters needed for visits. PropCare records the number of keys received and returns them when the service ends.',
    "Where PropCare pays bills or deals with authorities on the Owner's behalf, the Owner signs a letter of authorisation covering those tasks only.",
  ] },
  { id: 'fees', number: '3.3', title: 'Fees and payment', clauses: [
    'Fees are as per the chosen plan and are payable in advance for the billing period (monthly, quarterly or annual).',
    'GST is charged as applicable.',
    'Invoices are due within 7 days. If payment is more than 15 days late, PropCare may pause visits until it is received, after informing the Owner.',
    "Fees may be revised once a year with 30 days' written notice. Prepaid periods are not affected.",
    'The minimum commitment is 3 months.',
  ] },
  { id: 'repairs', number: '3.4', title: 'Repairs, vendors and approvals', clauses: [
    'All repair and vendor costs are paid by the Owner at actuals and are separate from the plan fee.',
    "PropCare sends a quote with photos before any work. No work starts without the Owner's written approval (WhatsApp or email is enough), except in an emergency under 3.5.",
    'The Owner may set a standing approval limit (for example, ₹2,000). Work below that limit may go ahead and is reported afterwards.',
    "The Owner may use their own vendor. PropCare will coordinate access but is not responsible for that vendor's work.",
    "Vendors arranged by PropCare are verified, but their work is guaranteed only to the extent of the vendor's own warranty. PropCare will follow up on defects on the Owner's behalf.",
    'For repair and maintenance work, PropCare keeps a spending advance from the Owner or bills at actuals with vendor invoices attached.',
  ] },
  { id: 'emergencies', number: '3.5', title: 'Emergencies', clauses: [
    'An emergency is a situation causing immediate damage or risk: a burst pipe, fire, break-in, electrical hazard or structural danger.',
    'PropCare will act to limit damage (shut water or power, secure the property, call a vendor or the authorities) and inform the Owner as soon as possible.',
    'Emergency spending without prior approval is capped at ₹5,000 unless the Owner agrees otherwise.',
  ] },
  { id: 'tenanted', number: '3.6', title: 'Tenanted properties', clauses: [
    "Visits to tenanted homes are made with at least 24 hours' notice to the tenant, except in an emergency.",
    "PropCare collects rent on the Owner's behalf only if the Owner chooses that option in writing; otherwise rent goes directly to the Owner.",
    "The tenancy agreement is between the Owner and the tenant. PropCare is not liable for unpaid rent, damage by the tenant, or the tenant's conduct, but will follow up and document on the Owner's behalf.",
    'Security deposits are held by the Owner unless both parties agree in writing that PropCare holds them.',
  ] },
  { id: 'reports', number: '3.7', title: 'Reports and records', clauses: [
    'PropCare sends a visit report with dated photos within 24 hours of each scheduled visit.',
    'Reports record the condition seen on the day of the visit. They are not a structural survey or a guarantee of condition between visits.',
    'Documents in the Digital Property Passport are stored securely and shared only with the Owner and people the Owner authorises.',
  ] },
  { id: 'liability', number: '3.8', title: 'Limitation of liability', clauses: [
    'PropCare is not liable for loss or damage caused by natural events, theft, acts of third parties, hidden defects, or anything that happens between scheduled visits, where PropCare has followed this agreement.',
    'PropCare is not responsible for encroachment or disputes over land, but will report what it sees and help the Owner collect evidence.',
    "PropCare's total liability in any case is limited to the plan fees paid by the Owner in the previous 3 months.",
    'PropCare is responsible for loss or damage caused directly by the negligence or misconduct of its own staff.',
  ] },
  { id: 'owner', number: '3.9', title: 'Owner responsibilities', clauses: [
    'Keep property tax, society dues, utility connections and insurance in their own name and up to date, unless PropCare is paying them under the plan.',
    'Give accurate information about the property, including any known disputes, defects or legal issues.',
    'Respond to approval requests within a reasonable time. Delays in approval may delay repairs.',
    'Tell PropCare about any change in ownership, tenancy or contact details.',
  ] },
  { id: 'cancellation', number: '3.10', title: 'Cancellation and termination', clauses: [
    "Either side may end the service with 30 days' written notice after the minimum 3-month period.",
    'On annual plans, a cancelled plan is refunded for full unused months, minus the value of the free months already used and any waived onboarding fee.',
    'PropCare may end the service immediately if fees remain unpaid for 30 days, if the Owner asks for anything unlawful, or if the property becomes unsafe to visit.',
    'When service ends, PropCare returns all keys and documents within 7 days and settles any balance of the spending advance with a statement.',
  ] },
  { id: 'confidentiality', number: '3.11', title: 'Confidentiality and data', clauses: [
    "PropCare keeps the Owner's personal and property information confidential and uses it only to provide the service.",
    "Photos and reports belong to the Owner. PropCare may use photos without identifying details (no address, name or number plates) for training or marketing only with the Owner's consent.",
  ] },
  { id: 'disputes', number: '3.12', title: 'Disputes and governing law', clauses: [
    'Complaints go first to the PropCare office (propcare.admin@gmail.com, 7760273587), which will respond within 7 working days.',
    'Unresolved disputes are settled by discussion, then by mediation, before any legal action.',
    'These terms are governed by the laws of India, with courts in Bengaluru having jurisdiction.',
  ] },
  { id: 'acceptance', number: '3.13', title: 'Acceptance', clauses: [
    'The Owner accepts these terms by signing the service agreement, paying the first invoice, or confirming in writing (including by email or WhatsApp).',
  ] },
];

/** "3.6" -> "t-tenanted" (the id of that section on the Terms page), or null. */
export function termsAnchor(number: string): string | null {
  const section = TERMS.find((s) => s.number === number);
  return section ? `t-${section.id}` : null;
}
