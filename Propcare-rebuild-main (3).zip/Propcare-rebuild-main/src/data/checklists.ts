/**
 * Site visit checklists ("What We Check"), word for word from section 2 of the owner's document
 * "PropCare — Pricing, Site Visit Checklists & Terms and Conditions" (28 Sep 2026).
 * Section numbers (2.1–2.5) match that document, so references such as "everything in 2.2"
 * and "see 3.6" (Terms & Conditions) keep working; the What We Check page turns them into links.
 */
export const CHECKLIST_INTRO =
  'Every visit uses the common checklist in 2.1, then the list for the property type. Tick OK, Attention or Urgent for each item, with a dated photo for anything not OK. The report goes to the owner within 24 hours of the visit.';

export const STATUS_LEGEND = [
  { id: 'ok', label: 'OK', description: 'Checked and in order' },
  { id: 'attention', label: 'Attention', description: 'Needs a look soon, with a dated photo' },
  { id: 'urgent', label: 'Urgent', description: 'Needs action now, with a dated photo' },
] as const;

export interface ChecklistGroup { title?: string; items: string[] }
export interface Checklist {
  id: 'every-visit' | 'apartment' | 'villa' | 'tenanted' | 'land';
  /** Section number in the owner's document. */
  number: string;
  tab: string;
  title: string;
  note?: string;
  groups: ChecklistGroup[];
}

export const CHECKLISTS: Checklist[] = [
  {
    id: 'every-visit', number: '2.1', tab: 'Every visit', title: 'Common to every visit',
    groups: [{ items: [
      'Record date, time of arrival and departure, and GPS location',
      'Photograph the property from the approach road and the main entrance',
      'Check locks, keys and entry points; note any sign of forced entry',
      'Check for notices, posters or letters on the gate or door; photograph and collect them',
      'Note any new construction, dumping or activity next to the property',
      'Confirm nobody is occupying or using the property without permission',
      'Speak to the security guard, society office or a neighbour if anything looks unusual',
      'Lock up and photograph the locked door or gate before leaving',
    ] }],
  },
  {
    id: 'apartment', number: '2.2', tab: 'Apartment', title: 'Apartment / flat',
    groups: [
      { title: 'Entry and common area', items: [
        'Main door, lock, peephole, doorbell',
        'Maintenance dues and notices from the society',
        'Parking slot: unused, clean, not occupied by others',
      ] },
      { title: 'Water and plumbing', items: [
        'Open every tap for 1–2 minutes; check flow and colour of water',
        "Flush every toilet; pour water into floor drains so traps don't dry out",
        'Check under sinks, behind toilets and at the geyser for drips',
        'Damp patches, seepage or peeling paint on walls and ceilings (bathrooms, shared walls)',
        'Water meter reading (if any)',
      ] },
      { title: 'Electrical', items: [
        'Electricity meter reading',
        'Switch on each light and fan briefly; test the MCB/RCCB trip switch',
        'Sockets and switchboards: burn marks or loose fittings',
        'Switch off geyser and non-essential circuits before leaving',
      ] },
      { title: 'Interior condition', items: [
        'Windows, grills and balcony doors closed and intact; no broken glass',
        'Pests: termites (mud tubes, hollow wood), cockroaches, rodents, bird nests',
        'Mould, dust or musty smell; air the home for 15–20 minutes',
        'Wardrobes, kitchen cabinets and wooden doors',
        'Fridge, AC and other appliances as agreed with the owner',
      ] },
    ],
  },
  {
    id: 'villa', number: '2.3', tab: 'Villa', title: 'Villa / independent house',
    note: 'Complete everything in 2.2, plus:',
    groups: [
      { title: 'Outside and structure', items: [
        'Compound wall, gate and gate hinges',
        'Cracks in outer walls, columns, sunshades and staircase',
        'Terrace: waterproofing, blocked rainwater drains, plants growing in cracks',
        'Overhead tank and sump: lid locked, water level, cleanliness',
        'Borewell and motor: run briefly if agreed with the owner',
        'Septic tank / drainage chamber covers in place, no overflow',
      ] },
      { title: 'Garden and surroundings', items: [
        'Weeds, overgrown trees touching walls or wires',
        'Stagnant water (mosquito risk)',
        'Snakes or rodent burrows near the compound',
        'Street light and outside lights working',
      ] },
    ],
  },
  {
    id: 'tenanted', number: '2.4', tab: 'Tenanted', title: 'Tenanted home',
    note: "Done with at least 24 hours' notice to the tenant (see 3.6). Complete the relevant items in 2.2 or 2.3, plus:",
    groups: [
      { title: 'Every visit', items: [
        'Number of occupants matches the rental agreement',
        'Used only for residence; no subletting or commercial use',
        'Changes made without permission (nails, fixtures, painting, extra locks)',
        'Damage beyond normal wear and tear, with photos',
        'Pending tenant complaints logged as maintenance requests',
        'Utility bills and society dues paid up to date',
        'Pets present and whether the agreement allows them',
      ] },
      { title: 'Move-in and move-out visits only', items: [
        'Room-by-room photos and video, with meter readings',
        'Inventory of fittings, furniture and appliances, signed by the tenant',
        'Keys handed over or returned, with count',
        'Move-out: list of deposit deductions, with photos',
      ] },
    ],
  },
  {
    id: 'land', number: '2.5', tab: 'Land', title: 'Vacant land / plot',
    groups: [{ items: [
      'GPS-tagged photos from all four corners and the centre of the plot',
      "Boundary stones present and in place; compare with last visit's photos",
      'Fence, compound wall and gate intact',
      "Owner's name board present and readable",
      'No encroachment: new structures, sheds, footpaths, cattle, crops or parked vehicles',
      'No construction material, garbage or debris dumped',
      'Weeds, shrubs or trees needing clearing; fire risk in summer',
      'Water logging or soil erosion after rain',
      'Changes around the plot: new roads, layouts, neighbouring construction',
      'Anyone asking about the plot or claiming ownership (report to owner same day)',
    ] }],
  },
];

export const checklistItemCount = (list: Checklist): number => list.groups.reduce((sum, g) => sum + g.items.length, 0);
