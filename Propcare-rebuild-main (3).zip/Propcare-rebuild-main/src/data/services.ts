import { oneTimeCharge, PRICING_NOTES } from './plans';
import type { FamilyId } from './plans';

export interface Service {
  id: string;
  title: string;
  summary: string;
  details: string[];
  family: FamilyId;
  checklist?: string;
}

export const SERVICES: Service[] = [
  {
    id: 'inspections', title: 'Property Inspections', family: 'home', checklist: 'every-visit',
    summary: 'Regular visits with dated photo and video reports, so you always know what is happening.',
    details: [
      'A written checklist on every visit, each item marked OK, Attention or Urgent',
      'Dated photo report within 24 hours, with video on Care Plus and Premium',
      'Visits monthly, twice a month or weekly, depending on your plan',
      'A Property Health Score (A/B/C/D) yearly, quarterly or monthly',
    ],
  },
  {
    id: 'cleaning', title: 'Cleaning & Upkeep', family: 'home', checklist: 'apartment',
    summary: 'Taps run, drains flushed and the home aired on every visit, so it stays healthy while empty.',
    details: [
      'Run taps, flush drains, air out the home and check for leaks on every Home Care plan',
      'Light cleaning and dusting once a month on Premium',
      'Deeper cleaning arranged with vendors when you need it',
      PRICING_NOTES.vendorCosts,
    ],
  },
  {
    id: 'repairs', title: 'Repairs & Maintenance', family: 'home', checklist: 'villa',
    summary: 'Plumbing, electrical, painting and carpentry coordinated with verified vendors.',
    details: [
      'A quote with photos before any work; nothing starts without your written approval',
      `Small repairs: ${oneTimeCharge('small-repairs').price.charAt(0).toLowerCase()}${oneTimeCharge('small-repairs').price.slice(1)}`,
      `Large works: ${oneTimeCharge('large-works').price}`,
      'Repair response within 72, 48 or 24 hours, depending on your plan',
    ],
  },
  {
    id: 'tenants', title: 'Tenant Support', family: 'rental', checklist: 'tenanted',
    summary: 'Tenant placement, rent follow-up and move-in and move-out inspections.',
    details: [
      PRICING_NOTES.tenantPlacement,
      'Rent tracking, follow-up with late payers and agreement renewal reminders',
      'Police verification, agreement drafting and deposit settlement on Full Rental Management',
      'TDS-on-rent support for NRI owners',
    ],
  },
  {
    id: 'bills', title: 'Bill & Tax Payments', family: 'home',
    summary: 'Property tax, electricity, water and society dues tracked, and paid for you if you wish.',
    details: [
      'Utility and property-tax due-date reminders on every Home Care plan',
      "Bill payment on your behalf, at actual cost, on Care Plus and Premium",
      'Khata and property-tax reminders for plots and land',
      `Paperwork tasks (khata transfer, e-khata, tax payment, certificates): ${oneTimeCharge('paperwork').price}`,
    ],
  },
  {
    id: 'plots', title: 'Plot & Land Care', family: 'land', checklist: 'land',
    summary: 'Boundary checks, clearing and an encroachment watch for vacant plots and land.',
    details: [
      'A monthly visit with GPS-tagged, dated photos',
      'Boundary stone, fence and gate checks; encroachment and dumping alerts',
      'Drone photos once a year on Land Watch, twice a year on Estate Watch',
      'Anyone asking about or claiming your plot is reported to you the same day',
    ],
  },
];
