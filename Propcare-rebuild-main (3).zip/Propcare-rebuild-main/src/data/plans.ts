/**
 * PropCare pricing — THE single source of truth.
 *
 * Every price on the website (Packages page, cards, comparison tables, estimator,
 * request form, confirmation emails and WhatsApp fallback) is read from this file.
 * Source: section 1 ("Pricing") of the owner's document "PropCare — Pricing, Site Visit
 * Checklists & Terms and Conditions" (28 Sep 2026). Wording is kept word for word.
 *
 * All fees are per property, per month, in ₹, with GST added as applicable.
 * Repair and vendor costs are always billed separately at actuals.
 */

export type FamilyId = 'home' | 'rental' | 'land' | 'portfolio';
export type BillingCycleId = 'monthly' | 'quarterly' | 'annual';
export type SizeId = 'upto-2bhk' | '3bhk-plus' | 'independent';
export type AddonId = 'onboarding' | 'tenant-placement' | 'emergency-visit' | 'paperwork';

/* ------------------------------------------------------------------ formatting */

const inrFormatter = new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0 });
/** 1499 -> "₹1,499" */
export const inr = (amount: number): string => `₹${inrFormatter.format(Math.round(amount))}`;
/** 5000 -> "5,000" (no symbol) */
export const num = (amount: number): string => inrFormatter.format(Math.round(amount));
const pct = (fraction: number): string => `${Math.round(fraction * 100)}%`;

/* ------------------------------------------------------------------ constants */

export const SQFT_PER_ACRE = 43560;

export const SIZE_OPTIONS: { id: SizeId; label: string; addon: number }[] = [
  { id: 'upto-2bhk', label: '1BHK / 2BHK', addon: 0 },
  { id: '3bhk-plus', label: '3BHK or larger', addon: 500 },
  { id: 'independent', label: 'Independent house / villa', addon: 1000 },
];

export interface BillingCycle {
  id: BillingCycleId;
  label: string;
  /** Months covered by one invoice. */
  months: number;
  /** Months actually charged for that period (annual: pay 10, get 12). */
  chargedMonths: number;
  /** Percentage discount on the period (quarterly: 5%). */
  discount: number;
  badge: string | null;
  description: string;
  per: string;
}

export const BILLING_CYCLES: Record<BillingCycleId, BillingCycle> = {
  monthly: { id: 'monthly', label: 'Monthly', months: 1, chargedMonths: 1, discount: 0, badge: null, description: 'Billed every month', per: 'per month' },
  quarterly: { id: 'quarterly', label: 'Quarterly', months: 3, chargedMonths: 3, discount: 0.05, badge: '5% off', description: '5% off, billed every 3 months', per: 'every 3 months' },
  annual: { id: 'annual', label: 'Annual', months: 12, chargedMonths: 10, discount: 0, badge: 'Pay 10, get 12', description: 'Pay for 10 months, get 12', per: 'per year' },
};
export const BILLING_ORDER: BillingCycleId[] = ['monthly', 'quarterly', 'annual'];

/** Effective monthly multiplier: monthly 1, quarterly 0.95, annual 10/12. */
export function billingFactor(cycle: BillingCycleId): number {
  const c = BILLING_CYCLES[cycle];
  return (c.chargedMonths * (1 - c.discount)) / c.months;
}

export interface PortfolioTier {
  id: 'portfolio-2-3' | 'portfolio-4-plus';
  label: string;
  minProperties: number;
  maxProperties: number | null;
  discount: number;
  extras: string[];
}

export const PORTFOLIO_TIERS: PortfolioTier[] = [
  { id: 'portfolio-2-3', label: '2–3', minProperties: 2, maxProperties: 3, discount: 0.1, extras: ['One consolidated family dashboard'] },
  { id: 'portfolio-4-plus', label: '4 or more', minProperties: 4, maxProperties: null, discount: 0.15, extras: ['Dashboard + dedicated relationship manager + Annual Asset Review for every property'] },
];

export function portfolioTierFor(properties: number): PortfolioTier | null {
  return PORTFOLIO_TIERS.slice().reverse().find((tier) => properties >= tier.minProperties) ?? null;
}

/* ------------------------------------------------------------------ plans */

export type PlanPricing =
  | { kind: 'flat'; monthly: number; sizeAddon: boolean; maxAreaSqFt?: number }
  | { kind: 'rentPercent'; percent: number; minimum: number }
  | { kind: 'perAcre'; base: number; includedAcres: number; perExtraAcre: number }
  | { kind: 'portfolio'; tier: PortfolioTier['id'] };

export interface Plan {
  id: string;
  family: FamilyId;
  name: string;
  /** Short, display-ready price, e.g. "₹2,999 per property per month". */
  priceLabel: string;
  /** Monthly base price in ₹, or null when the price depends on rent or other plans. */
  basePrice: number | null;
  /** Plain-language rule behind the price. */
  pricingRule: string;
  /** Everything included, generated from the comparison table below (never edit by hand). */
  features: string[];
  recommended: boolean;
  summary: string;
  pricing: PlanPricing;
}

export interface PlanFamily {
  id: FamilyId;
  name: string;
  audience: string;
  intro: string;
}

export const PLAN_FAMILIES: PlanFamily[] = [
  { id: 'home', name: 'Home Care', audience: 'Vacant or self-used homes (flats, villas)', intro: 'For flats and villas that stand empty or are used now and then.' },
  { id: 'rental', name: 'Rental Care', audience: 'Tenanted homes', intro: 'For homes with tenants: rent follow-up, inspections and tenant issues handled.' },
  { id: 'land', name: 'Land Watch', audience: 'Vacant plots and land', intro: 'For plots and land: boundary checks, encroachment alerts and GPS-tagged photos.' },
  { id: 'portfolio', name: 'Family Portfolio', audience: 'Two or more properties', intro: 'Combine plans across your family’s properties and save on the combined fees.' },
];

export const familyById = (id: FamilyId): PlanFamily => PLAN_FAMILIES.find((f) => f.id === id)!;

const sizeAddonRule = `Size add-on: +${inr(500)} per month for 3BHK or larger; +${inr(1000)} per month for an independent house or villa.`;

type PlanSeed = Omit<Plan, 'features'>;

const PLAN_SEEDS: PlanSeed[] = [
  // 1.1 Home Care
  { id: 'essential', family: 'home', name: 'Essential', basePrice: 1499, recommended: false,
    priceLabel: `${inr(1499)} per property per month`, pricingRule: `${inr(1499)} per property per month. ${sizeAddonRule}`,
    summary: 'A monthly check-up for a home that stands empty or is used now and then.',
    pricing: { kind: 'flat', monthly: 1499, sizeAddon: true } },
  { id: 'care-plus', family: 'home', name: 'Care Plus', basePrice: 2999, recommended: true,
    priceLabel: `${inr(2999)} per property per month`, pricingRule: `${inr(2999)} per property per month. ${sizeAddonRule}`,
    summary: 'Two visits a month, bill payments, society liaison and a quarterly deep check.',
    pricing: { kind: 'flat', monthly: 2999, sizeAddon: true } },
  { id: 'premium', family: 'home', name: 'Premium', basePrice: 4999, recommended: false,
    priceLabel: `${inr(4999)} per property per month`, pricingRule: `${inr(4999)} per property per month. ${sizeAddonRule}`,
    summary: 'Weekly visits, a monthly Health Score and your own relationship manager.',
    pricing: { kind: 'flat', monthly: 4999, sizeAddon: true } },
  // 1.2 Rental Care
  { id: 'rent-assist', family: 'rental', name: 'Rent Assist', basePrice: null, recommended: false,
    priceLabel: `5% of monthly rent (min ${inr(1500)})`, pricingRule: `5% of the monthly rent, with a minimum of ${inr(1500)} per month.`,
    summary: 'Rent follow-up, renewal reminders and a quarterly inspection.',
    pricing: { kind: 'rentPercent', percent: 0.05, minimum: 1500 } },
  { id: 'full-rental-management', family: 'rental', name: 'Full Rental Management', basePrice: null, recommended: false,
    priceLabel: `8% of monthly rent (min ${inr(3000)})`, pricingRule: `8% of the monthly rent, with a minimum of ${inr(3000)} per month.`,
    summary: 'Tenants, repairs, deposits and statements handled, with a monthly inspection.',
    pricing: { kind: 'rentPercent', percent: 0.08, minimum: 3000 } },
  // 1.3 Land Watch
  { id: 'site-watch', family: 'land', name: 'Site Watch', basePrice: 999, recommended: false,
    priceLabel: `${inr(999)} per month (up to ${num(2400)} sq ft)`, pricingRule: `${inr(999)} per month for a plot of up to ${num(2400)} sq ft.`,
    summary: `A monthly watch on a plot of up to ${num(2400)} sq ft.`,
    pricing: { kind: 'flat', monthly: 999, sizeAddon: false, maxAreaSqFt: 2400 } },
  { id: 'land-watch', family: 'land', name: 'Land Watch', basePrice: 1999, recommended: false,
    priceLabel: `${inr(1999)} per month (up to 1 acre)`, pricingRule: `${inr(1999)} per month for land of up to 1 acre.`,
    summary: 'A monthly watch on land of up to 1 acre, with yearly drone photos.',
    pricing: { kind: 'flat', monthly: 1999, sizeAddon: false, maxAreaSqFt: SQFT_PER_ACRE } },
  { id: 'estate-watch', family: 'land', name: 'Estate Watch', basePrice: 1999, recommended: false,
    priceLabel: `${inr(1999)} + ${inr(750)} per extra acre, per month`, pricingRule: `${inr(1999)} per month for the first acre, plus ${inr(750)} per month for each extra acre.`,
    summary: 'For larger land: drone photos twice a year and clearing once a year.',
    pricing: { kind: 'perAcre', base: 1999, includedAcres: 1, perExtraAcre: 750 } },
  // 1.4 Family Portfolio
  { id: 'portfolio-2-3', family: 'portfolio', name: '2–3 properties', basePrice: null, recommended: false,
    priceLabel: `${pct(0.1)} off combined fees`, pricingRule: `${pct(0.1)} off the combined monthly fees when 2–3 properties are under PropCare.`,
    summary: 'When two or three of your properties are under PropCare.',
    pricing: { kind: 'portfolio', tier: 'portfolio-2-3' } },
  { id: 'portfolio-4-plus', family: 'portfolio', name: '4 or more properties', basePrice: null, recommended: false,
    priceLabel: `${pct(0.15)} off combined fees`, pricingRule: `${pct(0.15)} off the combined monthly fees when 4 or more properties are under PropCare.`,
    summary: 'When four or more properties are under PropCare, with a relationship manager.',
    pricing: { kind: 'portfolio', tier: 'portfolio-4-plus' } },
];

/* ------------------------------------------------------------------ comparison tables (verbatim, sections 1.1–1.4) */

export interface ComparisonRow {
  label: string;
  /** Cell per plan id. "Yes", "—" (not included) or a value such as "2 per month". */
  values: Record<string, string>;
  /** How the row reads as a bullet when the cell is not "Yes". */
  bullet?: (value: string) => string;
}

export interface ComparisonTable {
  family: FamilyId;
  firstColumn: string;
  planIds: string[];
  rows: ComparisonRow[];
}

const v = (ids: string[], cells: string[]): Record<string, string> => Object.fromEntries(ids.map((id, i) => [id, cells[i]]));
const HOME = ['essential', 'care-plus', 'premium'];
const RENTAL = ['rent-assist', 'full-rental-management'];
const LAND = ['site-watch', 'land-watch', 'estate-watch'];
const PORTFOLIO = ['portfolio-2-3', 'portfolio-4-plus'];

export const COMPARISON: Record<FamilyId, ComparisonTable> = {
  home: {
    family: 'home', firstColumn: 'Service', planIds: HOME,
    rows: [
      { label: 'Inspection visits', values: v(HOME, ['1 per month', '2 per month', 'Weekly']), bullet: (x) => (x === 'Weekly' ? 'Weekly inspection visits' : `Inspection visits: ${x}`) },
      { label: 'Checklist inspection + dated photo report', values: v(HOME, ['Yes', 'Yes + video', 'Yes + video']), bullet: () => 'Checklist inspection + dated photo and video report' },
      { label: 'Run taps, flush drains, air out home, leak check', values: v(HOME, ['Yes', 'Yes', 'Yes']) },
      { label: 'Utility and property-tax due-date reminders', values: v(HOME, ['Yes', 'Yes', 'Yes']) },
      { label: "Bill payment on owner's behalf (at actual cost)", values: v(HOME, ['—', 'Yes', 'Yes']) },
      { label: 'Quarterly deep check (seepage, wiring, plumbing pressure)', values: v(HOME, ['—', 'Yes', 'Yes']) },
      { label: 'Housing society liaison', values: v(HOME, ['—', 'Yes', 'Yes']) },
      { label: 'Digital Property Passport (document vault + expiry alerts)', values: v(HOME, ['—', 'Yes', 'Yes']) },
      { label: 'Property Health Score (A/B/C/D)', values: v(HOME, ['Yearly', 'Quarterly', 'Monthly']), bullet: (x) => `Property Health Score (A/B/C/D): ${x.toLowerCase()}` },
      { label: 'Repair response time', values: v(HOME, ['72 hours', '48 hours', '24 hours']), bullet: (x) => `Repair response time: ${x}` },
      { label: 'Light cleaning / dusting', values: v(HOME, ['—', '—', '1 per month']), bullet: (x) => `Light cleaning / dusting: ${x}` },
      { label: 'Relationship manager + Annual Asset Review', values: v(HOME, ['—', '—', 'Yes']) },
    ],
  },
  rental: {
    family: 'rental', firstColumn: 'Service', planIds: RENTAL,
    rows: [
      { label: 'Rent tracking and follow-up with late payers', values: v(RENTAL, ['Yes', 'Yes']) },
      { label: 'Agreement renewal and expiry reminders', values: v(RENTAL, ['Yes', 'Yes']) },
      { label: 'Property inspection', values: v(RENTAL, ['Quarterly', 'Monthly']), bullet: (x) => `${x} property inspection` },
      { label: 'Move-in and move-out inspection with photos', values: v(RENTAL, ['Yes', 'Yes']) },
      { label: 'Tenant complaint handling and repair coordination', values: v(RENTAL, ['—', 'Yes']) },
      { label: 'Tenant police verification and rental agreement drafting', values: v(RENTAL, ['—', 'Yes']) },
      { label: 'Security deposit settlement at move-out', values: v(RENTAL, ['—', 'Yes']) },
      { label: 'Monthly income and expense statement', values: v(RENTAL, ['—', 'Yes']) },
      { label: 'TDS-on-rent support for NRI owners', values: v(RENTAL, ['—', 'Yes']) },
    ],
  },
  land: {
    family: 'land', firstColumn: 'Service', planIds: LAND,
    rows: [
      { label: 'Monthly visit with GPS-tagged, dated photos', values: v(LAND, ['Yes', 'Yes', 'Yes']) },
      { label: 'Boundary stone, fence and gate check', values: v(LAND, ['Yes', 'Yes', 'Yes']) },
      { label: 'Encroachment, dumping and unauthorised construction alerts', values: v(LAND, ['Yes', 'Yes', 'Yes']) },
      { label: 'Khata and property-tax reminders', values: v(LAND, ['Yes', 'Yes', 'Yes']) },
      { label: 'Drone photos', values: v(LAND, ['—', 'Once a year', 'Twice a year']), bullet: (x) => `Drone photos ${x.toLowerCase()}` },
      { label: 'Weed or debris clearing', values: v(LAND, ['At cost + 10%', 'At cost + 10%', 'Once a year included']), bullet: (x) => (x.startsWith('Once') ? 'Weed or debris clearing once a year, included' : `Weed or debris clearing at cost + 10%`) },
    ],
  },
  portfolio: {
    family: 'portfolio', firstColumn: 'Properties under PropCare', planIds: PORTFOLIO,
    rows: [
      { label: 'Discount on combined fees', values: v(PORTFOLIO, ['10%', '15%']), bullet: (x) => `${x} off the combined fees` },
      { label: 'Extras', values: v(PORTFOLIO, ['One consolidated family dashboard', 'Dashboard + dedicated relationship manager + Annual Asset Review for every property']), bullet: (x) => x },
    ],
  },
};

function featuresFor(planId: string, family: FamilyId): string[] {
  const table = COMPARISON[family];
  const out: string[] = [];
  for (const row of table.rows) {
    const value = row.values[planId];
    if (!value || value === '—') continue;
    if (value === 'Yes') out.push(row.label);
    else out.push(row.bullet ? row.bullet(value) : `${row.label}: ${value}`);
  }
  return out;
}

export const PLANS: Plan[] = PLAN_SEEDS.map((seed) => ({ ...seed, features: featuresFor(seed.id, seed.family) }));

export const planById = (id: string | null | undefined): Plan | undefined => PLANS.find((plan) => plan.id === id);
export const plansInFamily = (family: FamilyId): Plan[] => PLANS.filter((plan) => plan.family === family);
export const RECOMMENDED_PLAN_ID = PLANS.find((plan) => plan.recommended)?.id ?? 'care-plus';

/** Lowest monthly price in a family, for "from ₹…" teasers. */
export function familyFromLabel(family: FamilyId): string {
  if (family === 'rental') {
    const p = plansInFamily('rental')[0].pricing as Extract<PlanPricing, { kind: 'rentPercent' }>;
    return `${pct(p.percent)} of rent`;
  }
  if (family === 'portfolio') return `Up to ${pct(Math.max(...PORTFOLIO_TIERS.map((t) => t.discount)))} off`;
  const prices = plansInFamily(family).map((p) => p.basePrice).filter((x): x is number => x !== null);
  return `From ${inr(Math.min(...prices))}`;
}

/* ------------------------------------------------------------------ notes & extra charges */

export const PRICING_NOTES = {
  intro: 'PropCare has three plan families, one for each property type, plus a Family Portfolio discount when an owner combines plans.',
  perProperty: 'All fees are per property, per month, in ₹, with GST added as applicable.',
  vendorCosts: 'Repair and vendor costs are always billed separately at actuals.',
  sizeAddon: sizeAddonRule,
  tenantPlacement: "Tenant placement: half of one month's rent, charged once. Free with a 12-month Full Rental Management commitment.",
  estimate: 'Estimate — excl. GST; final quote confirmed after a call.',
  portfolio: `Family Portfolio: ${PORTFOLIO_TIERS.map((t) => `${pct(t.discount)} off for ${t.maxProperties ? `${t.minProperties}–${t.maxProperties}` : `${t.minProperties} or more`} properties`).join(', ')}.`,
  landLimits: `Site Watch covers plots up to ${num(2400)} sq ft and Land Watch covers up to 1 acre. Estate Watch adds ${inr(750)} for each extra acre.`,
  portfolioCombined: 'The discount applies to the combined monthly fees of all your properties under PropCare, whichever Home Care, Rental Care or Land Watch plan each one is on.',
};

export const ONE_TIME_CHARGES: { id: string; service: string; price: string; amount: number | null }[] = [
  { id: 'onboarding', service: 'Onboarding (baseline inspection, photo record, Property Passport setup, key handover, first Health Score)', price: `${inr(2499)} per property; waived on annual payment`, amount: 2499 },
  { id: 'single-inspection', service: 'Single inspection without a plan', price: `${inr(999)} per visit`, amount: 999 },
  { id: 'emergency-visit', service: 'Emergency visit (within 24 hours)', price: inr(1499), amount: 1499 },
  { id: 'small-repairs', service: 'Small repairs (plumbing, electrical, touch-ups)', price: 'Vendor bill at actuals; no coordination fee for plan members', amount: null },
  { id: 'large-works', service: 'Large works (renovation, waterproofing, interiors)', price: '10% of the bill for supervision; owner may use own vendor', amount: null },
  { id: 'paperwork', service: 'Paperwork tasks (khata transfer, e-khata, tax payment, certificates)', price: `${inr(1500)}–${num(5000)} per task, quoted before starting`, amount: null },
];

export const oneTimeCharge = (id: string) => ONE_TIME_CHARGES.find((c) => c.id === id)!;

export const ADDONS: { id: AddonId; label: string; detail: string }[] = [
  { id: 'onboarding', label: 'Onboarding', detail: oneTimeCharge('onboarding').price },
  { id: 'tenant-placement', label: 'Tenant placement', detail: "Half of one month's rent, charged once. Free with a 12-month Full Rental Management commitment." },
  { id: 'emergency-visit', label: 'Emergency visit', detail: `${oneTimeCharge('emergency-visit').price}, within 24 hours` },
  { id: 'paperwork', label: 'Paperwork assistance', detail: oneTimeCharge('paperwork').price },
];

export const BILLING_TERMS: string[] = [
  'Annual payment: pay for 10 months, get 12.',
  'Quarterly payment: 5% off.',
  'Minimum commitment: 3 months.',
  `Service area: base prices apply within about 25 km of Anekal; beyond that, add ${inr(300)} per visit.`,
  'GST added as applicable.',
];

export const OUTSIDE_AREA_NOTE = BILLING_TERMS.find((term) => term.startsWith('Service area'))!;
