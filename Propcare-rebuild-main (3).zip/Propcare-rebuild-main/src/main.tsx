import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './app.css';
import App from './App';

// Theme: the visitor's saved choice, else their system preference. Set before the first render,
// so the page never paints in the wrong theme (index.html shows nothing before this runs).
try {
  const saved = localStorage.getItem('pc-theme');
  document.documentElement.dataset.theme = saved === 'dark' || saved === 'light'
    ? saved
    : window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
} catch {
  document.documentElement.dataset.theme = 'light';
}

// Motion is opt-in: hidden "reveal" states only apply once JS is running and the visitor
// hasn't asked for reduced motion.
if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) document.documentElement.classList.add('motion');

createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>);
