/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_SITE_URL?: string;
  readonly VITE_EMAILJS_SERVICE_ID?: string;
  readonly VITE_EMAILJS_PUBLIC_KEY?: string;
  readonly VITE_EMAILJS_TEMPLATE_CUSTOMER?: string;
  readonly VITE_EMAILJS_TEMPLATE_ADMIN?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
