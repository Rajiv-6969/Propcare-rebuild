import * as React from 'react';

export type FooterLink = { label: string; href?: string; external?: boolean };
export type FooterColumn = { title: string; links: FooterLink[] };
export type FooterCredit = { lead?: string; label: string; href?: string; tail?: string };

export type BeamWordmarkFooterProps = {
  brand?: string;
  wordmark?: string;
  company?: string;
  tagline?: string;
  year?: number;
  credits?: FooterCredit[];
  columns?: FooterColumn[];
  /** Extra column (e.g. contact details) rendered after the link columns. */
  aside?: React.ReactNode;
  onLinkClick?: (label: string, href?: string) => void;
  animate?: boolean;
  className?: string;
};

const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));

/**
 * Footer with a soft light beam that follows the pointer and a large PropCare wordmark.
 * The beam runs at most 30 fps, only while the footer is on screen, and stops under
 * prefers-reduced-motion. Styles live in src/styles/footer.css.
 */
export default function BeamWordmarkFooter({
  brand = 'PropCare',
  wordmark,
  company = 'PropCare',
  tagline,
  year = new Date().getFullYear(),
  credits = [],
  columns = [],
  aside,
  onLinkClick,
  animate = true,
  className = '',
}: BeamWordmarkFooterProps) {
  const rootRef = React.useRef<HTMLElement>(null);
  const pointer = React.useRef({ x: 0, y: 0, beam: 58, inside: false });
  const [reduced, setReduced] = React.useState(false);
  const word = (wordmark ?? brand).trim() || brand;

  React.useEffect(() => {
    const media = window.matchMedia('(prefers-reduced-motion: reduce)');
    const update = () => setReduced(media.matches);
    update();
    media.addEventListener('change', update);
    return () => media.removeEventListener('change', update);
  }, []);

  React.useEffect(() => {
    const root = rootRef.current;
    if (!root) return;
    root.style.setProperty('--bwf-beam', '58%');
    if (!animate || reduced) return;
    let frame = 0;
    let previous = performance.now();
    let time = previous / 1000;
    let visible = false;
    let lastFrame = 0;
    const tick = (now: number) => {
      frame = 0;
      if (!visible || document.hidden) return;
      if (now - lastFrame < 1000 / 30) { frame = requestAnimationFrame(tick); return; }
      lastFrame = now;
      const dt = Math.min(0.1, (now - previous) / 1000);
      previous = now; time += dt;
      const p = pointer.current;
      const idle = 58 + 8 * (0.7 * Math.sin(time * 0.21) + 0.3 * Math.sin(time * 0.077 + 1.3));
      const target = p.inside ? p.beam * 0.72 + idle * 0.28 : idle;
      p.beam += (target - p.beam) * (1 - Math.pow(0.965, dt * 60));
      root.style.setProperty('--bwf-beam', `${p.beam}%`);
      root.style.setProperty('--bwf-px', `${p.x}px`);
      root.style.setProperty('--bwf-py', `${p.y}px`);
      root.style.setProperty('--bwf-glow', p.inside ? '1' : '0');
      frame = requestAnimationFrame(tick);
    };
    const intersection = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      if (visible && !frame) frame = requestAnimationFrame(tick);
      else if (!visible && frame) { cancelAnimationFrame(frame); frame = 0; }
    });
    const visibility = () => {
      if (document.hidden && frame) { cancelAnimationFrame(frame); frame = 0; }
      else if (!document.hidden && visible && !frame) frame = requestAnimationFrame(tick);
    };
    intersection.observe(root);
    document.addEventListener('visibilitychange', visibility);
    return () => { if (frame) cancelAnimationFrame(frame); intersection.disconnect(); document.removeEventListener('visibilitychange', visibility); };
  }, [animate, reduced]);

  const onPointerMove = (event: React.PointerEvent<HTMLElement>) => {
    if (event.pointerType === 'touch') return;
    const rect = event.currentTarget.getBoundingClientRect();
    const p = pointer.current;
    p.x = event.clientX - rect.left; p.y = event.clientY - rect.top;
    p.beam = clamp((p.x / Math.max(rect.width, 1)) * 52 + 30, 30, 82);
    p.inside = event.type !== 'pointerleave';
  };
  const follow = (event: React.MouseEvent<HTMLAnchorElement>, label: string, href?: string) => {
    if (!href || href === '#') event.preventDefault();
    onLinkClick?.(label, href);
  };

  return (
    <footer ref={rootRef} className={`bwf ${className}`} onPointerMove={onPointerMove} onPointerEnter={onPointerMove} onPointerLeave={onPointerMove}>
      <div className="bwf-rule" aria-hidden="true" />
      <div className="bwf-sky" aria-hidden="true"><div className="bwf-wash" /><div className="bwf-bands" /><div className="bwf-beam" /><div className="bwf-glow" /></div>
      <div className="bwf-inner">
        <div className="bwf-primary">
          <a className="bwf-brand" href="/" aria-label={`${company} home`}>
            <img src="/brand/propcare-mark-192.png" width={64} height={70} alt="" loading="lazy" decoding="async" />
            <span className="bwf-brand-copy"><strong>Prop<span>Care</span></strong><small>PRIVATE LIMITED</small>{tagline && <em>{tagline}</em>}</span>
          </a>
          <div className="bwf-credits">
            {credits.map((credit, index) => (
              <p key={`${credit.label}-${index}`}>{credit.lead}{credit.href
                ? <a href={credit.href} target="_blank" rel="noopener noreferrer" onClick={(event) => follow(event, credit.label, credit.href)}>{credit.label}</a>
                : <strong>{credit.label}</strong>}{credit.tail}</p>
            ))}
          </div>
          <p className="bwf-label">© {year} {company}</p>
        </div>
        {columns.map((column) => (
          <nav key={column.title} aria-label={column.title}>
            <p className="bwf-heading">{column.title}</p>
            <ul className="bwf-links">
              {column.links.map((link) => (
                <li key={link.label}>
                  <a className="bwf-link" href={link.href || '#'} {...(link.external ? { target: '_blank', rel: 'noopener noreferrer' } : {})} onClick={(event) => follow(event, link.label, link.href)}>{link.label}</a>
                </li>
              ))}
            </ul>
          </nav>
        ))}
        {aside && <div className="bwf-aside">{aside}</div>}
      </div>
      <div className="bwf-word" aria-hidden="true">
        <div className="bwf-word-box"><div className="bwf-word-in">{Array.from(word).map((letter, index) => <span className="bwf-letter" key={`${letter}-${index}`}>{letter === ' ' ? '\u00a0' : letter}</span>)}</div></div>
        <div className="bwf-foot" />
      </div>
    </footer>
  );
}
