import type { ChangeEvent, ReactNode } from 'react';
import { AlertCircle } from 'lucide-react';

function describedBy(id: string, hint?: ReactNode, error?: string) {
  return [hint ? `${id}-hint` : '', error ? `${id}-error` : ''].filter(Boolean).join(' ') || undefined;
}

function Messages({ id, hint, error }: { id: string; hint?: ReactNode; error?: string }) {
  return (
    <>
      {hint && <p className="field-hint" id={`${id}-hint`}>{hint}</p>}
      {error && <p className="field-error" id={`${id}-error`}><AlertCircle aria-hidden="true" />{error}</p>}
    </>
  );
}

const Req = () => <span className="req" aria-hidden="true">*</span>;

export function TextField({ id, label, value, onChange, error, hint, required, type = 'text', inputMode, autoComplete, prefix, maxLength, min, step }: {
  id: string; label: string; value: string; onChange: (value: string) => void; error?: string; hint?: ReactNode; required?: boolean;
  type?: string; inputMode?: 'text' | 'email' | 'tel' | 'numeric' | 'decimal'; autoComplete?: string; prefix?: string; maxLength?: number; min?: number; step?: string;
}) {
  return (
    <div className="field">
      <div className={`float ${prefix ? 'has-prefix' : ''}`}>
        <input id={id} name={id} className="control" type={type} value={value} placeholder=" " inputMode={inputMode} autoComplete={autoComplete}
          maxLength={maxLength} min={min} step={step} aria-required={required || undefined} aria-invalid={error ? true : undefined}
          aria-describedby={describedBy(id, hint, error)} onChange={(event: ChangeEvent<HTMLInputElement>) => onChange(event.target.value)} />
        <label htmlFor={id}>{label}{required && <Req />}</label>
        {prefix && <span className="prefix" aria-hidden="true">{prefix}</span>}
      </div>
      <Messages id={id} hint={hint} error={error} />
    </div>
  );
}

export function TextAreaField({ id, label, value, onChange, error, hint, maxLength }: {
  id: string; label: string; value: string; onChange: (value: string) => void; error?: string; hint?: ReactNode; maxLength?: number;
}) {
  return (
    <div className="field">
      <div className="float">
        <textarea id={id} name={id} className="control" value={value} placeholder=" " maxLength={maxLength}
          aria-invalid={error ? true : undefined} aria-describedby={describedBy(id, hint, error)} onChange={(event) => onChange(event.target.value)} />
        <label htmlFor={id}>{label}</label>
      </div>
      <Messages id={id} hint={hint} error={error} />
    </div>
  );
}

export interface SelectOption { value: string; label: string }
export interface SelectGroup { label: string; options: SelectOption[] }

export function SelectField({ id, label, value, onChange, options, groups, error, hint, required, placeholder = 'Select…' }: {
  id: string; label: string; value: string; onChange: (value: string) => void; options?: SelectOption[]; groups?: SelectGroup[];
  error?: string; hint?: ReactNode; required?: boolean; placeholder?: string;
}) {
  return (
    <div className="field">
      <div className="float is-select">
        <select id={id} name={id} className="control" value={value} aria-required={required || undefined} aria-invalid={error ? true : undefined}
          aria-describedby={describedBy(id, hint, error)} onChange={(event) => onChange(event.target.value)}>
          <option value="">{placeholder}</option>
          {options?.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
          {groups?.map((group) => (
            <optgroup key={group.label} label={group.label}>
              {group.options.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
            </optgroup>
          ))}
        </select>
        <label htmlFor={id}>{label}{required && <Req />}</label>
      </div>
      <Messages id={id} hint={hint} error={error} />
    </div>
  );
}

export interface Choice { value: string; title: ReactNode; detail?: ReactNode }

export function ChoiceGroup({ id, legend, choices, type = 'radio', value, values, onChange, onToggle, error, hint, required, columns }: {
  id: string; legend: ReactNode; choices: Choice[]; type?: 'radio' | 'checkbox'; value?: string; values?: string[];
  onChange?: (value: string) => void; onToggle?: (value: string, checked: boolean) => void; error?: string; hint?: ReactNode; required?: boolean; columns?: number;
}) {
  return (
    <fieldset className="field" id={id} aria-describedby={describedBy(id, hint, error)}>
      <legend className="field-label" style={{ marginBottom: 6 }}>{legend}{required && <Req />}</legend>
      <div className="choices" role={type === 'radio' ? 'radiogroup' : undefined} aria-required={type === 'radio' && required ? true : undefined}
        aria-invalid={error ? true : undefined} style={columns ? { gridTemplateColumns: `repeat(auto-fit, minmax(min(100%, ${Math.floor(560 / columns)}px), 1fr))` } : undefined}>
        {choices.map((choice) => {
          const checked = type === 'radio' ? value === choice.value : Boolean(values?.includes(choice.value));
          return (
            <label className="choice" key={choice.value}>
              <input type={type} name={id} value={choice.value} checked={checked}
                onChange={(event) => (type === 'radio' ? onChange?.(choice.value) : onToggle?.(choice.value, event.target.checked))} />
              <span className="choice-body">
                <span className="choice-title">{choice.title}</span>
                {choice.detail && <span className="choice-detail">{choice.detail}</span>}
              </span>
            </label>
          );
        })}
      </div>
      <Messages id={id} hint={hint} error={error} />
    </fieldset>
  );
}

export function Stepper({ id, label, value, onChange, min = 1, max = 50, hint, error }: {
  id: string; label: string; value: string; onChange: (value: string) => void; min?: number; max?: number; hint?: ReactNode; error?: string;
}) {
  const n = Number(value) || min;
  return (
    <div className="field">
      <label className="field-label" htmlFor={id}>{label}</label>
      <div className="stepper">
        <button type="button" aria-label="One fewer property" disabled={n <= min} onClick={() => onChange(String(Math.max(min, n - 1)))}>−</button>
        <input id={id} name={id} type="number" inputMode="numeric" min={min} max={max} value={value} aria-invalid={error ? true : undefined}
          aria-describedby={describedBy(id, hint, error)} onChange={(event) => onChange(event.target.value.replace(/[^\d]/g, '').slice(0, 2))} />
        <button type="button" aria-label="One more property" disabled={n >= max} onClick={() => onChange(String(Math.min(max, n + 1)))}>+</button>
      </div>
      <Messages id={id} hint={hint} error={error} />
    </div>
  );
}
