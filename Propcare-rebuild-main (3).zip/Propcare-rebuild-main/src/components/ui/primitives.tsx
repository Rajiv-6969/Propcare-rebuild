import { createElement, useEffect, useRef, type CSSProperties, type ElementType, type KeyboardEvent, type ReactNode } from 'react';
import { Check } from 'lucide-react';
import { useReveal, useTweenedNumber } from '../../hooks/motion';
import { inr } from '../../data/plans';

/* ------------------------------------------------------------------ WhatsApp glyph (Simple Icons, CC0) */
export function WhatsAppIcon({ size = 20, className }: { size?: number; className?: string }) {
  return (
    <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false">
      <path d="M17.47 14.38c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.16-.17.2-.35.22-.64.08-.3-.15-1.26-.46-2.39-1.48-.88-.79-1.48-1.76-1.65-2.06-.17-.3-.02-.46.13-.6.13-.14.3-.35.45-.52.15-.18.2-.3.3-.5.1-.2.05-.37-.03-.52-.07-.15-.67-1.61-.92-2.2-.24-.58-.49-.5-.67-.51l-.57-.01c-.2 0-.52.07-.8.37-.27.3-1.04 1.02-1.04 2.48s1.07 2.88 1.21 3.07c.15.2 2.1 3.2 5.08 4.49.71.3 1.26.49 1.7.63.71.22 1.36.19 1.87.12.57-.09 1.76-.72 2-1.41.25-.7.25-1.29.18-1.41-.08-.13-.27-.2-.57-.35m-5.42 7.4h-.01a9.87 9.87 0 0 1-5.03-1.38l-.36-.21-3.74.98 1-3.65-.24-.37a9.86 9.86 0 0 1-1.51-5.26c0-5.45 4.44-9.88 9.89-9.88 2.64 0 5.12 1.03 6.99 2.9a9.83 9.83 0 0 1 2.89 6.99c0 5.45-4.44 9.88-9.88 9.88m8.41-18.3A11.82 11.82 0 0 0 12.05 0C5.5 0 .16 5.34.16 11.89c0 2.1.55 4.14 1.59 5.95L.06 24l6.3-1.65a11.88 11.88 0 0 0 5.68 1.45h.01c6.55 0 11.89-5.34 11.89-11.89a11.82 11.82 0 0 0-3.48-8.41Z" />
    </svg>
  );
}

/* ------------------------------------------------------------------ Reveal */
export function Reveal({ as = 'div', i = 0, fade = false, className, style, children, ...rest }: {
  as?: ElementType; i?: number; fade?: boolean; className?: string; style?: CSSProperties; children?: ReactNode; [key: string]: unknown;
}) {
  const ref = useReveal<HTMLElement>();
  return createElement(as, { ref, 'data-reveal': fade ? 'fade' : '', className, style: { ...style, '--i': i } as CSSProperties, ...rest }, children);
}

/* ------------------------------------------------------------------ Animated rupee amount */
export function AnimatedINR({ value, className }: { value: number; className?: string }) {
  const shown = useTweenedNumber(value);
  return <span className={`tabular ${className ?? ''}`}>{inr(shown)}</span>;
}

/* ------------------------------------------------------------------ Status pill */
export function StatusPill({ status }: { status: 'ok' | 'attention' | 'urgent' }) {
  const label = status === 'ok' ? 'OK' : status === 'attention' ? 'Attention' : 'Urgent';
  return <span className={`status status-${status}`}>{label}</span>;
}

export function CheckList({ items, compact = false, className = '' }: { items: ReactNode[]; compact?: boolean; className?: string }) {
  return (
    <ul className={`check-list ${compact ? 'compact' : ''} ${className}`}>
      {items.map((item, index) => <li key={index}><Check aria-hidden="true" strokeWidth={2.4} />{item}</li>)}
    </ul>
  );
}

/* ------------------------------------------------------------------ Segmented control (radio group) */
export interface SegmentOption<T extends string> { value: T; label: ReactNode; sub?: ReactNode; }

/**
 * Options are equal-width grid columns, so the sliding thumb is positioned with CSS alone
 * (--seg-count / --seg-index): no layout measuring, no ResizeObserver.
 */
export function Segmented<T extends string>({ options, value, onChange, label, className = '', id }: {
  options: SegmentOption<T>[]; value: T; onChange: (value: T) => void; label: string; className?: string; id?: string;
}) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const index = Math.max(0, options.findIndex((option) => option.value === value));

  const onKey = (event: KeyboardEvent<HTMLButtonElement>, at: number) => {
    const delta = event.key === 'ArrowRight' || event.key === 'ArrowDown' ? 1 : event.key === 'ArrowLeft' || event.key === 'ArrowUp' ? -1 : 0;
    if (!delta) return;
    event.preventDefault();
    const next = options[(at + delta + options.length) % options.length];
    onChange(next.value);
    requestAnimationFrame(() => wrapRef.current?.querySelector<HTMLElement>(`[data-value="${next.value}"]`)?.focus());
  };

  return (
    <div ref={wrapRef} id={id} className={`segmented ${className}`} role="radiogroup" aria-label={label}
      style={{ '--seg-count': options.length, '--seg-index': index } as CSSProperties}>
      <span className="segmented-thumb" aria-hidden="true" />
      {options.map((option, at) => {
        const checked = option.value === value;
        return (
          <button key={option.value} type="button" role="radio" aria-checked={checked} tabIndex={checked ? 0 : -1} data-value={option.value}
            className="segmented-option" onClick={() => onChange(option.value)} onKeyDown={(event) => onKey(event, at)}>
            <span>{option.label}</span>
            {option.sub && <small>{option.sub}</small>}
          </button>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ Tabs */
export interface TabItem<T extends string> { id: T; label: ReactNode; icon?: ReactNode; count?: number }

export function TabList<T extends string>({ items, active, onChange, label, idPrefix, className = '' }: {
  items: TabItem<T>[]; active: T; onChange: (id: T) => void; label: string; idPrefix: string; className?: string;
}) {
  const listRef = useRef<HTMLDivElement>(null);
  const mounted = useRef(false);
  const onKey = (event: KeyboardEvent<HTMLButtonElement>, index: number) => {
    let next = -1;
    if (event.key === 'ArrowRight') next = (index + 1) % items.length;
    if (event.key === 'ArrowLeft') next = (index - 1 + items.length) % items.length;
    if (event.key === 'Home') next = 0;
    if (event.key === 'End') next = items.length - 1;
    if (next < 0) return;
    event.preventDefault();
    onChange(items[next].id);
    requestAnimationFrame(() => document.getElementById(`${idPrefix}-tab-${items[next].id}`)?.focus());
  };
  useEffect(() => {
    // Keep the active tab visible inside a horizontally scrolling tab row (never scrolls the page).
    // Skipped on first render when the first tab is active: nothing to scroll, so no layout read.
    const first = !mounted.current;
    mounted.current = true;
    if (first && items[0]?.id === active) return;
    const list = listRef.current;
    const tab = document.getElementById(`${idPrefix}-tab-${active}`);
    if (!list || !tab || list.scrollWidth <= list.clientWidth) return;
    const left = tab.offsetLeft; // .tabs is position: relative, so this is relative to the row
    if (left < list.scrollLeft || left + tab.offsetWidth > list.scrollLeft + list.clientWidth) list.scrollLeft = Math.max(0, left - 16);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active, idPrefix]);
  return (
    <div ref={listRef} className={`tabs ${className}`} role="tablist" aria-label={label}>
      {items.map((item, index) => (
        <button key={item.id} type="button" role="tab" id={`${idPrefix}-tab-${item.id}`} aria-selected={item.id === active}
          aria-controls={`${idPrefix}-panel-${item.id}`} tabIndex={item.id === active ? 0 : -1} className="tab"
          onClick={() => onChange(item.id)} onKeyDown={(event) => onKey(event, index)}>
          {item.icon}{item.label}{typeof item.count === 'number' && <span className="tab-count">{item.count}</span>}
        </button>
      ))}
    </div>
  );
}
