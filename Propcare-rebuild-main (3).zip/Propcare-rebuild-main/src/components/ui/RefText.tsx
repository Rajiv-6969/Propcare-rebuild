import { Fragment } from 'react';
import { pathFor } from '../../config/routes';
import { CHECKLISTS } from '../../data/checklists';
import { termsAnchor } from '../../data/terms';

type Page = 'what-we-check' | 'terms' | 'other';

/**
 * Where a cross-reference from the owner's document points on the website:
 * "section 1" = plans and pricing, "section 2" / "2.1"–"2.5" = site visit checklists,
 * "3.1"–"3.13" = Terms & Conditions clauses. Same-page references stay on the page.
 */
export function refHref(ref: string, page: Page): string | null {
  if (ref === 'section 1') return pathFor('packages');
  if (ref === 'section 2') return pathFor('what-we-check');
  const checklist = CHECKLISTS.find((list) => list.number === ref);
  if (checklist) return `${page === 'what-we-check' ? '' : pathFor('what-we-check')}#${checklist.id}`;
  const anchor = termsAnchor(ref);
  if (anchor) return `${page === 'terms' ? '' : pathFor('terms')}#${anchor}`;
  return null;
}

const REF_PATTERN = /(section [12]|\b[23]\.\d{1,2}\b)/g;

/** Renders document text with its cross-references ("see 3.6", "everything in 2.2") as links. */
export function RefText({ text, page }: { text: string; page: Page }) {
  const parts = text.split(REF_PATTERN);
  return (
    <>
      {parts.map((part, index) => {
        const href = index % 2 === 1 ? refHref(part, page) : null;
        return href ? <a key={index} className="ref-link" href={href}>{part}</a> : <Fragment key={index}>{part}</Fragment>;
      })}
    </>
  );
}
