import { useMemo, useRef, useState } from 'react';
import {
  ArrowRight, Building2, CalendarCheck, ClipboardCheck, Droplets, FileCheck2, Fence, Gauge, KeyRound, ReceiptText, RotateCcw, Users, Wrench,
} from 'lucide-react';
import { pathFor } from '../../config/routes';
import { CHECKLISTS, STATUS_LEGEND } from '../../data/checklists';
import { COMPARISON, PLAN_FAMILIES, RECOMMENDED_PLAN_ID, familyFromLabel, inr, oneTimeCharge, planById, plansInFamily, type FamilyId } from '../../data/plans';
import { SERVICES } from '../../data/services';
import { useInView } from '../../hooks/motion';
import { CheckList, Reveal, StatusPill } from '../ui/primitives';

/* ------------------------------------------------------------------ How it works */
const STEPS = [
  { icon: KeyRound, title: 'Onboarding', text: 'Share proof of ownership and key documents, hand over the keys, and sign an authorisation for any tasks we handle for you.' },
  { icon: FileCheck2, title: 'Baseline inspection & Property Passport', text: 'A full baseline inspection and photo record. Your documents go into a Digital Property Passport with expiry alerts.' },
  { icon: CalendarCheck, title: 'Scheduled visits', text: 'Monthly, twice a month or weekly, depending on your plan. Every visit follows a written checklist.' },
  { icon: ClipboardCheck, title: 'Dated photo report within 24 hrs', text: 'Each item is marked OK, Attention or Urgent, with a dated photo for anything that is not OK.' },
  { icon: Gauge, title: 'Health Score (A/B/C/D)', text: 'One grade that sums up the condition of your property, so you can see at a glance how it is doing.' },
];

export function HowItWorks({ id = 'how-it-works' }: { id?: string }) {
  const ref = useRef<HTMLOListElement>(null);
  const seen = useInView(ref, { threshold: 0.25 });
  return (
    <section className="section" aria-labelledby={`${id}-title`}>
      <div className="container">
        <Reveal className="section-head">
          <p className="eyebrow">How it works</p>
          <h2 id={`${id}-title`}>From keys to a <em>clear report</em></h2>
          <p>Five steps, the same every time, so you always know what has been checked and what needs a decision from you.</p>
        </Reveal>
        <ol ref={ref} className={`timeline ${seen ? 'is-drawn' : ''}`}>
          {STEPS.map((step, index) => (
            <li key={step.title} className="timeline-step" style={{ ['--i' as string]: index }}>
              <span className="timeline-dot" aria-hidden="true"><step.icon /></span>
              <p className="timeline-num" aria-hidden="true">{String(index + 1).padStart(2, '0')}</p>
              <h3>{step.title}</h3>
              <p>{step.text}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ Reports + Health Score */
export function HealthScoreBadge({ grade = 'A', caption = 'All well' }: { grade?: string; caption?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const seen = useInView(ref, { threshold: 0.5 });
  return (
    <div ref={ref} className={`hs-badge ${seen ? 'is-drawn' : ''}`}>
      <svg viewBox="0 0 120 120" aria-hidden="true">
        <circle className="hs-track" cx="60" cy="60" r="52" />
        <circle className="hs-arc" cx="60" cy="60" r="52" pathLength={100} />
      </svg>
      <div className="hs-center"><span className="hs-grade">{grade}</span><span className="hs-caption">{caption}</span></div>
    </div>
  );
}

export function ReportsSection() {
  const frequency = COMPARISON.home.rows.find((row) => row.label.startsWith('Property Health Score'))!;
  const common = CHECKLISTS[0].groups[0].items.slice(0, 4);
  return (
    <section className="section section-alt" aria-labelledby="reports-title">
      <div className="container reports-grid">
        <Reveal className="reports-copy">
          <p className="eyebrow">Reports you can act on</p>
          <h2 id="reports-title">Every visit follows a <em>written checklist</em></h2>
          <p className="lead">The common checklist first, then the list for your property type. You get the report within 24 hours of the visit.</p>
          <ul className="legend" aria-label="How each item is marked">
            {STATUS_LEGEND.map((s) => <li key={s.id}><StatusPill status={s.id} /><span>{s.description}</span></li>)}
          </ul>
          <div className="mini-checklist">
            <p className="mini-title">On every visit, for example:</p>
            <CheckList items={common} compact />
          </div>
          <a className="link-arrow" href={pathFor('what-we-check')}>See every checklist <ArrowRight aria-hidden="true" /></a>
        </Reveal>
        <Reveal className="score-card card" i={1}>
          <HealthScoreBadge />
          <div>
            <h3>Property Health Score</h3>
            <p>Each report rolls the checklist up into one grade, from A to D. A means all is well; D means something needs urgent attention.</p>
            <div className="hs-scale" aria-label="Health Score scale from A to D">
              {['A', 'B', 'C', 'D'].map((g) => <span key={g} className={`hs-step hs-${g.toLowerCase()}`}>{g}</span>)}
            </div>
            <dl className="hs-freq">
              {plansInFamily('home').map((plan) => (
                <div key={plan.id}><dt>{plan.name}</dt><dd>{frequency.values[plan.id]}</dd></div>
              ))}
            </dl>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ Services index */
const SERVICE_ICONS: Record<string, typeof ClipboardCheck> = {
  inspections: ClipboardCheck, cleaning: Droplets, repairs: Wrench, tenants: KeyRound, bills: ReceiptText, plots: Fence,
};

export function ServicesIndex() {
  return (
    <section className="section" aria-labelledby="services-title">
      <div className="container">
        <Reveal className="section-head split">
          <div>
            <p className="eyebrow">What we do</p>
            <h2 id="services-title">What we take <em>care</em> of</h2>
          </div>
          <p>From routine visits to repairs and paperwork, one local team handles it and keeps you informed.</p>
        </Reveal>
        <ul className="service-index">
          {SERVICES.map((service, index) => {
            const Icon = SERVICE_ICONS[service.id] ?? ClipboardCheck;
            return (
              <Reveal as="li" key={service.id} i={index % 2}>
                <a className="service-row" href={`${pathFor('services')}#${service.id}`}>
                  <span className="icon-tile"><Icon aria-hidden="true" /></span>
                  <span className="service-row-text"><strong>{service.title}</strong><span>{service.summary}</span></span>
                  <ArrowRight className="service-row-arrow" aria-hidden="true" />
                </a>
              </Reveal>
            );
          })}
        </ul>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ Plans teaser */
const FAMILY_ICONS: Record<FamilyId, typeof Building2> = { home: Building2, rental: KeyRound, land: Fence, portfolio: Users };

export function PlansTeaser() {
  const recommended = planById(RECOMMENDED_PLAN_ID)!;
  return (
    <section className="section section-surface" aria-labelledby="plans-title">
      <div className="container">
        <Reveal className="section-head split">
          <div>
            <p className="eyebrow">Care plans</p>
            <h2 id="plans-title">A plan for every <em>property</em></h2>
          </div>
          <p>All fees are per property, per month. Pay quarterly for 5% off, or annually and pay for 10 months, get 12.</p>
        </Reveal>
        <div className="family-cards">
          {PLAN_FAMILIES.map((family, index) => {
            const Icon = FAMILY_ICONS[family.id];
            const plans = plansInFamily(family.id);
            return (
              <Reveal key={family.id} i={index} className="family-card card card-hover">
                <span className="icon-tile"><Icon aria-hidden="true" /></span>
                <h3>{family.name}</h3>
                <p className="family-audience">{family.audience}</p>
                <p className="family-from">{familyFromLabel(family.id)}<small>{family.id === 'portfolio' ? ' combined fees' : family.id === 'rental' ? ` · min ${inr((plans[0].pricing as { minimum: number }).minimum)}` : ' / month'}</small></p>
                <p className="family-plans">{plans.map((p) => p.name).join(' · ')}</p>
                {family.id === recommended.family && <p className="family-note"><span className="badge">Recommended: {recommended.name}</span></p>}
                <a className="link-arrow" href={`${pathFor('packages')}#${family.id}`} aria-label={`See ${family.name} plans`}>See plans <ArrowRight aria-hidden="true" /></a>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ Property Health Check (self-assessment quiz) */
const QUESTIONS = [
  'When did someone last visit your property?',
  'Is the property currently occupied?',
  'Are property tax and utility bills up to date?',
  'Any leaks, damp patches, or cracks noticed recently?',
  'Is the boundary wall/fence secure?',
  'Do you have recent photos of your property?',
];
const ANSWERS: [number, string][] = [[20, 'Yes / within the last month'], [12, 'Occasionally / mostly secure'], [6, 'Some concerns'], [0, 'Not sure / needs attention']];

export function HealthCheck() {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [done, setDone] = useState(false);
  const score = useMemo(() => Math.round((answers.reduce((a, b) => a + b, 0) / (QUESTIONS.length * 20)) * 100), [answers]);
  const choose = (value: number) => setAnswers((current) => { const next = [...current]; next[step] = value; return next; });
  const essential = planById('essential')!;
  const carePlus = planById('care-plus')!;
  const onboarding = oneTimeCharge('onboarding');

  const result = score >= 75
    ? { title: 'Your property is in great shape.', text: `${essential.name} (${inr(essential.basePrice!)} a month) keeps it that way with a monthly checklist visit and a dated photo report.`, href: `${pathFor('request')}?plan=essential`, cta: `Request ${essential.name}` }
    : score >= 50
      ? { title: 'Your property is doing okay, but could use attention.', text: `${carePlus.name} (${inr(carePlus.basePrice!)} a month), our recommended plan, adds a second monthly visit and a quarterly deep check.`, href: `${pathFor('request')}?plan=care-plus`, cta: `Request ${carePlus.name}` }
      : { title: 'Your property may need a closer look.', text: `Start with onboarding: a baseline inspection, photo record and your first Health Score (${onboarding.price}).`, href: `${pathFor('request')}?plan=care-plus&addons=onboarding`, cta: 'Request onboarding' };

  return (
    <section className="section" id="health-check" aria-labelledby="health-check-title">
      <div className="container quiz-grid">
        <Reveal className="quiz-intro">
          <p className="eyebrow">Free self-check</p>
          <h2 id="health-check-title">Is your property <em>healthy?</em></h2>
          <p className="lead">Answer six quick questions to see how your property is doing, and what it might need. It takes a minute and nothing is stored.</p>
        </Reveal>
        <Reveal className="card quiz-card" i={1} aria-live="polite">
          {!done ? (
            <div key={step} className="swap-in">
              <div className="quiz-progress" aria-hidden="true"><span style={{ transform: `scaleX(${(step + 1) / QUESTIONS.length})` }} /></div>
              <p className="quiz-count">Question {step + 1} of {QUESTIONS.length}</p>
              <fieldset className="quiz-question">
                <legend>{QUESTIONS[step]}</legend>
                <div className="choices">
                  {ANSWERS.map(([value, label]) => (
                    <label className="choice" key={value}>
                      <input type="radio" name={`health-${step}`} checked={answers[step] === value} onChange={() => choose(value)} />
                      <span className="choice-body"><span className="choice-title">{label}</span></span>
                    </label>
                  ))}
                </div>
              </fieldset>
              <div className="quiz-actions">
                {step > 0 && <button type="button" className="btn btn-secondary" onClick={() => setStep(step - 1)}>Back</button>}
                <button type="button" className="btn btn-primary" disabled={answers[step] === undefined} onClick={() => (step < QUESTIONS.length - 1 ? setStep(step + 1) : setDone(true))}>
                  {step === QUESTIONS.length - 1 ? 'See my score' : 'Next'}
                </button>
              </div>
            </div>
          ) : (
            <div className="quiz-result swap-in">
              <div className="quiz-score"><span className="tabular">{score}</span><small>/100</small></div>
              <h3>{result.title}</h3>
              <p>{result.text}</p>
              <p className="quiz-note">This is a quick self-check. PropCare’s Property Health Score (A–D) comes from an on-site inspection.</p>
              <div className="quiz-actions">
                <a className="btn btn-primary" href={result.href}>{result.cta}</a>
                <button type="button" className="btn btn-secondary" onClick={() => { setStep(0); setAnswers([]); setDone(false); }}><RotateCcw aria-hidden="true" /> Start over</button>
              </div>
            </div>
          )}
        </Reveal>
      </div>
    </section>
  );
}
