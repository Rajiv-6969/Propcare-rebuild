import { useRef } from 'react';
import { ArrowRight, Camera, Clock3, MapPin } from 'lucide-react';
import { pathFor } from '../../config/routes';
import { EXTERNAL_LINK, SITE, whatsappUrl } from '../../config/site';
import { useCountUp, useInView } from '../../hooks/motion';
import { Band } from '../layout/Layout';
import { StatusPill, WhatsAppIcon } from '../ui/primitives';

const AREAS = ['Anekal', 'Electronic City', 'Sarjapur', 'Hosur Road', 'NRIs worldwide'];

/** Illustrative report built from real checklist items (section 2), clearly labelled as a sample. */
const SAMPLE_ROWS: { item: string; status: 'ok' | 'attention' | 'urgent' }[] = [
  { item: 'Locks, keys and entry points', status: 'ok' },
  { item: 'Taps run, drains and traps topped up', status: 'ok' },
  { item: 'Damp patch on bathroom ceiling', status: 'attention' },
  { item: 'MCB/RCCB trip switch tested', status: 'ok' },
  { item: 'Geyser and non-essential circuits switched off', status: 'ok' },
];

export function SampleReport() {
  return (
    <figure className="report-card" aria-label="Sample PropCare visit report">
      <div className="report-head">
        <img src="/brand/propcare-mark-96.png" width={30} height={33} alt="" />
        <div>
          <p className="report-title">Visit report</p>
          <p className="report-sub">Home Care · Care Plus · visit 2 of 2 this month</p>
        </div>
        <span className="badge badge-navy">Sample</span>
      </div>
      <ul className="report-meta" aria-label="Recorded on every visit">
        <li><MapPin aria-hidden="true" /> GPS-tagged</li>
        <li><Clock3 aria-hidden="true" /> Arrival &amp; departure</li>
        <li><Camera aria-hidden="true" /> Dated photos</li>
      </ul>
      <ul className="report-rows">
        {SAMPLE_ROWS.map((row, index) => (
          <li key={row.item} className="report-row" style={{ ['--i' as string]: index }}>
            <span>{row.item}</span>
            <StatusPill status={row.status} />
          </li>
        ))}
      </ul>
      <figcaption className="report-foot">
        <span className="score-ring" aria-hidden="true">
          <svg viewBox="0 0 44 44"><circle className="score-track" cx="22" cy="22" r="19" /><circle className="score-arc" cx="22" cy="22" r="19" pathLength={100} /></svg>
          <b>B</b>
        </span>
        <span><strong>Property Health Score: B</strong><br />Report sent within 24 hours, with a photo for anything not OK.</span>
      </figcaption>
    </figure>
  );
}

function Fact({ value, suffix, label, active }: { value: number; suffix: string; label: string; active: boolean }) {
  const shown = useCountUp(value, active);
  return (
    <div className="fact">
      <p className="fact-value">
        <span className="sr-only">{value}{suffix}</span>
        <span aria-hidden="true"><span className="tabular fact-num" style={{ minWidth: `${String(value).length}ch` }}>{shown}</span>{suffix}</span>
      </p>
      <p className="fact-label">{label}</p>
    </div>
  );
}

export function Hero() {
  const factsRef = useRef<HTMLDivElement>(null);
  const factsSeen = useInView(factsRef, { threshold: 0.4 });
  return (
    <Band className="hero" labelledBy="hero-title">
      <div className="container hero-grid">
        <div className="hero-copy">
          <p className="eyebrow hero-in" style={{ ['--i' as string]: 0 }}>Property care · Anekal &amp; Bengaluru</p>
          <h1 id="hero-title" className="hero-in" style={{ ['--i' as string]: 1 }}>Your property, cared for <em>while you’re away</em></h1>
          <p className="hero-tagline hero-in" style={{ ['--i' as string]: 2 }}>{SITE.tagline}</p>
          <p className="lead hero-in" style={{ ['--i' as string]: 3 }}>
            Scheduled visits, a written checklist and a dated photo report within 24 hours, for flats, villas, rented homes and land in and around Anekal, wherever you live.
          </p>
          <div className="hero-actions hero-in" style={{ ['--i' as string]: 4 }}>
            <a className="btn btn-primary btn-lg btn-shine" href={pathFor('packages')}>View Packages <ArrowRight aria-hidden="true" /></a>
            <a className="btn btn-on-dark btn-lg" href={whatsappUrl()} {...EXTERNAL_LINK}><WhatsAppIcon size={18} /> Chat on WhatsApp</a>
          </div>
          <ul className="hero-areas hero-in" style={{ ['--i' as string]: 5 }} aria-label="Areas we serve">
            {AREAS.map((area) => <li key={area} className="chip">{area}</li>)}
          </ul>
        </div>
        <div className="hero-visual hero-in" style={{ ['--i' as string]: 3 }}>
          <SampleReport />
        </div>
      </div>
      <div className="container">
        <div ref={factsRef} className="facts" role="list" aria-label="PropCare at a glance">
          <div role="listitem"><Fact value={3} suffix="" label="property types: homes, rentals and land" active={factsSeen} /></div>
          <div role="listitem"><Fact value={24} suffix=" hrs" label="dated photo report after every visit" active={factsSeen} /></div>
          <div role="listitem"><Fact value={24} suffix=" hrs" label="fastest repair response, on Premium" active={factsSeen} /></div>
          <div role="listitem"><Fact value={25} suffix=" km" label="around Anekal at base prices" active={factsSeen} /></div>
        </div>
      </div>
    </Band>
  );
}
