import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { AlertTriangle, ArrowRight, CheckCircle2, Info, Phone, RotateCcw } from 'lucide-react';
import { NETLIFY_FORM_NAME } from '../../config/email';
import { pathFor } from '../../config/routes';
import { EXTERNAL_LINK, SITE, planWhatsappMessage, telUrl, whatsappUrl } from '../../config/site';
import {
  ADDONS, BILLING_CYCLES, BILLING_ORDER, PLANS, PLAN_FAMILIES, PRICING_NOTES, SIZE_OPTIONS, familyById, inr, planById, plansInFamily, PORTFOLIO_TIERS,
  type AddonId, type BillingCycleId, type FamilyId, type SizeId,
} from '../../data/plans';
import { NEXT_STEPS, sendRequestEmails, submitToNetlify } from '../../lib/email';
import { savingsLabel, suggestLandPlan } from '../../lib/pricing';
import {
  CONTACT_METHODS, CONTACT_TIMES, OWNER_LOCATIONS, PROPERTY_TYPES, billedLine, estimateFor, feeFamily, planHeading, validate, valuesFromQuery, whatsappRequestMessage,
  type RequestErrors, type RequestValues,
} from '../../lib/request';
import { ChoiceGroup, SelectField, Stepper, TextAreaField, TextField } from '../ui/fields';
import { AnimatedINR, CheckList, Segmented, WhatsAppIcon } from '../ui/primitives';

type Status = 'idle' | 'sending' | 'success' | 'partial' | 'error';

const FIELD_ORDER: [keyof RequestValues, string][] = [
  ['name', 'rq-name'], ['email', 'rq-email'], ['phone', 'rq-phone'], ['cityArea', 'rq-city'], ['propertyType', 'rq-type'],
  ['monthlyRent', 'rq-rent'], ['landArea', 'rq-area'], ['numProperties', 'rq-count'], ['family', 'rq-family'], ['planId', 'rq-plan'], ['agree', 'rq-agree'],
];

const FEE_PLAN_GROUPS = PLAN_FAMILIES.filter((f) => f.id !== 'portfolio').map((family) => ({
  label: family.name,
  options: PLANS.filter((p) => p.family === family.id).map((p) => ({ value: p.id, label: `${p.name} — ${p.priceLabel}` })),
}));

function focusField(id: string) {
  const el = document.getElementById(id);
  const target = el?.matches('input, select, textarea, button') ? el : el?.querySelector<HTMLElement>('input, select, textarea, button');
  target?.focus({ preventScroll: false });
}

function SuccessMark() {
  return (
    <svg className="success-mark" viewBox="0 0 72 72" aria-hidden="true">
      <circle className="success-circle" cx="36" cy="36" r="32" pathLength={100} />
      <path className="success-tick" d="M22 37.5 31.5 47 50 27" pathLength={100} />
    </svg>
  );
}

export function RequestForm() {
  const [values, setValues] = useState<RequestValues>(() => valuesFromQuery(window.location.search));
  const [errors, setErrors] = useState<RequestErrors>({});
  const [submitted, setSubmitted] = useState(false);
  const [status, setStatus] = useState<Status>('idle');
  const [emailedTo, setEmailedTo] = useState('');
  const statusRef = useRef<HTMLDivElement>(null);
  const summaryRef = useRef<HTMLDivElement>(null);

  const est = useMemo(() => estimateFor(values), [values]);
  const plan = planById(values.planId);
  const ff = feeFamily(values);

  useEffect(() => { if (status !== 'idle' && status !== 'sending') statusRef.current?.focus(); }, [status]);

  const update = (patch: Partial<RequestValues>) => {
    const next = { ...values, ...patch };
    setValues(next);
    if (submitted) setErrors(validate(next));
  };

  const setFamily = (family: FamilyId | '') => {
    const keepPlan = family && planById(values.planId)?.family === family;
    const patch: Partial<RequestValues> = { family, planId: keepPlan ? values.planId : '' };
    if (family === 'home' || family === 'rental' || family === 'land') {
      const recommended = plansInFamily(family).find((p) => p.recommended);
      if (!keepPlan && recommended) patch.planId = recommended.id;
      if (!values.propertyType) patch.propertyType = family === 'rental' ? 'tenanted' : family === 'land' ? 'land' : 'apartment';
    }
    if (family === 'portfolio') {
      if (!keepPlan) patch.planId = Number(values.numProperties) >= 4 ? 'portfolio-4-plus' : 'portfolio-2-3';
      if (Number(values.numProperties) < 2) patch.numProperties = '2';
    }
    update(patch);
  };

  const setPropertyType = (id: string) => {
    const type = PROPERTY_TYPES.find((p) => p.id === id)!;
    const patch: Partial<RequestValues> = { propertyType: type.id };
    if (!values.family) { patch.family = type.family; const rec = plansInFamily(type.family).find((p) => p.recommended); if (rec) patch.planId = rec.id; }
    if (type.size && (values.family === 'home' || type.family === 'home') && !values.size) patch.size = type.size;
    update(patch);
  };

  const setCount = (count: string) => {
    const patch: Partial<RequestValues> = { numProperties: count };
    const n = Number(count);
    if (values.family === 'portfolio' && n >= 1) {
      const tier = PORTFOLIO_TIERS.slice().reverse().find((t) => n >= t.minProperties);
      if (tier) patch.planId = tier.id;
    }
    update(patch);
  };

  const setPlan = (planId: string) => {
    const patch: Partial<RequestValues> = { planId };
    const tier = PORTFOLIO_TIERS.find((t) => t.id === planId);
    if (tier && Number(values.numProperties) < tier.minProperties) patch.numProperties = String(tier.minProperties);
    update(patch);
  };

  const toggleAddon = (id: string, checked: boolean) => update({ addons: checked ? [...values.addons, id as AddonId] : values.addons.filter((a) => a !== id) });

  const onSubmit = async (event: FormEvent) => {
    event.preventDefault();
    if (status === 'sending') return;
    const found = validate(values);
    setErrors(found);
    setSubmitted(true);
    const first = FIELD_ORDER.find(([key]) => found[key]);
    if (first) {
      summaryRef.current?.focus();
      return;
    }
    if (values.botField) { setStatus('success'); return; }
    setStatus('sending');
    const submittedAt = `${new Intl.DateTimeFormat('en-IN', { timeZone: 'Asia/Kolkata', dateStyle: 'medium', timeStyle: 'short' }).format(new Date())} IST`;
    const [netlify, email] = await Promise.all([
      submitToNetlify(NETLIFY_FORM_NAME, values, est, submittedAt),
      sendRequestEmails(values, est, { origin: window.location.origin, submittedAt }),
    ]);
    setEmailedTo(values.email.trim());
    if (email.admin && email.customer) setStatus('success');
    else if (email.admin || netlify) setStatus('partial');
    else setStatus('error');
  };

  const errorCount = Object.keys(errors).length;
  const fallbackUrl = whatsappUrl(whatsappRequestMessage(values, est));
  const planOptions = values.family ? plansInFamily(values.family).map((p) => ({ value: p.id, label: `${p.name} — ${p.priceLabel}${p.recommended ? ' (Recommended)' : ''}` })) : [];
  const landHint = ff === 'land' && Number(values.landArea) > 0 && values.family === 'land' ? planById(suggestLandPlan(Number(values.landArea), values.landUnit)) : null;

  /* ---------------------------------------------------------------- result panels */
  if (status === 'success' || status === 'partial' || status === 'error') {
    return (
      <div className="request-layout">
        <div ref={statusRef} tabIndex={-1} className={`card result-card result-${status}`} role="status" aria-live="polite">
          {status === 'success' && (
            <>
              <SuccessMark />
              <h2>Request sent. Welcome to PropCare!</h2>
              <p className="lead">We’ve emailed a confirmation to <strong>{emailedTo || 'you'}</strong> with your plan details and estimate. {NEXT_STEPS}</p>
            </>
          )}
          {status === 'partial' && (
            <>
              <SuccessMark />
              <h2>We’ve received your request</h2>
              <p className="lead">{NEXT_STEPS}</p>
              <p className="notice notice-warn"><AlertTriangle aria-hidden="true" />We couldn’t send your confirmation email just now. For a quick confirmation, message us on WhatsApp — your details are already filled in.</p>
            </>
          )}
          {status === 'error' && (
            <>
              <AlertTriangle className="result-icon" aria-hidden="true" />
              <h2>Couldn’t send — please WhatsApp us</h2>
              <p className="lead">Something went wrong while sending your request. Tap below to send the same details to PropCare on WhatsApp, or try again.</p>
            </>
          )}
          {plan && (
            <div className="result-summary">
              <p className="mini-title">Your selection</p>
              <p><strong>{planHeading(values)}</strong> · {plan.priceLabel}</p>
              {est?.ok && <p>Estimated fee: <strong>{inr(est.effectiveMonthly)} per month</strong> ({BILLING_CYCLES[values.billing].label.toLowerCase()} billing). {PRICING_NOTES.estimate}</p>}
            </div>
          )}
          <div className="result-actions">
            <a className={`btn btn-lg ${status === 'error' ? 'btn-primary' : 'btn-secondary'}`} href={fallbackUrl} {...EXTERNAL_LINK}>
              <WhatsAppIcon size={18} /> {status === 'error' ? 'Send on WhatsApp' : 'Message us on WhatsApp'}
            </a>
            {status === 'error'
              ? <button type="button" className="btn btn-secondary btn-lg" onClick={() => setStatus('idle')}><RotateCcw aria-hidden="true" /> Try again</button>
              : <a className="btn btn-primary btn-lg" href="/">Back to home</a>}
          </div>
        </div>
      </div>
    );
  }

  /* ---------------------------------------------------------------- form */
  return (
    <div className="request-layout">
      <form className="card request-form" name={NETLIFY_FORM_NAME} method="post" noValidate onSubmit={onSubmit} aria-describedby="rq-required-note">
        <div ref={summaryRef} tabIndex={-1} className="error-summary-wrap">
          {submitted && errorCount > 0 && (
            <div className="notice notice-error error-summary" role="alert">
              <AlertTriangle aria-hidden="true" />
              <div>
                <p><strong>Please check {errorCount === 1 ? 'one field' : `${errorCount} fields`}:</strong></p>
                <ul>
                  {FIELD_ORDER.filter(([key]) => errors[key]).map(([key, id]) => (
                    <li key={key}><a href={`#${id}`} onClick={(e) => { e.preventDefault(); focusField(id); }}>{errors[key]}</a></li>
                  ))}
                </ul>
              </div>
            </div>
          )}
        </div>
        <p id="rq-required-note" className="field-hint">Fields marked <span className="req" aria-hidden="true">*</span><span className="sr-only">with an asterisk</span> are required.</p>

        <fieldset className="form-section">
          <legend><span className="step-num" aria-hidden="true">1</span> About you</legend>
          <div className="form-grid two">
            <div className="span-2"><TextField id="rq-name" label="Full name" required autoComplete="name" value={values.name} onChange={(v) => update({ name: v })} error={errors.name} maxLength={80} /></div>
            <TextField id="rq-email" label="Email" type="email" inputMode="email" required autoComplete="email" value={values.email} onChange={(v) => update({ email: v })} error={errors.email} hint="We’ll send your confirmation here." maxLength={120} />
            <TextField id="rq-phone" label="Phone / WhatsApp" type="tel" inputMode="tel" required autoComplete="tel" value={values.phone} onChange={(v) => update({ phone: v })} error={errors.phone} hint="Include the country code if you’re outside India." maxLength={20} />
            <SelectField id="rq-time" label="Preferred contact time" value={values.contactTime} onChange={(v) => update({ contactTime: v })} options={CONTACT_TIMES.map((t) => ({ value: t, label: t }))} placeholder="Any time" />
            <SelectField id="rq-method" label="Preferred way to reach you" value={values.contactMethod} onChange={(v) => update({ contactMethod: v })} options={CONTACT_METHODS.map((t) => ({ value: t, label: t }))} placeholder="No preference" />
            <div className="span-2">
              <ChoiceGroup id="rq-location" legend="Where do you live now?" value={values.ownerLocation} onChange={(v) => update({ ownerLocation: v })}
                choices={OWNER_LOCATIONS.map((l) => ({ value: l, title: l }))} />
            </div>
          </div>
        </fieldset>

        <fieldset className="form-section">
          <legend><span className="step-num" aria-hidden="true">2</span> Your property</legend>
          <div className="form-grid">
            <TextField id="rq-city" label="City / area of the property" required value={values.cityArea} onChange={(v) => update({ cityArea: v })} error={errors.cityArea}
              hint="For example: Anekal, Electronic City, Sarjapur Road." maxLength={120} />
            <ChoiceGroup id="rq-type" legend="Property type" required value={values.propertyType} onChange={setPropertyType} error={errors.propertyType}
              choices={PROPERTY_TYPES.map((p) => ({ value: p.id, title: p.label }))} />
            {ff === 'home' && (
              <div className="reveal-field swap-in">
                <ChoiceGroup id="rq-size" legend="Property size" value={values.size} onChange={(v) => update({ size: v as SizeId })} hint={PRICING_NOTES.sizeAddon}
                  choices={SIZE_OPTIONS.map((s) => ({ value: s.id, title: s.label, detail: s.addon ? `+${inr(s.addon)}/month` : 'No add-on' }))} />
              </div>
            )}
            {ff === 'rental' && (
              <div className="reveal-field swap-in">
                <TextField id="rq-rent" label="Monthly rent" required prefix="₹" inputMode="numeric" value={values.monthlyRent}
                  onChange={(v) => update({ monthlyRent: v.replace(/[^\d]/g, '').slice(0, 8) })} error={errors.monthlyRent} hint="Used to estimate the Rental Care fee (a percentage of the rent)." />
              </div>
            )}
            {ff === 'land' && (
              <div className="reveal-field swap-in area-row">
                <TextField id="rq-area" label="Land area" required inputMode="decimal" value={values.landArea} onChange={(v) => update({ landArea: v.replace(/[^\d.]/g, '').slice(0, 9) })}
                  error={errors.landArea} hint={landHint && landHint.id !== values.planId ? `For this area, ${landHint.name} fits: ${landHint.priceLabel}.` : PRICING_NOTES.landLimits} />
                <Segmented label="Area unit" value={values.landUnit} onChange={(u) => update({ landUnit: u })} options={[{ value: 'sqft', label: 'sq ft' }, { value: 'acres', label: 'acres' }]} />
              </div>
            )}
            <Stepper id="rq-count" label="Number of properties" value={values.numProperties} onChange={setCount} error={errors.numProperties}
              min={values.family === 'portfolio' ? 2 : 1} hint={PRICING_NOTES.portfolio} />
          </div>
        </fieldset>

        <fieldset className="form-section">
          <legend><span className="step-num" aria-hidden="true">3</span> Your plan</legend>
          <div className="form-grid two">
            <SelectField id="rq-family" label="Plan family" required value={values.family} onChange={(v) => setFamily(v as FamilyId | '')} error={errors.family}
              options={PLAN_FAMILIES.map((f) => ({ value: f.id, label: `${f.name} — ${f.audience}` }))} placeholder="Choose a plan family" />
            <SelectField id="rq-plan" label="Plan" required value={values.planId} onChange={setPlan} error={errors.planId} options={planOptions}
              placeholder={values.family ? 'Choose a plan' : 'Choose a plan family first'} />
            {values.family === 'portfolio' && (
              <div className="span-2 swap-in">
                <SelectField id="rq-base" label="Plan for each property" value={values.basePlanId} onChange={(v) => v && update({ basePlanId: v })} groups={FEE_PLAN_GROUPS}
                  hint="Mixing plans across properties? Tell us in the message and we’ll tailor the quote." />
              </div>
            )}
            <div className="span-2 field">
              <span className="field-label">Billing preference</span>
              <Segmented label="Billing preference" value={values.billing} onChange={(b: BillingCycleId) => update({ billing: b })}
                options={BILLING_ORDER.map((c) => ({ value: c, label: BILLING_CYCLES[c].label, sub: BILLING_CYCLES[c].badge ?? 'Pay as you go' }))} />
            </div>
            <div className="span-2">
              <ChoiceGroup id="rq-addons" type="checkbox" legend="Add-ons (optional)" values={values.addons} onToggle={toggleAddon} columns={2}
                choices={ADDONS.map((a) => ({ value: a.id, title: a.label, detail: a.detail }))} />
            </div>
          </div>
        </fieldset>

        <fieldset className="form-section">
          <legend><span className="step-num" aria-hidden="true">4</span> Anything else?</legend>
          <TextAreaField id="rq-message" label="Message / special requirements" value={values.message} onChange={(v) => update({ message: v })} maxLength={1500}
            hint="Keys, access, tenants, known issues or anything we should know." />
          <p className="sr-only" aria-hidden="true">
            <label>Leave this empty: <input name="bot-field" tabIndex={-1} autoComplete="off" value={values.botField} onChange={(e) => update({ botField: e.target.value })} /></label>
          </p>
          <div className="field consent-field">
            <label className="consent" htmlFor="rq-agree">
              <input id="rq-agree" type="checkbox" checked={values.agree} onChange={(e) => update({ agree: e.target.checked })}
                aria-invalid={errors.agree ? true : undefined} aria-describedby={errors.agree ? 'rq-agree-error' : undefined} aria-required="true" />
              <span>I agree to the <a href={pathFor('terms')} target="_blank" rel="noopener">Terms &amp; Conditions</a><span className="req" aria-hidden="true">*</span></span>
            </label>
            {errors.agree && <p className="field-error" id="rq-agree-error"><AlertTriangle aria-hidden="true" />{errors.agree}</p>}
          </div>
        </fieldset>

        <button type="submit" className="btn btn-primary btn-lg btn-block" disabled={status === 'sending'} aria-busy={status === 'sending'}>
          {status === 'sending' ? <><span className="spinner" aria-hidden="true" /> Sending your request…</> : <>Submit request <ArrowRight aria-hidden="true" /></>}
        </button>
        <p className="form-foot">We’ll email you a summary of your plan and send a copy to PropCare. Your details are used only to respond to this request. <a href={pathFor('privacy')}>Privacy</a>.</p>
      </form>

      <aside className="request-aside" aria-label="Your selection">
        <div className="card selection-card">
          <p className="eyebrow">Your selection</p>
          {plan ? (
            <>
              <h2 className="selection-title">{familyById(plan.family).name} — {plan.name}</h2>
              <p className="selection-price">{plan.priceLabel}</p>
              {est?.ok ? (
                <div className="selection-est">
                  <p className="est-total"><AnimatedINR value={est.effectiveMonthly} /><span>/month</span></p>
                  <p className="est-billed">{billedLine(est)}</p>
                  {savingsLabel(values.billing, est.savingsPerYear) && <p><span className="badge">{savingsLabel(values.billing, est.savingsPerYear)}</span></p>}
                </div>
              ) : <p className="est-missing"><Info aria-hidden="true" /> {est?.missing}</p>}
              {est && est.oneTime.length > 0 && (
                <dl className="est-lines">{est.oneTime.map((line) => <div key={line.id} className="est-line"><dt>{line.label}</dt><dd>{line.display}</dd></div>)}</dl>
              )}
              <details className="selection-features">
                <summary>What’s included ({(plan.family === 'portfolio' && est ? est.feePlan.features.length + plan.features.length : plan.features.length)})</summary>
                <CheckList items={plan.family === 'portfolio' && est ? [...plan.features, ...est.feePlan.features] : plan.features} compact />
              </details>
              <p className="est-note">{PRICING_NOTES.estimate}</p>
            </>
          ) : (
            <p className="selection-empty">Choose a plan to see what’s included and your estimated fee. <a href={pathFor('packages')}>Compare plans</a>.</p>
          )}
        </div>
        <div className="card talk-card">
          <h2>Prefer to talk?</h2>
          <p>WhatsApp is the fastest way to reach us. Working hours {SITE.hours}.</p>
          <a className="btn btn-secondary btn-block" href={whatsappUrl(plan ? planWhatsappMessage(plan.name) : undefined)} {...EXTERNAL_LINK}><WhatsAppIcon size={18} /> Chat on WhatsApp</a>
          <a className="btn btn-secondary btn-block" href={telUrl}><Phone aria-hidden="true" /> Call {SITE.phoneDisplay}</a>
        </div>
        <p className="aside-note"><CheckCircle2 aria-hidden="true" /> {PRICING_NOTES.perProperty}</p>
      </aside>
    </div>
  );
}
