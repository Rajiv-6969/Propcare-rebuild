import { useEffect, useMemo, useState } from 'react';
import { ArrowRight, Calculator, Check, Info, Minus } from 'lucide-react';
import { pathFor } from '../../config/routes';
import { EXTERNAL_LINK, planWhatsappMessage, whatsappUrl } from '../../config/site';
import {
  ADDONS, BILLING_CYCLES, BILLING_ORDER, COMPARISON, PLANS, PLAN_FAMILIES, PORTFOLIO_TIERS, PRICING_NOTES, SIZE_OPTIONS, billingFactor, familyById, inr, planById,
  type AddonId, type BillingCycleId, type FamilyId, type Plan, type SizeId,
} from '../../data/plans';
import { cardPrice, estimate, savingsLabel, suggestLandPlan, type LandUnit } from '../../lib/pricing';
import { ChoiceGroup, SelectField, Stepper, TextField } from '../ui/fields';
import { AnimatedINR, CheckList, Segmented, WhatsAppIcon } from '../ui/primitives';

export function requestHref(params: Record<string, string | number | undefined | null>): string {
  const q = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) if (value !== undefined && value !== null && value !== '') q.set(key, String(value));
  return `${pathFor('request')}?${q.toString()}`;
}

/* ------------------------------------------------------------------ billing toggle */
export function BillingToggle({ value, onChange, id }: { value: BillingCycleId; onChange: (v: BillingCycleId) => void; id?: string }) {
  return (
    <Segmented id={id} label="Billing cycle" value={value} onChange={onChange}
      options={BILLING_ORDER.map((cycle) => ({ value: cycle, label: BILLING_CYCLES[cycle].label, sub: BILLING_CYCLES[cycle].badge ?? 'Pay as you go' }))} />
  );
}

/* ------------------------------------------------------------------ plan card */
function PriceBlock({ plan, billing }: { plan: Plan; billing: BillingCycleId }) {
  const price = cardPrice(plan, billing);
  const cycle = BILLING_CYCLES[billing];
  const saving = savingsLabel(billing, price.savings);
  const p = plan.pricing;

  if (p.kind === 'portfolio') {
    const tier = PORTFOLIO_TIERS.find((t) => t.id === p.tier)!;
    return (
      <div className="price">
        <p className="price-main"><span className="price-amount">{Math.round(tier.discount * 100)}%</span><span className="price-unit">off combined fees</span></p>
        <p className="price-sub">{plan.pricingRule}</p>
        {billing !== 'monthly' && <p className="price-sub">Plus the {cycle.label.toLowerCase()} billing saving ({cycle.badge}).</p>}
      </div>
    );
  }
  if (p.kind === 'rentPercent') {
    return (
      <div className="price">
        <p className="price-main"><span className="price-amount">{Math.round(p.percent * 100)}%</span><span className="price-unit">of monthly rent</span></p>
        <p className="price-sub">Minimum <AnimatedINR value={price.amount!} />/month{billing !== 'monthly' && <> effective · {inr(price.billed!)} {cycle.per}</>}</p>
        {saving && <p className="price-save"><span className="badge">{cycle.badge}</span></p>}
      </div>
    );
  }
  return (
    <div className="price">
      <p className="price-main">
        <AnimatedINR className="price-amount" value={price.amount!} />
        <span className="price-unit">/month{p.kind === 'perAcre' ? ', first acre' : ''}</span>
      </p>
      <p className="price-sub">
        {billing === 'monthly' ? 'Billed monthly' : <>{inr(price.billed!)} billed {cycle.per}</>}
        {billing !== 'monthly' && <> · <s className="price-was">{inr(plan.basePrice!)}</s></>}
        {p.kind === 'perAcre' && <> · +{inr(p.perExtraAcre)} per extra acre</>}
      </p>
      {saving && <p className="price-save"><span className="badge">{saving}</span></p>}
    </div>
  );
}

export function PlanCard({ plan, billing, index, onEstimate }: { plan: Plan; billing: BillingCycleId; index: number; onEstimate: (planId: string) => void }) {
  return (
    <article className={`plan-card card swap-in ${plan.recommended ? 'is-recommended' : ''}`} style={{ ['--i' as string]: index }} aria-labelledby={`plan-${plan.id}`}>
      {plan.recommended && <p className="plan-flag"><span className="badge badge-solid">Recommended</span></p>}
      <h3 id={`plan-${plan.id}`}>{plan.name}</h3>
      <p className="plan-summary">{plan.summary}</p>
      <PriceBlock plan={plan} billing={billing} />
      <p className="plan-label">{plan.priceLabel}</p>
      <CheckList items={plan.features} compact className="plan-features" />
      <div className="plan-actions">
        <a className={`btn btn-block ${plan.recommended ? 'btn-primary btn-shine' : 'btn-navy'}`} href={requestHref({ plan: plan.id, billing })}>
          Choose this plan <ArrowRight aria-hidden="true" />
        </a>
        <div className="plan-links">
          <a className="link-arrow" href="#estimator" onClick={() => onEstimate(plan.id)}><Calculator aria-hidden="true" /> Estimate my fee</a>
          <a className="link-arrow" href={whatsappUrl(planWhatsappMessage(plan.name))} {...EXTERNAL_LINK}><WhatsAppIcon size={16} /> Ask on WhatsApp</a>
        </div>
      </div>
    </article>
  );
}

export function FamilyNote({ family }: { family: FamilyId }) {
  const note = family === 'home' ? PRICING_NOTES.sizeAddon
    : family === 'rental' ? PRICING_NOTES.tenantPlacement
      : family === 'land' ? PRICING_NOTES.landLimits
        : PRICING_NOTES.portfolioCombined;
  return <p className="family-note-line"><Info aria-hidden="true" /> {note}</p>;
}

/* ------------------------------------------------------------------ comparison table */
function Cell({ value }: { value: string }) {
  if (value === 'Yes') return <span className="cell-yes"><Check aria-hidden="true" /><span>Included</span></span>;
  if (value === '—') return <span className="cell-no"><span className="sr-only">Not included</span></span>;
  if (value.startsWith('Yes + ')) return <span className="cell-yes"><Check aria-hidden="true" /><span>{value.replace('Yes + ', 'Included + ')}</span></span>;
  return <span>{value}</span>;
}

export function ComparisonTable({ family }: { family: FamilyId }) {
  const table = COMPARISON[family];
  const plans = table.planIds.map((id) => planById(id)!);
  return (
    <div className="table-wrap compare">
      <table className="data-table stack">
        <caption className="sr-only">{familyById(family).name}: what each plan includes</caption>
        <thead>
          <tr>
            <th scope="col">{table.firstColumn}</th>
            {plans.map((plan) => (
              <th scope="col" key={plan.id} className={plan.recommended ? 'highlight' : undefined}>
                {plan.name}{plan.recommended && <span className="badge badge-solid th-badge">Recommended</span>}
                <span className="th-price">{plan.priceLabel}</span>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {table.rows.map((row) => (
            <tr key={row.label}>
              <th scope="row">{row.label}</th>
              {plans.map((plan) => (
                <td key={plan.id} data-label={plan.name} className={plan.recommended ? 'highlight' : undefined}><Cell value={row.values[plan.id]} /></td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ------------------------------------------------------------------ estimator */
const PLAN_GROUPS = PLAN_FAMILIES.map((family) => ({
  label: family.name,
  options: PLANS.filter((p) => p.family === family.id).map((p) => ({ value: p.id, label: `${p.name} — ${p.priceLabel}` })),
}));
const FEE_PLAN_OPTIONS = PLAN_FAMILIES.filter((f) => f.id !== 'portfolio').map((family) => ({
  label: family.name,
  options: PLANS.filter((p) => p.family === family.id).map((p) => ({ value: p.id, label: `${p.name} — ${p.priceLabel}` })),
}));

export function Estimator({ planId, setPlanId, billing, setBilling }: {
  planId: string; setPlanId: (id: string) => void; billing: BillingCycleId; setBilling: (b: BillingCycleId) => void;
}) {
  const [size, setSize] = useState<SizeId>('upto-2bhk');
  const [rent, setRent] = useState('');
  const [area, setArea] = useState('');
  const [unit, setUnit] = useState<LandUnit>('sqft');
  const [count, setCount] = useState('1');
  const [basePlanId, setBasePlanId] = useState('care-plus');
  const [addons, setAddons] = useState<AddonId[]>([]);

  const plan = planById(planId) ?? planById('care-plus')!;
  const isPortfolio = plan.family === 'portfolio';
  const feePlan = isPortfolio ? planById(basePlanId)! : plan;
  const minCount = PORTFOLIO_TIERS.find((t) => t.id === plan.id)?.minProperties ?? 1;
  useEffect(() => { if ((Number(count) || 1) < minCount) setCount(String(minCount)); }, [minCount, count]);
  const result = useMemo(() => estimate({
    planId: plan.id, basePlanId, size, monthlyRent: Number(rent) || null, landArea: Number(area) || null, landUnit: unit,
    numProperties: Number(count) || 1, billing, addons,
  }), [plan.id, basePlanId, size, rent, area, unit, count, billing, addons]);

  const landHint = feePlan.family === 'land' && Number(area) > 0 ? planById(suggestLandPlan(Number(area), unit)) : null;
  const toggleAddon = (id: string, checked: boolean) => setAddons((list) => (checked ? [...list, id as AddonId] : list.filter((a) => a !== id)));
  const href = requestHref({
    plan: plan.id, billing, n: Number(count) > 1 ? count : undefined, base: isPortfolio ? basePlanId : undefined,
    size: feePlan.family === 'home' ? size : undefined, rent: feePlan.family === 'rental' ? rent : undefined,
    area: feePlan.family === 'land' ? area : undefined, unit: feePlan.family === 'land' && area ? unit : undefined,
    addons: addons.length ? addons.join(',') : undefined,
  });
  const factor = billingFactor(billing);

  return (
    <div className="estimator card">
      <div className="estimator-form">
        <SelectField id="est-plan" label="Plan" value={plan.id} onChange={(v) => v && setPlanId(v)} groups={PLAN_GROUPS} placeholder="Choose a plan" />
        {isPortfolio && <SelectField id="est-base" label="Plan for each property" value={basePlanId} onChange={(v) => v && setBasePlanId(v)} groups={FEE_PLAN_OPTIONS} />}
        {feePlan.family === 'home' && (
          <ChoiceGroup id="est-size" legend="Property size" value={size} onChange={(v) => setSize(v as SizeId)}
            choices={SIZE_OPTIONS.map((s) => ({ value: s.id, title: s.label, detail: s.addon ? `+${inr(s.addon)}/month` : 'No add-on' }))} />
        )}
        {feePlan.family === 'rental' && (
          <TextField id="est-rent" label="Monthly rent" prefix="₹" inputMode="numeric" value={rent} onChange={(v) => setRent(v.replace(/[^\d]/g, '').slice(0, 8))}
            hint={feePlan.pricing.kind === 'rentPercent' ? `${Math.round(feePlan.pricing.percent * 100)}% of the rent, minimum ${inr(feePlan.pricing.minimum)} a month.` : undefined} />
        )}
        {feePlan.family === 'land' && (
          <div className="area-row">
            <TextField id="est-area" label="Land area" inputMode="decimal" value={area} onChange={(v) => setArea(v.replace(/[^\d.]/g, '').slice(0, 9))}
              hint={landHint && landHint.id !== feePlan.id ? `For this area, ${landHint.name} fits: ${landHint.priceLabel}.` : undefined} />
            <Segmented label="Area unit" value={unit} onChange={setUnit} options={[{ value: 'sqft', label: 'sq ft' }, { value: 'acres', label: 'acres' }]} />
          </div>
        )}
        <Stepper id="est-count" label="Number of properties" value={count} onChange={setCount} min={minCount}
          hint={PRICING_NOTES.portfolio} />
        <div className="field">
          <span className="field-label" id="est-billing-label">Billing cycle</span>
          <BillingToggle value={billing} onChange={setBilling} />
        </div>
        <ChoiceGroup id="est-addons" type="checkbox" legend="One-time add-ons (optional)" values={addons} onToggle={toggleAddon} columns={2}
          choices={ADDONS.map((a) => ({ value: a.id, title: a.label, detail: a.detail }))} />
      </div>

      <aside className="estimator-result" aria-live="polite" aria-atomic="true">
        <div className="estimator-sticky">
        <p className="eyebrow">Your estimate</p>
        <p className="est-plan">{familyById(plan.family).name} — {plan.name}{isPortfolio && <> · each property on {feePlan.name}</>}</p>
        {result.ok ? (
          <>
            <p className="est-total"><AnimatedINR value={result.effectiveMonthly} /><span>/month</span></p>
            <p className="est-billed">
              {billing === 'monthly' ? `${inr(result.billedAmount)} billed every month` : `${inr(result.billedAmount)} billed ${BILLING_CYCLES[billing].per}`}
              {factor < 1 && <span className="badge">{savingsLabel(billing, result.savingsPerYear)}</span>}
            </p>
          </>
        ) : (
          <p className="est-missing">{result.missing}</p>
        )}
        <dl className="est-lines">
          {result.lines.map((line, i) => (
            <div key={i} className={`est-line est-${line.kind}`}>
              <dt>{line.label}</dt>
              <dd className="tabular">{line.kind === 'discount' ? <><Minus aria-hidden="true" size={12} />{inr(Math.abs(line.amount))}</> : inr(line.amount)}</dd>
            </div>
          ))}
        </dl>
        {result.warnings.map((w) => <p key={w} className="notice notice-warn"><Info aria-hidden="true" />{w}</p>)}
        {result.oneTime.length > 0 && (
          <div className="est-onetime">
            <p className="mini-title">One-time and on-demand</p>
            <dl className="est-lines">
              {result.oneTime.map((line) => <div key={line.id} className="est-line"><dt>{line.label}{line.note && <small> ({line.note})</small>}</dt><dd>{line.display}</dd></div>)}
            </dl>
          </div>
        )}
        <p className="est-note">Excl. GST. {PRICING_NOTES.vendorCosts} {result.notes.filter((n) => n !== PRICING_NOTES.vendorCosts).join(' ')}</p>
        <div className="est-actions">
          <a className="btn btn-primary btn-block" href={href}>Request this plan <ArrowRight aria-hidden="true" /></a>
          <a className="btn btn-secondary btn-block" href={whatsappUrl(`Hi PropCare, I'm interested in the ${plan.name} plan.${result.ok ? ` Your website estimates ${inr(result.effectiveMonthly)}/month (excl. GST).` : ''}`)} {...EXTERNAL_LINK}>
            <WhatsAppIcon size={18} /> Ask about this on WhatsApp
          </a>
        </div>
        </div>
      </aside>
    </div>
  );
}
