import { useEffect, useRef, useState } from 'react';
import { Menu, Moon, Phone, Sun, X, ArrowRight } from 'lucide-react';
import { NAV_ROUTES, pathFor, type RouteId } from '../../config/routes';
import { EXTERNAL_LINK, SITE, telUrl, whatsappUrl } from '../../config/site';
import { useScrolled } from '../../hooks/motion';
import { WhatsAppIcon } from '../ui/primitives';

type Theme = 'light' | 'dark';

function currentTheme(): Theme {
  return document.documentElement.dataset.theme === 'dark' ? 'dark' : 'light';
}

function applyTheme(theme: Theme) {
  document.documentElement.dataset.theme = theme;
  try { localStorage.setItem('pc-theme', theme); } catch { /* storage may be blocked */ }
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', theme === 'dark' ? '#061321' : '#0b3c6c');
}

export function BrandLink({ compact = false }: { compact?: boolean }) {
  return (
    <a className="brand" href="/" aria-label="PropCare home">
      <img className="brand-mark" src="/brand/propcare-mark-96.png" srcSet="/brand/propcare-mark-96.png 1x, /brand/propcare-mark-192.png 2x" width={40} height={44} alt="" />
      <span className="brand-text">
        <span className="brand-name">Prop<span>Care</span></span>
        {!compact && <span className="brand-sub">PRIVATE LIMITED</span>}
      </span>
    </a>
  );
}

export function Header({ routeId }: { routeId: RouteId }) {
  const scrolled = useScrolled(8);
  const [open, setOpen] = useState(false);
  const [theme, setTheme] = useState<Theme>(currentTheme);
  const toggleRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    document.body.classList.toggle('menu-open', open);
    if (!open) return;
    const onKey = (event: KeyboardEvent) => { if (event.key === 'Escape') { setOpen(false); toggleRef.current?.focus(); } };
    const onResize = () => { if (window.innerWidth >= 1080) setOpen(false); };
    window.addEventListener('keydown', onKey);
    window.addEventListener('resize', onResize);
    return () => { window.removeEventListener('keydown', onKey); window.removeEventListener('resize', onResize); document.body.classList.remove('menu-open'); };
  }, [open]);

  const toggleTheme = () => {
    const next: Theme = theme === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    setTheme(next);
  };

  const navLinks = NAV_ROUTES.map((route) => ({ id: route.id, label: route.nav!, href: route.path }));

  return (
    <>
      <header className={`site-header ${scrolled ? 'is-scrolled' : ''} ${open ? 'is-open' : ''}`}>
        <div className="container header-inner">
          <BrandLink />
          <nav className="main-nav" aria-label="Main">
            <ul>
              {navLinks.map((link) => (
                <li key={link.id}><a className="nav-link" href={link.href} aria-current={routeId === link.id ? 'page' : undefined}>{link.label}</a></li>
              ))}
            </ul>
          </nav>
          <div className="header-actions">
            <button type="button" className="icon-btn" onClick={toggleTheme} aria-label={theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'} title={theme === 'dark' ? 'Light theme' : 'Dark theme'}>
              {theme === 'dark' ? <Sun size={18} aria-hidden="true" /> : <Moon size={18} aria-hidden="true" />}
            </button>
            <a className="icon-btn" href={whatsappUrl()} {...EXTERNAL_LINK} aria-label="Chat with PropCare on WhatsApp (opens WhatsApp)" title="Chat on WhatsApp">
              <WhatsAppIcon size={18} />
            </a>
            <a className="btn btn-primary btn-sm header-cta" href={pathFor('request')} aria-current={routeId === 'request' ? 'page' : undefined}>Submit a Request</a>
            <button ref={toggleRef} type="button" className="icon-btn menu-toggle" aria-expanded={open} aria-controls="mobile-menu" aria-label={open ? 'Close menu' : 'Open menu'} onClick={() => setOpen((v) => !v)}>
              {open ? <X size={20} aria-hidden="true" /> : <Menu size={20} aria-hidden="true" />}
            </button>
          </div>
        </div>
      </header>
      {open && (
        <div id="mobile-menu" className="mobile-menu" role="dialog" aria-modal="false" aria-label="Menu">
          <nav className="container" aria-label="Mobile">
            <ul>
              <li><a className="mobile-link" href="/" aria-current={routeId === 'home' ? 'page' : undefined}>Home <ArrowRight size={18} aria-hidden="true" /></a></li>
              {navLinks.map((link) => (
                <li key={link.id}><a className="mobile-link" href={link.href} aria-current={routeId === link.id ? 'page' : undefined}>{link.label} <ArrowRight size={18} aria-hidden="true" /></a></li>
              ))}
            </ul>
            <div className="menu-actions">
              <a className="btn btn-primary btn-lg" href={pathFor('request')}>Submit a Request</a>
              <a className="btn btn-secondary btn-lg" href={whatsappUrl()} {...EXTERNAL_LINK}><WhatsAppIcon size={18} /> Chat on WhatsApp</a>
              <a className="btn btn-secondary btn-lg" href={telUrl}><Phone aria-hidden="true" /> Call {SITE.phoneDisplay}</a>
            </div>
          </nav>
        </div>
      )}
    </>
  );
}
