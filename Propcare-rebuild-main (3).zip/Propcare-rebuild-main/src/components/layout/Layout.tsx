import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Clock, Mail, MapPin, Phone } from 'lucide-react';
import { pathFor, type RouteId } from '../../config/routes';
import { EXTERNAL_LINK, SITE, mailtoUrl, telUrl, whatsappUrl } from '../../config/site';
import { useInitialHashScroll, usePauseOffscreen } from '../../hooks/motion';
import BeamWordmarkFooter from '../ui/beam-wordmark-footer';
import { WhatsAppIcon } from '../ui/primitives';
import { Header } from './Header';

export function SiteFooter() {
  return (
    <BeamWordmarkFooter
      brand="PropCare"
      wordmark="PropCare"
      company={SITE.legalName}
      tagline={SITE.tagline}
      credits={[
        { lead: 'Property care in ', label: 'Bengaluru', tail: ' for owners wherever they are.' },
        { lead: 'Questions? ', label: 'WhatsApp PropCare', href: whatsappUrl() },
      ]}
      columns={[
        { title: 'Explore', links: [
          { label: 'About Us', href: pathFor('about') },
          { label: 'Services', href: pathFor('services') },
          { label: 'What We Check', href: pathFor('what-we-check') },
          { label: 'Packages', href: pathFor('packages') },
        ] },
        { title: 'Start here', links: [
          { label: 'Submit a Request', href: pathFor('request') },
          { label: 'Contact Us', href: pathFor('contact') },
          { label: 'Terms & Conditions', href: pathFor('terms') },
          { label: 'Privacy', href: pathFor('privacy') },
        ] },
      ]}
      aside={(
        <>
          <p className="bwf-heading">Contact</p>
          <p className="bwf-contact"><WhatsAppIcon size={18} /><span><a href={whatsappUrl()} {...EXTERNAL_LINK}>WhatsApp {SITE.phoneDisplay}</a></span></p>
          <p className="bwf-contact"><Phone aria-hidden="true" /><span><a href={telUrl}>Call {SITE.phoneDisplay}</a></span></p>
          <p className="bwf-contact"><Mail aria-hidden="true" /><span><a href={mailtoUrl}>{SITE.email}</a></span></p>
          <p className="bwf-contact"><MapPin aria-hidden="true" /><span>{SITE.address}</span></p>
          <p className="bwf-contact"><Clock aria-hidden="true" /><span>Working hours {SITE.hours}</span></p>
        </>
      )}
    />
  );
}

/** Floating WhatsApp button, bottom-right on every page. Pulses once per visit. */
export function WhatsAppFloat() {
  const [pulse, setPulse] = useState(false);
  useEffect(() => {
    let done = false;
    try { done = sessionStorage.getItem('pc-wa-pulsed') === '1'; sessionStorage.setItem('pc-wa-pulsed', '1'); } catch { /* ignore */ }
    if (done || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const start = window.setTimeout(() => setPulse(true), 1400);
    const stop = window.setTimeout(() => setPulse(false), 2400);
    return () => { window.clearTimeout(start); window.clearTimeout(stop); };
  }, []);
  return (
    <a className={`wa-float ${pulse ? 'pulse' : ''}`} href={whatsappUrl()} {...EXTERNAL_LINK} aria-label="Chat with PropCare on WhatsApp (opens WhatsApp)">
      <WhatsAppIcon size={24} />
      <span className="wa-float-label" aria-hidden="true">Chat on WhatsApp</span>
    </a>
  );
}

/** Navy hero band with slow ambient glow (paused off screen). */
export function Band({ as: Tag = 'section', className = '', children, grid = true, labelledBy }: { as?: 'section' | 'div'; className?: string; children: ReactNode; grid?: boolean; labelledBy?: string }) {
  const ref = useRef<HTMLElement>(null);
  usePauseOffscreen(ref);
  return (
    <Tag ref={ref as never} className={`band ${className}`} aria-labelledby={labelledBy}>
      <div className="band-glow" aria-hidden="true" />
      {grid && <div className="band-grid" aria-hidden="true" />}
      {children}
    </Tag>
  );
}

export function PageHero({ eyebrow, title, lead, children, id = 'page-title' }: { eyebrow: string; title: ReactNode; lead?: ReactNode; children?: ReactNode; id?: string }) {
  return (
    <Band className="page-hero" labelledBy={id}>
      <div className="container">
        <p className="eyebrow hero-in" style={{ ['--i' as string]: 0 }}>{eyebrow}</p>
        <h1 id={id} className="hero-in" style={{ ['--i' as string]: 1 }}>{title}</h1>
        {lead && <p className="lead hero-in" style={{ ['--i' as string]: 2 }}>{lead}</p>}
        {children && <div className="hero-in" style={{ ['--i' as string]: 3 }}>{children}</div>}
      </div>
    </Band>
  );
}

export function CtaBand({ title, text, primary, secondary }: {
  title: ReactNode; text: ReactNode; primary?: { label: string; href: string }; secondary?: { label: string; href: string; whatsapp?: boolean };
}) {
  return (
    <section className="section-tight">
      <div className="container">
        <Band as="div" className="cta-band">
          <div className="cta-band-inner">
            <div>
              <h2>{title}</h2>
              <p>{text}</p>
            </div>
            <div className="cta-actions">
              {primary && <a className="btn btn-primary btn-lg btn-shine" href={primary.href}>{primary.label}</a>}
              {secondary && (
                <a className="btn btn-on-dark btn-lg" href={secondary.href} {...(secondary.whatsapp ? EXTERNAL_LINK : {})}>
                  {secondary.whatsapp && <WhatsAppIcon size={18} />}{secondary.label}
                </a>
              )}
            </div>
          </div>
        </Band>
      </div>
    </section>
  );
}

export function Layout({ routeId, children }: { routeId: RouteId; children: ReactNode }) {
  useInitialHashScroll();
  return (
    <>
      <a className="skip-link" href="#main">Skip to content</a>
      <Header routeId={routeId} />
      <main id="main" tabIndex={-1}>{children}</main>
      <SiteFooter />
      <WhatsAppFloat />
    </>
  );
}
