import type { ComponentType } from 'react';
import { Layout } from './components/layout/Layout';
import { routeFor, type RouteId } from './config/routes';
import AboutPage from './pages/About';
import ContactPage from './pages/Contact';
import HomePage from './pages/Home';
import NotFoundPage from './pages/NotFound';
import PackagesPage from './pages/Packages';
import PrivacyPage from './pages/Privacy';
import RequestPage from './pages/Request';
import ServicesPage from './pages/Services';
import TermsPage from './pages/Terms';
import WhatWeCheckPage from './pages/WhatWeCheck';

/* Every page is a real HTML file (see vite.config.ts); this picks the component for it. */
const PAGES: Record<RouteId, ComponentType> = {
  home: HomePage,
  about: AboutPage,
  services: ServicesPage,
  'what-we-check': WhatWeCheckPage,
  packages: PackagesPage,
  request: RequestPage,
  contact: ContactPage,
  terms: TermsPage,
  privacy: PrivacyPage,
  'not-found': NotFoundPage,
};

export default function App() {
  const route = routeFor(window.location.pathname);
  const Page = PAGES[route.id];
  return (
    <Layout routeId={route.id}>
      <Page />
    </Layout>
  );
}
