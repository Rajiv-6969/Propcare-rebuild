# Email setup (EmailJS)

When someone sends the **Submit a Request** form, the website sends two emails through
[EmailJS](https://www.emailjs.com), straight from the browser. No server is needed.

| Email | Goes to | Template file |
|---|---|---|
| Confirmation of the chosen plan | The customer | `email-templates/customer-confirmation.html` |
| New-request notification with every form field | propcare.admin@gmail.com | `email-templates/admin-notification.html` |

The customer email follows the required order: Welcome → Thank you → plan details and estimate →
What happens next → Contact → Sign-off. Replying to the notification goes straight to the customer.

The request is also saved in **Netlify Forms** (form name `property-request`). If the confirmation
can't be sent, the visitor is offered WhatsApp with their request already written in. If nothing
could be sent at all, they see "Couldn't send — please WhatsApp us".

**Free plan:** 200 requests a month and 2 templates. Each form submission uses 2 requests (one per
email), so the free plan covers about **100 submissions a month**. On the free plan, emails end with
a small "Email sent via EmailJS.com" footer, and Email History is kept for 7 days. The paid plans
remove the footer and keep history for 30 days.

It takes about 15 minutes. You need to be able to sign in to propcare.admin@gmail.com.

---

## 1. Create the account and connect Gmail

1. Go to <https://www.emailjs.com> → **Sign Up Free**. Use propcare.admin@gmail.com.
2. Open **Email Services** → **Add New Service** → **Gmail** → **Connect Account**. Sign in as
   propcare.admin@gmail.com and allow EmailJS to send email.
3. Click **Create Service**. Write down the **Service ID** (it looks like `service_abc1234`).

## 2. Template 1: customer confirmation

1. Open **Email Templates** → **Create New Template**.
2. Open the template's **Content** and switch from the visual editor to the **code (HTML)** editor.
   Delete the example and paste the whole of `email-templates/customer-confirmation.html`.
3. Fill in the template fields exactly like this:

   | Field | Value |
   |---|---|
   | Subject | `Welcome to PropCare — your {{plan_name}} request is received` |
   | To Email | `{{to_email}}` |
   | From Name | `PropCare` |
   | From Email | leave "Use default email address" ticked |
   | Reply To | `{{reply_to}}` |

4. **Save**. Write down the **Template ID** (in the template's Settings, e.g. `template_xyz9876`).

## 3. Template 2: new-request notification to PropCare

1. **Create New Template** again and paste the whole of `email-templates/admin-notification.html`.
2. Fill in:

   | Field | Value |
   |---|---|
   | Subject | `New request: {{plan_heading}} — {{customer_name}} ({{city_area}})` |
   | To Email | `propcare.admin@gmail.com` (type the address itself, not a variable) |
   | From Name | `PropCare website` |
   | Reply To | `{{reply_to}}` (the customer's email) |

3. **Save** and write down this **Template ID**.

Don't rename anything inside `{{double braces}}` in the templates. The website fills those in.
Values in double braces are HTML-escaped by EmailJS, so nothing a visitor types can change the email.
The PropCare logo in both emails is loaded from the live site (`/email/propcare-mark.png`), so it
appears once this version of the site is deployed.

## 4. Copy the Public Key

Open **Account** → **General** and copy the **Public Key**. It is designed to be used in websites.
Never use the **Private Key** in this project.

## 5. Put the four values into Netlify

In Netlify: **Site configuration → Environment variables → Add a variable**:

| Name | Value |
|---|---|
| `VITE_EMAILJS_SERVICE_ID` | Service ID from step 1 |
| `VITE_EMAILJS_TEMPLATE_CUSTOMER` | Template ID from step 2 |
| `VITE_EMAILJS_TEMPLATE_ADMIN` | Template ID from step 3 |
| `VITE_EMAILJS_PUBLIC_KEY` | Public Key from step 4 |

Then **Deploys → Trigger deploy → Clear cache and deploy site**. The values are built into the site,
so changing them always needs a new deploy.

To build on your own computer instead, copy `.env.example` to `.env`, fill in the same four values,
and run `npm run build`. `.env` is ignored by Git, so it is never committed.

## 6. Security notes

- The Public Key can only trigger **your own templates with your own content**. It can't be used to
  send other emails, which is why EmailJS says it is fine for it to be visible in a website.
- In EmailJS → **Account → Security**, leave **"Use Private Key"** turned off. When it is on, EmailJS
  also needs the private key, which must never be put in a website, so the form would stop sending.
- The paid plans add a **domain allowlist**. If you upgrade, add the live address there, e.g.
  `https://propcare-bengaluru.netlify.app`.
- The form already has a hidden anti-spam field. EmailJS accepts 1 request per second, so the site
  sends the two emails about a second apart and retries once if EmailJS says it is busy.

## 7. Test it

Open the live site → **Submit a Request** → fill it in with your own email address → send. Then check:

- [ ] The confirmation arrives at your address. Check spam the first time and mark it "Not spam".
- [ ] The notification arrives at propcare.admin@gmail.com with every field, and **Reply** goes to the customer.
- [ ] Netlify → **Forms** → `property-request` shows the submission. Turn on form detection there the first time.
- [ ] EmailJS → **Email History** shows both emails (kept for 7 days on the free plan).

## Troubleshooting

| What the visitor sees | Likely cause |
|---|---|
| "We've received your request", then "We couldn't send your confirmation email just now", every time | EmailJS isn't sending. Usually it's a missing or mistyped ID, IDs in the wrong variable, Gmail disconnected in EmailJS, the monthly limit used up, or no redeploy after adding the variables. Check EmailJS → Email History. The request itself is still saved in Netlify Forms. |
| The same message, but the notification reaches propcare.admin@gmail.com | Only the customer email failed. Check that template 1's **To Email** is `{{to_email}}`. |
| "Request sent. Welcome to PropCare!" but the customer can't find the email | Look in spam or Promotions. Mark it "Not spam" the first time. |
| "Couldn't send — please WhatsApp us" | Both EmailJS and Netlify Forms failed. Check the points above, and that form detection is on in Netlify → Forms. |
| Blank spaces in an email | A `{{variable}}` was renamed or deleted in the template. Paste the template file again. |
