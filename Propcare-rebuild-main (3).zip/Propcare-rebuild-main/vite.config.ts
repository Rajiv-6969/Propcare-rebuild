import { defineConfig, loadEnv, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath, URL } from 'node:url';
import { ROUTES, routeFor, type RouteMeta } from './src/config/routes';

const DEFAULT_SITE_URL = 'https://propcare-bengaluru.netlify.app';

const escapeAttr = (value: string) => value.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const canonicalFor = (siteUrl: string, route: RouteMeta) => `${siteUrl}${route.path}`;

/** Fill the __PC_*__ placeholders in index.html for one route. */
function applyRouteMeta(html: string, route: RouteMeta, siteUrl: string): string {
  const values: Record<string, string> = {
    TITLE: escapeAttr(route.title),
    DESCRIPTION: escapeAttr(route.description),
    CANONICAL: canonicalFor(siteUrl, route),
    SITE_URL: siteUrl,
    ROBOTS: route.id === 'not-found' ? 'noindex, follow' : 'index, follow',
  };
  return html.replace(/__PC_([A-Z_]+)__/g, (match, key: string) => values[key] ?? match);
}

function sitemapXml(siteUrl: string): string {
  const today = new Date().toISOString().slice(0, 10);
  const urls = ROUTES.filter((route) => route.sitemap).map((route) => [
    '  <url>',
    `    <loc>${canonicalFor(siteUrl, route)}</loc>`,
    `    <lastmod>${today}</lastmod>`,
    `    <priority>${(route.priority ?? 0.5).toFixed(1)}</priority>`,
    '  </url>',
  ].join('\n'));
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.join('\n')}\n</urlset>\n`;
}

/**
 * One real HTML file per page (about.html, packages.html, …), each with its own title,
 * description, canonical URL and Open Graph tags, plus sitemap.xml and robots.txt —
 * all generated from src/config/routes.ts so they never drift apart.
 */
function propcarePages(siteUrl: string): Plugin {
  return {
    name: 'propcare-pages',
    enforce: 'post',
    transformIndexHtml: {
      order: 'pre',
      handler(html, ctx) {
        // Dev server: fill in the meta for the page being viewed. Build: keep the
        // placeholders so generateBundle can clone the processed HTML per route.
        if (!ctx.server) return html;
        const pathname = new URL(ctx.originalUrl ?? ctx.path, 'http://localhost').pathname;
        return applyRouteMeta(html, routeFor(pathname), siteUrl);
      },
    },
    generateBundle(_options, bundle) {
      const index = bundle['index.html'];
      if (!index || index.type !== 'asset') throw new Error('propcare-pages: index.html missing from the bundle');
      // Preload the three fonts used above the fold, so text is laid out once in its final font.
      const fonts = Object.keys(bundle)
        .filter((file) => /(geist-latin-wght-normal|source-serif-4-latin-wght-(normal|italic))-[\w-]+\.woff2$/.test(file))
        .sort()
        .map((file) => `<link rel="preload" href="/${file}" as="font" type="font/woff2" crossorigin />`);
      if (fonts.length !== 3) this.warn(`propcare-pages: expected 3 fonts to preload, found ${fonts.length}`);
      const template = String(index.source).replace('<title>', `${fonts.join('\n    ')}\n    <title>`);
      for (const route of ROUTES) {
        const html = applyRouteMeta(template, route, siteUrl);
        if (route.file === 'index.html') index.source = html;
        else this.emitFile({ type: 'asset', fileName: route.file, source: html });
      }
      this.emitFile({ type: 'asset', fileName: 'sitemap.xml', source: sitemapXml(siteUrl) });
      this.emitFile({ type: 'asset', fileName: 'robots.txt', source: `User-agent: *\nAllow: /\n\nSitemap: ${siteUrl}/sitemap.xml\n` });
    },
  };
}

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), 'VITE_');
  const siteUrl = (env.VITE_SITE_URL || DEFAULT_SITE_URL).replace(/\/+$/, '');
  return {
    plugins: [react(), propcarePages(siteUrl)],
    resolve: { alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) } },
    build: { target: 'es2020', cssCodeSplit: false, assetsInlineLimit: 0 },
  };
});
