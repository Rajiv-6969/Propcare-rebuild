# PropCare Bengaluru website

Website for PropCare Private Limited, Anekal, Bengaluru: "Healthy Properties Happy Owners".
It is built with React, TypeScript and Vite. Every page is built as its own HTML file, so it can be
hosted on Netlify or any static host.

What changed in this version is listed in [CHANGES.md](CHANGES.md).

## Run locally

Requires Node.js 20 or later and npm. From the project folder, run:

```bash
npm ci
npm run dev
```

Open the local URL printed by Vite, usually `http://localhost:5173/`. Stop the server with **Ctrl+C**.

To build and preview the production version:

```bash
npm run build      # type-checks, then builds into dist/
npm run preview    # serves dist/, usually at http://localhost:4173/
npm test           # unit tests for the pricing maths and the emails
```

## Pages

| Page | File |
|---|---|
| Home | `/` |
| About Us | `/about.html` |
| Services | `/services.html` |
| What We Check (site visit checklists) | `/what-we-check.html` |
| Packages (plans, billing toggle, fee estimator) | `/packages.html` |
| Submit a Request | `/request.html` |
| Contact Us | `/contact.html` |
| Terms & Conditions | `/terms.html` |
| Privacy | `/privacy.html` |
| Page not found | `404.html` |

On Netlify the short addresses work too, e.g. `/packages`. Each page's title, description and social
preview text is set in `src/config/routes.ts`. `sitemap.xml` and `robots.txt` are generated from the
same list when the site is built.

## Changing prices, checklists or terms

All the business content is in one place. Edit it there and every page, the estimator, the request
form, the emails and the WhatsApp messages update together.

| What | File |
|---|---|
| Plans, prices, comparison tables, billing terms, one-time charges | `src/data/plans.ts` |
| Site visit checklists (sections 2.1–2.5) | `src/data/checklists.ts` |
| Terms & Conditions (clauses 3.1–3.13) and their date | `src/data/terms.ts` |
| Service descriptions | `src/data/services.ts` |
| Phone, WhatsApp number, email, address, hours | `src/config/site.ts` |

The wording follows PropCare's document "PropCare — Pricing, Site Visit Checklists & Terms and
Conditions" (28 Sep 2026) word for word. Keep the section numbers the same as the document, because
the pages link references such as "see 3.6" to those numbers. When the terms change, also update
`TERMS_UPDATED` in `src/data/terms.ts`.

## Confirmation emails

"Submit a Request" sends a confirmation to the customer and a notification to
propcare.admin@gmail.com through EmailJS. It also keeps a copy in Netlify Forms. Setting it up takes
about 15 minutes: follow [EMAIL_SETUP.md](EMAIL_SETUP.md). Until the four EmailJS values are set, the
form still saves to Netlify Forms and offers WhatsApp instead.

## Deploy to Netlify

1. Put this project in a Git repository owned by the client, or invite the client to this one.
2. In the client's Netlify account, import the repository. The build settings are already in
   `netlify.toml`: build command `npm run build`, publish directory `dist`.
3. Add the EmailJS environment variables from [EMAIL_SETUP.md](EMAIL_SETUP.md), then deploy.
4. Using your own domain? Add it in Netlify and follow its DNS instructions, then set the environment
   variable `VITE_SITE_URL` to the new address (for example `https://www.propcare.in`) and redeploy.
   This updates the canonical links, social previews and sitemap.
5. In Netlify → **Forms**, enable form detection, then send a test request from `/request.html`. Check
   it appears under `property-request` and set who gets Netlify's notifications.
6. Check every page on a phone and a computer, and tap the WhatsApp and call buttons on a real phone.

Security headers and redirects are in `public/_headers` and `public/_redirects`. If you add another
outside service that the browser calls, add it to the `Content-Security-Policy` in `public/_headers`.

## Handover checklist

- [ ] The client has owner/admin access to the hosting account, the domain/DNS, the EmailJS account
      and this repository.
- [ ] The client has approved the copy, phone, email, WhatsApp number, address, prices and terms.
- [ ] A test request produced both emails and a Netlify Forms entry. See the checklist in
      [EMAIL_SETUP.md](EMAIL_SETUP.md).
- [ ] HTTPS, redirects, page titles, sitemap and robots file are verified on the final domain.
- [ ] The client has the live URL and knows who maintains the site and its dependencies.
