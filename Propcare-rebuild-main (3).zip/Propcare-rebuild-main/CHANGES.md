# Changes

Upgrade of the PropCare website (the `PropCare-client-delivery` project from `Propcare.zip`) to a
dynamic but professional design, with new pricing, checklists, terms, confirmation emails and a
WhatsApp fix. Same stack (React + TypeScript + Vite), same logo and brand colours.

## Content: pricing, checklists and terms

- **All content now follows the owner's document word for word:** "PropCare — Pricing, Site Visit
  Checklists & Terms and Conditions" (28 Sep 2026). Section 1 covers pricing, section 2 the checklists
  and section 3 the Terms & Conditions.
- **One source for every price:** `src/data/plans.ts`. The plan cards, comparison tables, estimator,
  request form, emails and WhatsApp messages all read from it, so a price can't disagree with itself.
  No old prices or plan names remain.
- **New "What We Check" page** with the checklists for every visit, apartments, villas, tenanted
  homes and land (sections 2.1–2.5). It shows the OK / Attention / Urgent legend.
- **New Terms & Conditions page** with clauses 3.1–3.13 and a sticky table of contents on desktop.
  It is linked from the footer and from the required "I agree" checkbox on the request form.
- **Section numbers match the document.** Cross-references such as "see 3.6", "everything in 2.2"
  and "(section 1)" are clickable links.
- **One sentence is left off the website on purpose.** The document's terms preamble also says "This
  draft should be reviewed by a lawyer before use; it is a working template, not legal advice." That
  is a note to PropCare, not a customer term. A comment in `src/data/terms.ts` records it.

## Look and feel ("dynamic but professional")

- **Design system** in `src/styles/`, with brand colours taken from the logo: navy `#0B3C6C`, shield
  blue `#0A5288`, "Care" green `#207A45` and gold `#C9973F`. It uses an 8 px spacing scale and two
  self-hosted fonts: Source Serif 4 for headings and Geist for text. Light and dark themes are included.
- **New hero:** the headline "Your property, cared for while you're away", the tagline, View Packages
  and Chat on WhatsApp buttons, a sample visit report (labelled as a sample) and fact counters based
  on the document.
- **Motion:**
  - Sections fade in as you scroll, the header shrinks on scroll, prices animate when the billing
    cycle changes, a tick draws after a successful request, and the floating WhatsApp button pulses once.
  - Each of these effects takes 600 ms or less and never hides content.
  - The one slow movement is the gradient behind the navy bands, as the brief asks ("a slow gradient").
    It pauses when it is off screen.
  - All motion switches off when the visitor's device asks for reduced motion.
- **Packages page:**
  - Tabs for Home Care, Rental Care, Land Watch and Family Portfolio.
  - A Monthly / Quarterly (5% off) / Annual (pay 10, get 12) toggle showing the effective monthly
    price and the savings.
  - Care Plus is highlighted as Recommended, with comparison tables that become stacked cards on phones.
  - A live estimator covering size add-ons, rent percentages and minimums, extra acres, and the Family
    Portfolio discount (10% for 2–3 properties, 15% for 4 or more).
  - The one-time charges and billing terms tables.
- **Removed because they conflicted with the brief:**
  - The 1.8-second intro loading screen, which blocked content.
  - The site-wide gradient colour picker; colours now come from the logo.
  - The animated noise-field background and the endlessly looping button shine.
  - Unused components: magnetic cursor, custom cursor, particles, beams, tile preloader and glowing border.
  - Tailwind, GSAP and vecteur, since nothing uses them any more.

## Submit a Request and confirmation emails

- **Form:**
  - All the requested fields. The plan list depends on the plan family, and size, rent or land area
    only appear for the plan that needs them.
  - "Choose this plan" and estimator links pre-fill the form through the URL, e.g.
    `/request.html?plan=care-plus&billing=annual`.
  - Inline errors and an error summary, a loading state, a honeypot against spam, and a required
    Terms checkbox.
- **Emails go through EmailJS.**
  - PropCare gets a notification with every field, and Reply goes to the customer. The customer gets a
    confirmation in the required order, with the plan, everything included, their selections and the
    estimate marked "Estimate — excl. GST; final quote confirmed after a call".
  - The templates are in `email-templates/` and the setup steps in `EMAIL_SETUP.md`. The keys come from
    environment variables (`.env.example`); none are in the code.
- **Netlify Forms keeps a copy** of every request (`property-request`).
- **Fallback:** if the confirmation can't be sent, the visitor is offered WhatsApp with their request
  already written into the message. If nothing could be sent, they see "Couldn't send — please
  WhatsApp us".

## WhatsApp and phone links

- **One helper builds every WhatsApp link** (`src/config/site.ts`), in the form
  `https://wa.me/917760273587?text=<encoded message>`. Every link opens in a new tab with
  `rel="noopener noreferrer"`, and plan buttons pre-fill "Hi PropCare, I'm interested in the <plan> plan."
  The old links used the right number but were inconsistent: some had no `target` or `rel`, and none
  were pre-filled.
- **Phone numbers** are `tel:+917760273587` links.
- **The Contact page shows a QR code** so desktop visitors can open the chat on their phone.

## Pages, SEO and performance

- **Every page is a real HTML file** with its own title, description, canonical URL, Open Graph and
  Twitter tags. These are generated from `src/config/routes.ts`, along with `sitemap.xml` and
  `robots.txt`. Clean URLs (`/packages`) work on Netlify, and unknown URLs get a real 404 page.
- **Favicon, app icons and a 1200×630 share image** are made from the existing logo files, which are
  unchanged.
- **Security headers** were updated so the browser may call EmailJS (`connect-src`).
- **Lighthouse (mobile) on the production build:** Performance 93–97; Accessibility, Best Practices
  and SEO 100.

## Tests

- `npm test` runs 27 unit tests: pricing maths, email content and order, HTML escaping, and send order
  and retries.
- Browser checks on the built site covered all prices, billing and discount maths, plan pre-selection,
  the success and failure paths, every WhatsApp and phone link, layouts from 360 to 1440 px wide,
  dark theme and reduced motion.
